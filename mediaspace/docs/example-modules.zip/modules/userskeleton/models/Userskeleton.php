<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * module that implements all entry interfaces + dependency and all view hooks
 *
 * @author gonen
 */
class Userskeleton_Model_Userskeleton extends Kms_Module_BaseModel
    implements
    Kms_Interface_Form_User_Edit,
    Kms_Interface_Model_User_Add,
    Kms_Interface_Model_User_Get,
    Kms_Interface_Model_User_Update
{
    public function editForm(Application_Form_EditUser $form)
    {
        // add or change elements in user edit/add form

        // example module to learn from: customdata, although not imlementing Kms_Interface_Form_User_Edit, it implements Kms_Interface_Form_Entry_Edit which has the same logic
    }

    function add(Application_Model_User $model)
    {
        // catch event of user added, use $model->user and do what ou wish for that event
    }

    function get(Application_Model_User $model)
    {
        // user object fetched from the API
    }

    function update(Application_Model_User $model)
    {
        // user object was updated - you can act upon the update event to do additional processing
    }

}

?>
