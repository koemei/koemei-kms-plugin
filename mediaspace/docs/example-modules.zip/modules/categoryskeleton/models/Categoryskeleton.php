<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * module that implements all category interfaces
 *
 * @author gonen
 */
class Categoryskeleton_Model_Categoryskeleton extends Kms_Module_BaseModel implements Kms_Interface_Model_Category_Get, Kms_Interface_Model_Category_Save
{
    function get(Application_Model_Category $model)
    {
        // take category from the model and do something with it
    }

    function save(Application_Model_Category $model)
    {
        // do something according to upadted category
    }
}

?>
