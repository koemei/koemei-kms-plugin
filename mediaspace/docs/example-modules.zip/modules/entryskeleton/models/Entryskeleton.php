<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * module that implements all entry interfaces + dependency and all view hooks
 *
 * @author gonen
 */
class Entryskeleton_Model_Entryskeleton extends Kms_Module_BaseModel
    implements  Kms_Interface_Form_Entry_Edit, Kms_Interface_Model_Dependency, Kms_Interface_Model_Entry_Get,
        Kms_Interface_Model_Entry_ListFilter, Kms_Interface_Model_Entry_Save, Kms_Interface_Model_ViewHook
{

    /** Entry Related implementations **/
    public function editForm(Application_Form_EditEntry $form)
    {
        // change the form object passed to the function
    }

    public static function getModuleDependency()
    {
        // declare that this module depends on "publish" module
        // if "publish" module is not enabled - this one will be excluded automatically
        // there is no real dependency, this is only for illustrating how dependency is declared/enforced
        return array('publish');
    }

    function get(Application_Model_Entry $model)
    {
        // do something with the entry that was just fetched from the the API
        // save your data to $model->setModuleData($data, 'YOUR_MODULE_NAME');

        // modules to learn from: customdata
    }

    public function modifyFilter(Kaltura_Client_Type_BaseEntryFilter $filter, $context)
    {
        // check what is the context

        // change filter as you wish, like
        // $filter->statusEqual = Kaltura_Client_Enum_EntryStatus::NO_CONTENT;
    }

    function save(Application_Model_Entry $model)
    {
        // look at the saved entry:
        // $entry = $model->entry

        // do whatever you wish according to the saved entry

        // modules to learn from: customdata
    }
    /** END Entry Related implementations **/

}

?>
