<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * module that implements all view hooks
 *
 * @author gonen
 */
class Viewhookskeleton_Model_Viewhookskeleton extends Kms_Module_BaseModel // Kms_Module_BaseModel already implements  Kms_Interface_Model_ViewHook
{
    const MODULE_NAME = 'viewhookskeleton';

    // other functions in viewHook interface are implemented by the Kms_Module_BaseModel
    // The only function that really needs to be implemented in each module is addViewHooks,
    //   when module wants to declare its own new viewHook for other modules to use.
    function addViewHooks()
    {
        // return array of viewHooks declared by this module so other modules can add content in
        return array('SkeletonNewHook' => 'appears in my custom page, before content');
    }

    // declare viewHooks this module implements (returns content for)
    // for the sake of example we're using the name of the viewhook as the name of the action to be invoked
    public $viewHooks = array(
         Kms_Resource_Viewhook::CORE_VIEW_HOOK_AFTERLOGIN => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_AFTERLOGIN, // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_BEFORELOGIN => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_BEFORELOGIN, // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_MYMEDIASIDEBARPOST => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_MYMEDIASIDEBARPOST,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_MYMEDIASIDEBARPRE => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_MYMEDIASIDEBARPRE,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_MYPLAYLISTSSIDE => array (
            'action' => 'myPlaylistsSide', // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PLAYERSIDETABLINKS => array (
            'action' => 'playerSideTabLinks', // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PLAYERSIDETABS => array (
            'action' => 'playerSideTabs', // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PLAYERTABLINKS => array (
            'action' => 'playerTabLinks', // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PLAYERTABS => array (
            'action' => 'playerTabs', // action name must start lowercase
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTENTRYDETAILS => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTENTRYDETAILS,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTGALLERY => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTGALLERY,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTGALLERYITEMS => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTGALLERYITEMS,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYMEDIA => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYMEDIA,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYMEDIAENTRIES => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYMEDIAENTRIES,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYPLAYLISTSENTRIES => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTMYPLAYLISTSENTRIES,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREGALLERY => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREGALLERY,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREGALLERYITEMS => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREGALLERYITEMS,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYMEDIA => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYMEDIA,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYMEDIAENTRIES => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYMEDIAENTRIES,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYPLAYLISTSENTRIES => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PREMYPLAYLISTSENTRIES,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PRESIDENAV => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PRESIDENAV,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTSIDENAV => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTSIDENAV,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_HEADERMENU => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_HEADERMENU,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTHEADER => array (
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POSTHEADER,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_PRE_HEADERUPLOAD => array(
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_PRE_HEADERUPLOAD,
            'controller' => 'index',
            'order' => 100,
        ),
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_POST_HEADERUPLOAD => array(
            'action' => Kms_Resource_Viewhook::CORE_VIEW_HOOK_POST_HEADERUPLOAD,
            'controller' => 'index',
            'order' => 100,
        ),
    );

    // since we have controller and actions we must declare access rules for those actions
    public function getAccessRules()
    {
        $accessrules = array();

        // get all actions into one array from $this->viewhooks
        $actions = array();
        foreach($this->viewHooks as $viewHookName => $viewHookDeails)
        {
            $actions[] = $viewHookDeails['action'];
        }

        // defaults to allow for anonymous
        $accessrules[] = array(
            'controller' => self::MODULE_NAME.':index',
            'actions' => $actions,
            'role' => Kms_Plugin_Access::EMPTY_ROLE,
        );

        return $accessrules;
    }
}

?>
