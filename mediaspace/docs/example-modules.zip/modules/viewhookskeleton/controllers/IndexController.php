<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * Example IndexController for viewhookSkeleton module
 * Each action in this controller represents a view hook implemented by this module.
 * each action is invoked by the system when the specific viewhook needs to be displayed
 * For the sake of example, each function only passes variable to the view with the name of the viewhook
 *
 * @author gonen
 */
class Viewhookskeleton_IndexController extends Kms_Module_Controller_Abstract
{
    private function getCleanFunctionName($functionName)
    {
        return str_replace(__CLASS__.'::', '', str_replace('Action', '', $functionName));
    }
    
    public function afterloginAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function beforeloginAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function mymediasidebarpostAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function mymediasidebarpreAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function myplaylistssideAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function playersidetablinksAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function playersidetabsAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function playertablinksAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function playertabsAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postentrydetailsAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postgalleryAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postgalleryitemsAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postmymediaAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postmymediaentriesAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postmyplaylistsentriesAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function pregalleryAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function pregalleryitemsAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function premymediaAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function premymediaentriesAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function premyplaylistsentriesAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function presidenavigationAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postsidenavigationAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function headermenuAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postheaderAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function preheaderuploadAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }

    public function postheaderuploadAction()
    {
        $this->view->viewhookName = $this->getCleanFunctionName(__METHOD__);
    }
}

?>
