<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 *  Category Model
 */
class Application_Model_Category
{
	/* these consts match the values of Kaltura_Client_Enum_PrivacyType */
    const MEMBERSHIP_OPEN = Kaltura_Client_Enum_PrivacyType::ALL; //1
    const MEMBERSHIP_RESTRICTED = Kaltura_Client_Enum_PrivacyType::AUTHENTICATED_USERS; //2;
    const MEMBERSHIP_PRIVATE = Kaltura_Client_Enum_PrivacyType::MEMBERS_ONLY; //3;
        
    const CATEGORY_USER_NO_ROLE = 99;
    
    const CATEGORY_USER_TYPE_ALL = 'all';
    const CATEGORY_USER_TYPE_MANAGER = 'manager';
    const CATEGORY_USER_TYPE_MEMBER = 'member';
    const CATEGORY_USER_TYPE_CONTRIBUTOR = 'contributor';
    const CATEGORY_USER_TYPE_MODERATOR = 'moderator';
    
    const CATEGORY_TYPE_MANAGER = 0;
    const CATEGORY_TYPE_MEMBER = 3;
    const CATEGORY_TYPE_CONTRIBUTOR = 2;
    const CATEGORY_TYPE_MODERATOR = 1;
    
    const CATEGORY_PUBLISH_PAGE_SIZE = 1000;
    
    const METADATA_ADDITIONAL_INFO_KEY_PATH = "Detail";

    public $id;
    public $name;
    public $Category;
    public $Categories;
    private $totalcount = 0;
    private $modules = array();
    
    
 	/**
     * retreive a category either by its id or by its name.
     * @param string $name			category full name
     * @param boolean $absolutePath is this the whole category name (true) or only from local root (false)
     * @param int $id				category id
     */
    public function get($name = null, $absolutePath = false, $id = null) {
        $category = null;
    	if (!empty($id)) {
    		$category = $this->getById($id);
    	}
    	else if (!empty($name)) {
    		$category = $this->getByName($name, $absolutePath);
    	}

        // call Kms_Interface_Model_Category_Get
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_Get');
        foreach ($models as $model) {
            $model->get($this);
        }

    	return $category;
    }
    
    /**
     * reject the entries pending moderation
     * @param Kaltura_Client_Type_Category $channel
     * @param array $entries
     * @return boolean
     */
    public function rejectCategoryEntries(Kaltura_Client_Type_Category $category, array $entries = array())
    {
        Kms_Log::log('category: rejecting entries ' . implode(',', $entries),Kms_Log::DEBUG);
        $result = true;
        
        $client = Kms_Resource_Client::getUserClient();
        
        // reject the entries from the channel
        $client->startMultiRequest();
        foreach ($entries as $entry)
        {
            $client->categoryEntry->reject($entry, $category->id);
            $cacheTags[] = 'entry_' . $entry;
        }
        try
        {
            $results = $client->doMultiRequest();
        }
        catch(Kaltura_Client_Exception $e)
        {
            // test if an entry is not pending 
            if ($e->getCode() == 'CANNOT_REJECT_CATEGORY_ENTRY_SINCE_IT_IS_NOT_PENDING' && count($entries) > 1)
            {
                Kms_Log::log('category: some entries ' . implode(',',$entries) .' are not pending for category ' . $category->id . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::INFO);
                // this is fine by us - go on.
            }
            else{
                Kms_Log::log('category: Error rejecting entries ' . implode(',',$entries) .' for category ' . $category->id . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::WARN);
                return false;
            }
        }        
        
        if ($results)
        {
        	foreach ($results as $result)
        	{
        		if ($result instanceof Kaltura_Client_Exception)
        		{
        			if ($result->getCode() == 'CANNOT_REJECT_CATEGORY_ENTRY_SINCE_IT_IS_NOT_PENDING' && count($entries) > 1)
        			{
        				Kms_Log::log('category: some entries ' . implode(',',$entries) .' are not pending for category ' . $category->id . ': ' . $result->getCode() . ', ' . $result->getMessage(), Kms_Log::INFO);
        				// this is fine by us - go on.
        			}
        			else{
        				Kms_Log::log('category: Error rejecting entries ' . implode(',',$entries) .' for category ' . $category->id . ': ' . $result->getCode() . ', ' . $result->getMessage(), Kms_Log::WARN);
        				return false;
        			}
        		}
        	}
        }
                
        // clean the entries cache
        $cacheTags[] = 'categoryId_'.$category->id;
        Kms_Resource_Cache::apiClean('entry', array(), $cacheTags);
        Kms_Resource_Cache::apiClean('entries', array(''), $cacheTags); 
        return $result;
    }
    
    /**
     * approve entries pending moderation
     * @param Kaltura_Client_Type_Category $channel
     * @param array $entries
     */
    public function approveCategoryEntries(Kaltura_Client_Type_Category $category, array $entries = array())
    {
        Kms_Log::log('category: approving entries ' . implode(',', $entries),Kms_Log::DEBUG);
        
        $client = Kms_Resource_Client::getUserClient();
        
        $client->startMultiRequest();
        foreach ($entries as $entry)
        {
            $client->categoryEntry->activate($entry, $category->id);
            $cacheTags[] = 'entry_' . $entry;
        }
        try
        {
            $results = $client->doMultiRequest();
        }
        catch(Kaltura_Client_Exception $e)
        {
            Kms_Log::log('category: Error approving entries for category ' . $category->name . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::WARN);
            return false;
        }
        if ($results)
        {
        	foreach ($results as $result)
        	{
        		if ($result instanceof Kaltura_Client_Exception)
        		{
        			Kms_Log::log('category: Error approving entries ' . implode(',',$entries) .' for category ' . $category->id . ': ' . $result->getCode() . ', ' . $result->getMessage(), Kms_Log::WARN);
        			return false;
        			
        		}
        	}
        }
        
        // clean the entries cache
        $cacheTags[] = 'categoryId_'.$category->id;
        Kms_Resource_Cache::apiClean('entry', array(), $cacheTags);
        Kms_Resource_Cache::apiClean('entries', array(''), $cacheTags);
        return true;
    }
    
	
    
    /**
     * get the category user objects
     * @param Kaltura_Client_Type_CategoryUserFilter $filter
     * @param array $params
     * @throws Kaltura_Client_Exception
     */
    private function getCategoryUserList(Kaltura_Client_Type_CategoryUserFilter $filter, array $params = array())
    {
        $pager = new Kaltura_Client_Type_FilterPager();
        //$pager->pageSize = 3;
        if (!empty($params['page'])){
            $pager->pageIndex = $params['page'];
        }
        if (!empty($params['pagesize'])){
            $pager->pageSize = $params['pagesize'];
        }
        $cacheTags = array();
        $channelUsers = array();
        $cacheParams = Kms_Resource_Cache::buildCacheParams($filter,$pager);

        if(!$results = Kms_Resource_Cache::apiGet('categoryUser', $cacheParams))
        {
            $client = Kms_Resource_Client::getUserClient();
            try
            {
                $results = $client->categoryUser->listAction($filter,$pager);
        
                if (!empty($results->objects) && count($results->objects)){
                    foreach ($results->objects as $categoryUser){
                        $cacheTags[] = 'userId_' . $categoryUser->userId;
                        $cacheTags[] = 'categoryId_' . $categoryUser->categoryId;
                    }
                }
                
                // add the filter params to the tags, in case the results are empty
                if (!empty($filter->categoryIdEqual)) {
                    $cacheTags[] = 'categoryId_' . $filter->categoryIdEqual;
                }
                 if (!empty($filter->userIdEqual)) {
                    $cacheTags[] = 'userId_' . $filter->userIdEqual;
                }

                Kms_Resource_Cache::apiSet('categoryUser', $cacheParams, $results, $cacheTags);
            }
            catch (Kaltura_Client_Exception $e)
            {
                Kms_Log::log('category: Failed to get categoryUser ' .$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
                throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
            }
        }
        
        if($results){
            $channelUsers = $results->objects;            
            $this->setTotalCount(isset($results->totalCount) ? $results->totalCount : 0);
        }
        
        return $channelUsers;
    }
    
	/**
     * return the channel users of a specific type
     * @param Kaltura_Client_Type_Category $channel
     * @param string $userType
     * @param array $params
     * @throws Kaltura_Client_Exception
     */
    public function getCategoryUsers(Kaltura_Client_Type_Category $cat, $userType = '', array $params = array())
    {
        $channelUsers = array();
        
        // filter
        $filter = new Kaltura_Client_Type_CategoryUserFilter();
        $filter->categoryIdEqual = $cat->id;
        $filter->orderBy = Kaltura_Client_Enum_CategoryUserOrderBy::CREATED_AT_ASC;
                
        if ($userType == self::CATEGORY_USER_TYPE_ALL){
             // all levels 
            $permissions = array(
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::MEMBER,
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR,
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR,
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER);
            $filter->permissionLevelIn = implode(',',$permissions);
        }
        else if ($userType == self::CATEGORY_USER_TYPE_MANAGER)
        {
            // only manager level
            $filter->permissionLevelEqual = Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER;
        }
    	else if ($userType == self::CATEGORY_USER_TYPE_CONTRIBUTOR)
        {
            $filter->permissionLevelEqual = Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR;
        }
    	else if ($userType == self::CATEGORY_USER_TYPE_MODERATOR)
        {
            $filter->permissionLevelEqual = Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR;
        }
    	else if ($userType == self::CATEGORY_USER_TYPE_MEMBER)
        {
            $filter->permissionLevelEqual = Kaltura_Client_Enum_CategoryUserPermissionLevel::MEMBER;
        }
        else {
            // all levels but manager
            $permissions = array(
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::MEMBER,
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR,
                    Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR);
            $filter->permissionLevelIn = implode(',',$permissions);
        }
        
        // get the category user objects
        $channelUsers = $this->getCategoryUserList($filter,$params);
        
        return $channelUsers;
    }
    
    
    /**
     * get a single category by its name.
     * @param string $name - the name of the category. NOT id - name.
     * @throws Kaltura_Client_Exception
     * @return Ambigous <boolean, unknown>
     */
    private function getByName($name, $absolutePath = false)
    {
        // gallery root
        $rootGalleryCategory = Kms_Resource_Config::getRootGalleriesCategory();
        $client = Kms_Resource_Client::getUserClient();
        $filter = new Kaltura_Client_Type_CategoryFilter();
        if($absolutePath || preg_match('/^' . preg_quote($rootGalleryCategory, '/') . '>/', $name)) {
            // get from absolute mediaspace root
            $filter->fullNameEqual = $name;
        }
        else {
            $filter->fullNameEqual = $rootGalleryCategory.'>'.$name;
        }
        
		$userId = Kms_Plugin_Access::getId();
        $cacheParams = Kms_Resource_Cache::buildCacheParams($filter);
		$cacheParams['userId'] = $userId;
        
        
        if(!$this->Category = Kms_Resource_Cache::apiGet('category', $cacheParams)) {            
            try  {
                $category = $client->category->listAction($filter);
                if(isset($category->objects) && count($category->objects)) {
                    $this->Category = $category->objects[0];
                    $this->safeStrings($this->Category);

                    // set the membership data
                    $this->Category->membership = $this->getMembership($this->Category);
                    // cache with list params
			        $cacheTags = array( 'categoryUser_' . $userId, 'categoryId_' . $this->Category->id, 'categories');
                    Kms_Resource_Cache::apiSet('category', $cacheParams, $this->Category, $cacheTags);
                    // cache with get params
                    $cacheParams = array( "categoryId" => $this->Category->id, "userId" => $userId);
                    Kms_Resource_Cache::apiSet('category', $cacheParams, $this->Category, $cacheTags);
                }
            }
            catch(Kaltura_Client_Exception $e) {
                Kms_Log::log('category: Failed to get category '.$name.'. '.$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
                throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
            }
        }
        
        $this->name = isset($this->Category) && $this->Category && isset($this->Category->name) ? $this->Category->name : null;
        $this->id = isset($this->Category) && $this->Category && isset($this->Category->fullName) ? $this->Category->fullName : null;
        
        return $this->Category;
    }
    
    
    
    private function getById($id)
    {
    	$category = null;
        $userId = Kms_Plugin_Access::getId();
        
    	$cacheParams = array( "categoryId" => $id, "userId" => $userId);
        $cacheTags = array( 'categoryUser_' . $userId, 'categoryId_' . $id, 'categories');
        
        if(!$category = Kms_Resource_Cache::apiGet('category', $cacheParams)) {
            $client = Kms_Resource_Client::getUserClient();
            try {
                $category = $client->category->get($id);
                $this->safeStrings($category);
                
            	// set the membership data
	            if ($category){
	                $category->membership = $this->getMembership($category);
	            }
	            
            	// cache with get params
            	Kms_Resource_Cache::apiSet('category', $cacheParams, $category, $cacheTags);
            	// cache with list params
            	$cacheParams = $this->createMockCacheParams($category->fullName);
	            $cacheParams['userId'] = $userId;
            	Kms_Resource_Cache::apiSet('category', $cacheParams, $category, $cacheTags);
            }
            catch(Kaltura_Client_Exception $e) {
                Kms_Log::log('category: Error fetching category from API: '.$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
            }
        }
        $this->Category = $category;
        return $category;
    }
    
    private function safeStrings(Kaltura_Client_Type_Category &$category)
    {
        $category->tags = Kms_Resource_Wysihtml::safeString($category->tags);
        $category->name = Kms_Resource_Wysihtml::safeString($category->name);
        $category->description = Kms_Resource_Wysihtml::safeString($category->description);
    }
    
    /**
     * create cache params as if request was made using "getByName"
     * @param  $categoryName	category's full name
     */
    private function createMockCacheParams($categoryName) 
    {
        $filter = new Kaltura_Client_Type_CategoryFilter();
        $filter->fullNameEqual = $categoryName;
        $cacheParams = Kms_Resource_Cache::buildCacheParams($filter);
        return $cacheParams;
    }
    
    
    /**
     * get a list of categories by the given filter
     * @param Kaltura_Client_Type_CategoryFilter $filter
     * @param Kaltura_Client_Type_FilterPager $pager
     * @param boolean $getModules	should modules list interface be triggered
     * @return array with categories matching the given data
     */
    public function getListByFilter(Kaltura_Client_Type_CategoryFilter $filter, Kaltura_Client_Type_FilterPager $pager = null, $getModules = true)
    {
        // execute the modules implementing "Kms_Interface_Model_Category_ListFilter" for catgeory
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_ListFilter');
        foreach ($models as $model)
        {
            $filter = $model->modifyFilter($filter);
        }

        $cacheParams = Kms_Resource_Cache::buildCacheParams($filter, $pager);
        $identity = Zend_Auth::getInstance()->getIdentity();
        $userRole = null;
                
        if($identity)
        {
            $userRole = $identity->getRole();
            $userId = Kms_Plugin_Access::getId();
            $cacheParams['userId'] = $userId;
            $cacheTags = array( 'categoryUser_' . $userId, 'categories');
        }
        
        if(!$results = Kms_Resource_Cache::apiGet('categories', $cacheParams))
        {
            $cats = array();
        
            $client = Kms_Resource_Client::getUserClient();
            try
            {
                $results = $client->category->listAction($filter, $pager);
                if (isset($results->objects) && count($results->objects))
                {
                    $cParams['userId'] = $userId;
                    foreach($results->objects as $obj)
                    {
                        $this->safeStrings($obj);
                        // only keep cache tags if the category will be included in the result set
                        if($this->isCategoryAllowed($obj, $userRole))
                        {
                            $cacheTags[] = 'categoryId_' . $obj->id;
                            $cacheTags[$obj->parentId] = 'categoryId_' .$obj->parentId;
                        	// need to add category membership before caching the category!! (getById assumes it is there)
                            $obj->membership = $this->getMembership($obj);
                        }
                        $cParams['categoryId'] = $obj->id; 
                        // cache each category by id (used in getById)
                        Kms_Resource_Cache::apiSet('category', $cParams, $obj, array('categoryId_' . $obj->id));
                    }
                }
                elseif (!empty($filter->fullNameStartsWith) && Kms_Resource_Cache::isEnabled())
                {
                    // generate the tags so the cache will be cleaned when the first category is created
                    // called only if the cache is enabled because it involves an api call
                    $cacheTags[] = 'categoryId_' . $this->getParentCategoryId(chop($filter->fullNameStartsWith,'>'));
                }
                                
                Kms_Resource_Cache::apiSet('categories', $cacheParams, $results, $cacheTags);
            }
            catch(Kaltura_Client_Exception $e)
            {
                Kms_Log::log('category: Error fetching category list from API: '.$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
                //throw new Zend_Exception($e->getMessage(), $e->getCode());
            }
        }
        
        // set the total result count for this request
        $this->totalcount = isset($results->totalCount) ? $results->totalCount : 0;

        // check if categories allowed
        $cats = array();
        if (isset($results->objects) && count($results->objects))
        { 
            foreach($results->objects as $obj)
            {
                if($this->isCategoryAllowed($obj, $userRole))
                {
                    $cats[$obj->id] = $obj;
                }
            }
        }
        
        $this->Categories = $cats;

        if ($getModules) {
	        // execute the modules implementing "Kms_Interface_Model_Category_List" for catgeory
	        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_List');
	        foreach ($models as $model)
	        {
	            $model->listAction($this);
	        }
        }
        return $cats;
    }
    
    /**
     *  return true if user has a permission to view a category(gallery/channel)
     * 
     *  @param string $catId the category id of the channel/gallery
     *  @return boolean
     */
	public function isUserAllowedViewingCategory($catId)
    {
    	$role = Kms_Plugin_Access::getCurrentRole();
    	
    	//gets the category 
    	$category = $this->get('',false,$catId);

    	// in case the category is open
        if ($category && $category->membership == self::MEMBERSHIP_OPEN)
    	{
    		if ($this->isCategoryAChannel($category))
    			//only if you have viewer role and above
    			return (Kms_Plugin_Access::isRoleInherit(Kms_Plugin_Access::VIEWER_ROLE,$role));
    		else
    			//only if you have anonymous role and above
    			return true;
    				
    	}
    	
    	// in case the category is restricted
        else if ($category && $category->membership == self::MEMBERSHIP_RESTRICTED)
    	{
    		//only if you have viewer role and above
    		if (Kms_Plugin_Access::isRoleInherit(Kms_Plugin_Access::VIEWER_ROLE,$role))
    			return true;	
    	}
    	
    	//in case the category is private and unlisted it means that we are members in this category
        else if ($category && $category->membership == self::MEMBERSHIP_PRIVATE &&
    			$category->appearInList == Kaltura_Client_Enum_AppearInListType::CATEGORY_MEMBERS_ONLY)
    	{
    		return true;
    	}
    	
        //in case the category is private and listed(!!) or is a shared repository - then we must check if we are members on this category or not
        else if ($category && $category->membership == self::MEMBERSHIP_PRIVATE)
    	{	
            return $this->isUserInCategory($catId);
    	}

    	//if the category is empty so we are not allowed to view this category
    	else if (!$category)
    		return false;

    	return false;
    }

    protected function isUserInCategory($catId)
    {
        $permissions = array(
	                        Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER,
	                        Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR,
	                        Kaltura_Client_Enum_CategoryUserPermissionLevel::MEMBER,
	                        Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR);

        $filter = new Kaltura_Client_Type_CategoryUserFilter();
        $filter->userIdEqual = Kms_Plugin_Access::getId();
        $filter->permissionLevelIn = implode(',',$permissions);
        $filter->categoryIdEqual = $catId;

        // get the category user objects
        $category = $this->getCategoryUserList($filter);

        if (!empty($category)){
	        return true;
        }
	    else{
	        return false;
	    }
    }

    public function isTopLevelCategory($catId)
    {
    	$str = str_replace(Kms_Resource_Config::getRootGalleriesCategoryfullId() . '>', '', $catId);
    	if (strpos($str, '>') === false)
    	{
    		return true;
    	}
    	else
    		return false;
    }
    

    /**
     *  get the categories relevant for publishing - under the root category
     * 
     *  @param $rootCategoryFullId - the root category full id - channels/galleries
     *  @return array of categories
     */
    public function getCategoriesForPublish($rootCategoryFullId, $userContextual = Kms_Plugin_Access::ADMIN_ROLE, $keyword="")
    {
        $categories = array();

        if(!empty($rootCategoryFullId))
        {
        	$pager = new Kaltura_Client_Type_FilterPager();
	        $pager->pageSize = self::CATEGORY_PUBLISH_PAGE_SIZE; 
        	
	        if (Kms_Plugin_Access::isAdminPermission($userContextual))
        	{
	            // get all the open categories
	            $filter = new Kaltura_Client_Type_CategoryFilter();
	            $filter->contributionPolicyEqual = Kaltura_Client_Enum_ContributionPolicyType::ALL;
	            $filter->fullIdsStartsWith = $rootCategoryFullId .'>';	             
	            
	            if ($keyword)
	            	$filter->freeText = $keyword;
	            
	            $categories = $this->getListByFilter($filter);
        	}

            // get the categories the user is manager/moderator/contributor of
            $filter = new Kaltura_Client_Type_CategoryUserFilter();
            $filter->userIdEqual = Kms_Plugin_Access::getId();
            $filter->categoryFullIdsStartsWith = $rootCategoryFullId .'>';
                        
            $permissions = array(
                        Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER,
                        Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR,
                        Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR);
            $filter->permissionLevelIn = implode(',',$permissions);
                                    
            // get the category user objects
            $cateoryIds = array();            
            $myCategories = $this->getCategoryUserList($filter , array('pagesize' => self::CATEGORY_PUBLISH_PAGE_SIZE));

            foreach ($myCategories as $category){
                $cateoryIds[] = $category->categoryId;
            }
            
            if (count($cateoryIds)){
                $filter = new Kaltura_Client_Type_CategoryFilter();
                //$filter->idIn = implode(',', $cateoryIds);
                $filter->idOrInheritedParentIdIn = implode(',', $cateoryIds);
                if ($keyword)
	            	$filter->freeText = $keyword;

                // get the actual categories
                $myCategories =  $this->getListByFilter($filter, $pager);   
            }

            // merge the category lists
            $categories += array_diff_key($myCategories,$categories);   
        }

        return $categories;
    }
    
 	/**
 	 * checks if the currect user is allowed to publish to any category or channel
 	 * @return boolean
 	 */
 	public function hasPermissionOnCategories()
    {
    	static $result;
    	
    	if (empty($result)) {
    		
    		if (!Kms_Plugin_Access::isRoleInherit(Kms_Plugin_Access::PRIVATE_ROLE, Kms_Plugin_Access::getCurrentRole()))
    		{
    			//no permission on categories at all
    			$result="false";
    		}
    		else
    		{
    			$client = Kms_Resource_Client::getAdminClient();
    			$client->startMultiRequest();
    				
    			$pager = new Kaltura_Client_Type_FilterPager();
    			$pager->pageSize = 1;

    			// get all the open categories
    			$filter = new Kaltura_Client_Type_CategoryFilter();
    			//if the user has private role, he has permissions on galleries only if he is set as contributor on them
    			if (Kms_Plugin_Access::getCurrentRole() == Kms_Plugin_Access::PRIVATE_ROLE)
    			{
    				$filter->fullIdsStartsWith = Kms_Resource_Config::getRootChannelsCategoryFullId() . '>';
    			}
    			else {
    				$filter->fullIdsStartsWith = Kms_Resource_Config::getRootGalleriesCategoryFullId() . '>,' . Kms_Resource_Config::getRootChannelsCategoryFullId() . '>';
    			}
    			$filter->contributionPolicyEqual = Kaltura_Client_Enum_ContributionPolicyType::ALL;
    			$client->category->listAction($filter,$pager);
    			// get KMS categories to which this user can add content
    			$filter = new Kaltura_Client_Type_CategoryUserFilter();
    			$filter->userIdEqual = Kms_Plugin_Access::getId();
    			$filter->categoryFullIdsStartsWith = Kms_Resource_Config::getRootGalleriesCategoryFullId() . '>';
    			$permissions = array(
    					Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER,
    					Kaltura_Client_Enum_CategoryUserPermissionLevel::CONTRIBUTOR,
    					Kaltura_Client_Enum_CategoryUserPermissionLevel::MODERATOR);
    			$filter->permissionLevelIn = implode(',',$permissions);
    			$client->categoryUser->listAction($filter,$pager);
    				
    			$filter->categoryFullIdsStartsWith = Kms_Resource_Config::getRootChannelsCategoryFullId() . '>';
    			$client->categoryUser->listAction($filter,$pager);
    				
    				
    			try {
    				$response = $client->doMultiRequest();
    				foreach ($response as $object) {
    					if ($object instanceof Kaltura_Client_Exception)
    					{
    						Kms_Log::log('permission on category: ' .$object->getCode().': '.$object->getMessage(), Kms_Log::WARN);
    						$result = "false";
    					}
    				}
    				if (count($response[0]->objects)>0 || count($response[1]->objects)>0 || count($response[2]->objects)>0)
    					$result = "true";
    				else
    					$result = "false";
    					
    			}
    			catch (Kaltura_Client_Exception $e) {
    				Kms_Log::log('permission on category: ' .$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
    				$result = "false";
    			}
    		}
    	}
    	return $result == "true";
    }


    
    /**
     * is category not restricted in KMS-admin
     * @param unknown_type $catObj KalturaCategory object
     * @param unknown_type $userRole user applicative role
     * @return boolean
     */
    public function isCategoryAllowed($catObj, $userRole)
    {
        // retreive the root category
        $rootCategory = Kms_Resource_Config::getRootGalleriesCategory();
        // get list of restricted categories and the roles, from the configuration
        $restrictedCategories = Kms_Resource_Config::getConfiguration('categories', 'restricted');
        // the category's "full name" starting from mediaspace galleries root
        $categoryLocalName = str_replace($rootCategory.'>', '', $catObj->fullName);
        // iterate over the restricted categories
        if(count($restrictedCategories))
        {
            foreach($restrictedCategories as $restrictedCat)
            {
                if($restrictedCat->category == $categoryLocalName || preg_match('/^'.preg_quote($restrictedCat->category, '/').'>.*/', $categoryLocalName))
                {
                    // the role can use this category
                    if($userRole == Kms_Plugin_Access::PARTNER_ROLE || !isset($restrictedCat->roles) || !count($restrictedCat->roles) || in_array($userRole, $restrictedCat->roles->toArray()))
                    {        
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        
        return true;
    }
    
    /**
     * save the category
     * @param array $data
     * @param unknown_type $admin
     * @param string $parentCategory - the parent category name
     * @return Kaltura_Client_Type_Category the saved category
     */
    public function save(array $data, $admin = false, $parentCategory = null)
    {                
        $client = Kms_Resource_Client::getAdminClient();
        
        // set the data
        $category = new Kaltura_Client_Type_Category();
        if (!empty($data['name']))			$category->name = $data['name'];
        if (!empty($data['description']) || (isset($data['description']) && $data['description']=="")) 	$category->description = $data['description'];
        if (!empty($data['tags']) || (isset($data['tags']) && $data['tags']=="")) 			$category->tags = $data['tags'];
        if (isset($data['referenceId']))	$category->referenceId = $data['referenceId'];
        if (isset($data['moderation'])) 	$category->moderation = $data['moderation'];
        
        $privacyContext = Kms_Resource_Config::getCategoryContext();
        if (!empty($privacyContext)) {
        	// the following attributes cannot be set without privacyContext:
	        if (!empty($data['membership'])) 	$category = $this->setMembership($category, $data['membership']); 	// privacyContext required
	        if (!empty($data['inheritance']))	$category->inheritanceType = $data['inheritance'];					// privacyContext required
	        if (isset($data['defaultPermissionLevel']))	$category->defaultPermissionLevel = $data['defaultPermissionLevel'];	// privacyContext required
	        if (!empty($data['owner'])) 		$category->owner = $data['owner'];									// privacyContext required
        }

        // save the category
        if (isset($data['id']) && $data['id'] != 0)
        {
            // existing category - update
            $category->id = $data['id'];
            try {
                $category = $client->category->update($data['id'], $category);
                
                // invalidate the caches
                Kms_Resource_Cache::apiClean('category', array('id' => $data['id']));
                Kms_Resource_Cache::apiClean('categories', array(''), array('categoryId_'.$data['id'], 'categoryId_'.$category->parentId));
            }
            catch (Kaltura_Client_Exception $e){
                Kms_Log::log('category: Error updating category id: ' . $data['id'] . ' ' .$e->getCode().': '.$e->getMessage(), Kms_Log::ERR);
                throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
            }
        }
        else{
            // new category - add      
            $category->parentId = $this->getParentCategoryId($parentCategory);
            
            //$category->owner = Kms_Plugin_Access::getId();                        
            try {
                $category = $client->category->add($category);
                // invalidate the categories cache by the parent id
                Kms_Resource_Cache::apiClean('categories', array(''), array('categoryId_'.$category->parentId));
            }
            catch (Kaltura_Client_Exception $e){
                Kms_Log::log('category: Error adding category to: ' . $category->parentId . ' ' .$e->getCode().': '.$e->getMessage(), Kms_Log::ERR);
                throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
            }
        }
        
        $this->Category = $category;
        
        // invoke modules save hooks
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_Save');
        foreach ($models as $model)
        {
            $model->save($this, $data);
        }
        
        return $this->Category;
    }
    
    
    /**
     * deletes a category
     * @param string $id - the category id. Not Name.
     */
    public function delete($categoryName = null, $categoryId = '')
    {
        $category = $this->getById($categoryId);
        if (!empty($category))
        {
            $this->deleteCategory($category);
        }
        else
        {
            Kms_Log::log('category: category was already deleted. id = ' . $categoryId, Kms_Log::WARN);
        }
    }
    
    /**
     * deletes a given category and cleans its cache.
     * we need the entire category object to clean the cache of itself and its parent.
     * @param Kaltura_Client_Type_Category $category 
     * @throws Kaltura_Client_Exception
     */
    protected function deleteCategory(Kaltura_Client_Type_Category $category)
    {        
        $client = Kms_Resource_Client::getAdminClient();
    

        // invoke modules save hooks
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_Delete');
        foreach ($models as $model)
        {
            $model->delete($this);
        }

        try
        {
            // delete the category with the flag set NOT to move its entries up the tree.
            $client->category->delete($category->id, Kaltura_Client_Enum_NullableBoolean::FALSE_VALUE);
        }
        catch (Kaltura_Client_Exception $e)
        {
            if ($e->getCode() == 'CATEGORY_NOT_FOUND'){
                // this is fine. just log.
                Kms_Log::log('category: category was already deleted. ' .$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
            }
            else{
                Kms_Log::log('category: Failed to delete category ' .$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
                throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
            }
        }        
        
        // clean the cache
        $caheTags = array('categoryId_' . $category->id, 'categoryUser_' . Kms_Plugin_Access::getId());
        if (!empty($category) && !empty($category->parentId)){
            // clean the cache of the parent category - this will clean all the pages of list actions
            $caheTags[] = 'categoryId_' . $category->parentId;
        }
        Kms_Resource_Cache::apiClean('category', array(), $caheTags);
    }
    
    
    /**
     * get a category's id
     * @param string $categoryName - full name of the required category. 
     * 								if null, galleries root category will be used.
     * @return integer - the category id
     */
    public function getParentCategoryId($categoryName = null)
    {
        $categoryId = null;
        
        // determine the parent category name
        if (is_null($categoryName)) {
            // the default parent category
            $categoryName = Kms_Resource_Config::getRootGalleriesCategory();
        }
        
        // get the parent category id - we always use the full path here
        $category = $this->get($categoryName, true);
        
        if( isset($category->id)) {
            $categoryId = $category->id;
        }
        
        return $categoryId;
    }

    
    /**
     * calculates the category membership according to privacy, contributor membership
     * @param Kaltura_Client_Type_Category $category - the category to check
     * @return string
     */
    protected function getMembership(Kaltura_Client_Type_Category $category)
    {
        $result = self::MEMBERSHIP_PRIVATE;
    
        if ($category->privacy == Kaltura_Client_Enum_PrivacyType::MEMBERS_ONLY){
            // private
            $result = self::MEMBERSHIP_PRIVATE;
        }
        else if ($category->contributionPolicy == Kaltura_Client_Enum_ContributionPolicyType::MEMBERS_WITH_CONTRIBUTION_PERMISSION){
            // restricted
            $result = self::MEMBERSHIP_RESTRICTED;
        }
        else{
            // open
            $result = self::MEMBERSHIP_OPEN;
        }
        return $result;
    }
    
    /**
     * set the category attributes according to membership
     * @param Kaltura_Client_Type_Category &$category
     * @param int $membership
     */
    protected function setMembership(Kaltura_Client_Type_Category &$category, $membership)
    {
        switch($membership)
        {
            case self::MEMBERSHIP_OPEN:
                $this->setOpenMembership($category);
                break;
            case self::MEMBERSHIP_RESTRICTED:
                $this->setRestrictedMembership($category);
                break;
            case self::MEMBERSHIP_PRIVATE:
                $this->setPrivateMembership($category);
                break;
        }
        return $category;
    }

    /**
     * the default open membership - same as channel, not gallery.
     */
    protected function setOpenMembership(Kaltura_Client_Type_Category &$category)
    {
        $category->privacy = Kaltura_Client_Enum_PrivacyType::AUTHENTICATED_USERS;        // view
        $category->contributionPolicy = Kaltura_Client_Enum_ContributionPolicyType::ALL;  // contrib
        $category->appearInList = Kaltura_Client_Enum_AppearInListType::PARTNER_ONLY;     // list
    }
    
    /**
     * default restricted membership.
     */
    protected function setRestrictedMembership(Kaltura_Client_Type_Category &$category)
    {
        $category->privacy = Kaltura_Client_Enum_PrivacyType::AUTHENTICATED_USERS;
        $category->contributionPolicy = Kaltura_Client_Enum_ContributionPolicyType::MEMBERS_WITH_CONTRIBUTION_PERMISSION;
        $category->appearInList = Kaltura_Client_Enum_AppearInListType::PARTNER_ONLY;
    }

    /**
     * default private membership
     */
    protected function setPrivateMembership(Kaltura_Client_Type_Category &$category)
    {
        $category->privacy = Kaltura_Client_Enum_PrivacyType::MEMBERS_ONLY;
        $category->contributionPolicy = Kaltura_Client_Enum_ContributionPolicyType::MEMBERS_WITH_CONTRIBUTION_PERMISSION;
        $category->appearInList = Kaltura_Client_Enum_AppearInListType::CATEGORY_MEMBERS_ONLY;   
    }

    /**
     * get the user role associated with a category.
     * first search by category id, then by category name.
     * @param string $categoryName
     * @param string $userId
     * @param string $categoryId
     * @return integer the role
     */
    public function getUserRoleInCategory($categoryName, $userId, $categoryId = '')
    {    
        // we use a static member because this method can be called several times with the same parameters
        static $rolesByName;
        static $rolesById;
        
        $result = null;
        if (!empty($categoryId) && isset($rolesById[$categoryId]) && isset($rolesById[$categoryId][$userId])) {
	        $result = $rolesById[$categoryId][$userId];
        }
        
        if (is_null($result) && isset($rolesByName[$categoryName]) ) {
	        $result = $rolesByName[$categoryName][$userId];
        }
        
        if (is_null($result))
        {
            Kms_Log::log('category: getting user role for category ' . $categoryName  . ' user ' . $userId, Kms_Log::DEBUG);

            $role = self::CATEGORY_USER_NO_ROLE;
            if (empty($categoryId)) {
	            // get the category itself - need it for its id
            	$category = $this->get($categoryName, false, $categoryId);
            	if (!empty($category)) {
	            	$categoryId = $category->id;
	            	$categoryName = $category->name;
            	}
            }
            
            if (!empty($categoryId)) {            
                // we have access to this channel - check what role
                $client = Kms_Resource_Client::getUserClient();
                try {
                    $categoryUser = $client->categoryUser->get($categoryId, $userId);
                    $role = $categoryUser->permissionLevel;
                    
                    Kms_Log::log('category: role for category ' . $categoryId  . ' user ' . $userId . ' role ' . $role , Kms_Log::DEBUG);
                }
                catch (Kaltura_Client_Exception $e){
                    Kms_Log::log('category: No user role for category ' . $categoryName .  ' user ' . $userId .', ' . $e->getCode() . ': ' . $e->getMessage(), Kms_Log::DEBUG);
                    // no role / error - do noting. just return null.
                }
                // allow modules to override
	            $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Category_Role');
		        foreach ($models as $model)
		        {
		            $role = $model->getContextualUserRole($this, $role, $categoryName , $userId, $categoryId);
		        }
	        
	            $rolesById[$categoryId][$userId] = $role;
	            $rolesByName[$categoryName][$userId] = $role;
                $result = $role;
            }
        }
        return (integer)$result;
    }
    
    /**
     * get the total result count
     * @return number
     */
    public function getTotalCount()
    {
        return $this->totalcount;
    }
    
    /**
     * set the total result count
     * @param number $count
     */
    protected function setTotalCount($count)
    {
        $this->totalcount = $count;
    }
    
    /**
     * allow modules using model hooks to keep and access data on the model
     * @param string $moduleName
     */
    public function getModuleData($moduleName)
    {
        return isset($this->modules[$moduleName]) ? $this->modules[$moduleName] : NULL;
    }
    
    /**
     * allow modules using model hooks to keep and access data on the model
     * @param unknown_type $data
     * @param string $moduleName
     */
    public function setModuleData($data, $moduleName)
    {
        $this->modules[$moduleName] = $data;
    }
    
    /**
     * get the current category from the model - or retreive it from the api
     * @param string $catName - the category name
     * @param string $catId - the category id
     * @return Kaltura_Client_Type_Category, NULL
     */
    public function getCurrent($catName = '', $catId = null)
    {
    	$category = null;
        
        // get the current copy of the category
        if (!empty($this->Category)) {
	        if (!empty($catId) && $this->Category->id == $catId) {
	            $category = $this->Category;
	        }
	        elseif ($this->Category->name == $catName) {
	        	$category = $this->Category;
	        }
        }
        
        // fetch the category from the api
        if (is_null($category)) {
            $category = $this->get($catName, false, $catId);
        }
        
        return $category;
    }
    
    
    /**
     * checks if the given category object is a channel or a gallery
     * @param Kaltura_Client_Type_Category $category
     * @return boolean true if channel, false otherwise
     */
    public function isCategoryAChannel(Kaltura_Client_Type_Category $category) {
    	$result = false;
    	$rootCat = Kms_Resource_Config::getRootChannelsCategory();
	    $rootCatLen = strlen($rootCat);
        if (substr($category->fullName, 0, $rootCatLen) == $rootCat)
        {
          	$result = true;
        }
        return $result;
    } 
    
    public function isExists($name = null, $absolutePath = false){
         // gallery root
        $rootGalleryCategory = Kms_Resource_Config::getRootGalleriesCategory();
        $client = Kms_Resource_Client::getAdminClientNoEntitlement();
        $filter = new Kaltura_Client_Type_CategoryFilter();
        if($absolutePath || preg_match('/^' . preg_quote($rootGalleryCategory, '/') . '>/', $name)) {
            // get from absolute mediaspace root
            $filter->fullNameEqual = $name;
        }
        else {
            $filter->fullNameEqual = $rootGalleryCategory.'>'.$name;
        }
        try{
            $category = $client->category->listAction($filter);
            if(isset($category->objects) && count($category->objects)) 
                return true;
        }
        catch(Kaltura_Client_Exception $e) {
            Kms_Log::log('category: Failed to get category '.$name.'. '.$e->getCode().': '.$e->getMessage(), Kms_Log::WARN);
            throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
        }
        return false;
    }
    
    /**
     * set the channel details metadata
     * This method is not in use. kept for use in near future
     * @param Kaltura_Client_Type_Category $channel
     * @param array $data
     */
    public function setCategoryAdditionalInfo(Kaltura_Client_Type_Category $category, $key, $value)
    {
    	$profileId = Kms_Resource_Config::getConfiguration('categories', 'categoryAdditionalInfoProfileId');
    
    	if (!empty($category) && !empty($profileId))
    	{
    		$metadata = $this->getCategoryMetadata($profileId, $category->id);
    		if (!empty($metadata) && !empty($metadata->objects))
    		{
    			try {
    				$metadataObject = $metadata->objects[0];
    				$xmlObj = new SimpleXMLElement($metadataObject->xml);
    					
    				$xmlKeys = $xmlObj->xpath(self::METADATA_ADDITIONAL_INFO_KEY_PATH);
    				
    				$found = false;
    				foreach ($xmlKeys as $obj)
    				{
    					if ((string)$obj->Key == $key)
    					{
    						$found = true;
    						$obj->Value = $value;
    						break;
    					}
    				}
    				if (!$found)
    				{
    					$xmlObj = new SimpleXMLElement($metadataObject->xml);
						$detail = $xmlObj->addChild('Detail');
    					$detail->addChild('Key', $key);
    					$detail->addChild('Value', $value);
    				}
    				$this->setCategoryMetadata($profileId, $category->id, $xmlObj);
    			}
    			catch (Exception $ex){
    				Kms_Log::log('Category: Failed parsing category additional info customdata for channel Ids ' . $category->id . ', ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::WARN);
    				throw new Exception($ex->getMessage(), $ex->getCode());
    			}
    		}
    		else {
    			$metadata = new SimpleXMLElement('<metadata/>');
    			//$newObj = new SimpleXMLElement($metadata->objects[0]->xml);
    			$detail = $metadata->addChild('Detail');
    			$detail->addChild('Key', $key);
    			$detail->addChild('Value', $value);
    			$this->setCategoryMetadata($profileId, $category->id, $metadata);
    		}
    
    		// clean the cache
    		$cacheParams = array('profileId' => $profileId, 'categoryId' => $category->id);
    		Kms_Resource_Cache::appClean('categoryAdditionalInfo', $cacheParams);
    	}
    	else
    	{
    		if (empty($profileId)){
    			Kms_Log::log('channel: categoryAdditionalInfoProfileId not configured' , Kms_Log::ERR);
    		}
    		elseif (empty($category)){
    			Kms_Log::log('channel: empty channel given' , Kms_Log::ERR);
    		}
    	}
    }
    
    public function getCategoryAdditionalInfo(Kaltura_Client_Type_Category $category, $key = null)
    {
        // we always return an array
        $details = array();
        $profileId = Kms_Resource_Config::getConfiguration('categories', 'categoryAdditionalInfoProfileId');
        
        if (!empty($category) && !empty($profileId))
        {
            $cacheParams = array('profileId' => $profileId, 'categoryId' => $category->id);
        
            $details = Kms_Resource_Cache::appGet('categoryAdditionalInfo', $cacheParams);
            if (!$details)
            {
                // get the metadata from the api
                $metadata = $this->getCategoryMetadata($profileId, $category->id);
        
                // parse the metadata
                if (!empty($metadata) && !empty($metadata->objects))
                {
                    try {
                        $metadataObject = $metadata->objects[0];
                       
                        $xmlObj = new SimpleXMLElement($metadataObject->xml); 
                       
                        $xmlKeys = $xmlObj->xpath(self::METADATA_ADDITIONAL_INFO_KEY_PATH);
                        
                        foreach ($xmlKeys as $obj)
                        {
                        	$details[(string)$obj->Key] = (string)$obj->Value;
                        }
                    }
                    catch (Exception $ex){
                        Kms_Log::log('Category: Failed parsing category addtional info customdata for channel Ids ' . $category->id . ', ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::WARN);
                        throw new Exception($ex->getMessage(), $ex->getCode());
                    }
                }
                else $details = array();
        
                // update the cache
                Kms_Resource_Cache::appSet('categoryAdditionalInfo', $cacheParams, $details);
            }
        }
        else
        {
            if (empty($profileId)){
                Kms_Log::log('category: categoryAdditionalInfoProfileId not configured' , Kms_Log::ERR);
            }
            elseif (empty($category)){
                Kms_Log::log('category: empty channel given' , Kms_Log::ERR);
            }
        }
       
        if (isset($key))
        {
        	if (isset($details) && array_key_exists($key, $details))
        	{
        	   	return $details[$key];
        	}
        	return null;
        }
        
        return $details;
    }
    
    
    /**
     * get the channel/s metadata from the api
     * @param unknown_type $profileId
     * @throws Kaltura_Client_Exception
     */
    private function getCategoryMetadata($profileId, $categoryIds)
    {
    	$metadata = array();
    	 
    	if (!empty($profileId))
    	{
    		// get the metadata from the api
    		$filter = new Kaltura_Client_Metadata_Type_MetadataFilter();
    		$filter->objectIdIn = $categoryIds;
    		$filter->metadataProfileIdEqual = $profileId;
    		$filter->metadataObjectTypeEqual = Kaltura_Client_Metadata_Enum_MetadataObjectType::CATEGORY;
    
    		$client = Kms_Resource_Client::getAdminClient();
    		$metadataPlugin = Kaltura_Client_Metadata_Plugin::get($client);
    
    		try {
    			$metadata = $metadataPlugin->metadata->listAction($filter);
    
    			// test that we got the object from the correct profile
    			if (!empty($metadata->objects) && count($metadata->objects)){
    				if ($metadata->objects[0]->metadataProfileId != $profileId){
    					Kms_Log::log('channel: Got wrong customdata for channel Ids ' . $categoryIds . ' profileId ' . $profileId, Kms_Log::ERR);
    					$metadata = array();
    				}
    			}
    		}
    		catch (Kaltura_Client_Exception $e)
    		{
    			Kms_Log::log('channel: Failed getting customdata for channel Ids ' . $categoryIds . ', ' . $e->getCode() . ': ' . $e->getMessage(), Kms_Log::WARN);
    			throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
    		}
    	}
    	else
    	{
    		Kms_Log::log('channel: Empty profileId ' . $profileId, Kms_Log::ERR);
    	}
    
    	return $metadata;
    }
    
    /**
     * set the channel metadata in the api
     * @param string $profileId
     * @param string $channelId
     * @param SimpleXMLElement $customDataXML
     * @throws Kaltura_Client_Exception
     */
    private function setCategoryMetadata($profileId, $categoryId, SimpleXMLElement $customDataXML)
    {
    	if (!empty($profileId))
    	{
    		$client = Kms_Resource_Client::getAdminClient();
    		$metadataPlugin = Kaltura_Client_Metadata_Plugin::get($client);
    
    		// get the current metadata from the matadata api
    		$metadata = $this->getCategoryMetadata($profileId, $categoryId);
    		
    		if (!empty($metadata->objects) && count($metadata->objects))
    		{
    			// existing metadata - update metadata
    			try {
    				$customdataId = $metadata->objects[0]->id;
    				$metadataPlugin->metadata->update($customdataId, $customDataXML->asXML());
    			}
    			catch (Kaltura_Client_Exception $e)
    			{
    				Kms_Log::log('channel: Failed updating customdata for channel Id ' . $categoryId . ', profileId ' . $profileId . ', ' . $e->getCode() . ': ' . $e->getMessage() . '; xml: ' . $customDataXML->asXML(), Kms_Log::ERR);
    				throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
    			}
    		}
    		else{
    			// no metadata - add new metadata
    			try {
    				$metadataPlugin->metadata->add($profileId,Kaltura_Client_Metadata_Enum_MetadataObjectType::CATEGORY, $categoryId, $customDataXML->asXML());
    			}
    			catch (Kaltura_Client_Exception $e)
    			{
    				Kms_Log::log('channel: Failed adding thumbnail for category Id ' . $categoryId . ', profileId ' . $profileId . ', ' . $e->getCode() . ': ' . $e->getMessage() . '; xml: ' . $customDataXML->asXML(), Kms_Log::ERR);
    				throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
    			}
    		}
    	}
    	else
    	{
    		Kms_Log::log('category: Empty profileId ' . $profileId, Kms_Log::ERR);
    	}
    }
    
    
    /**
     * validate category info before save.
     * use this method to validate stuff that require API calls
     * @param Kaltura_Client_Type_Category $category
     */
    public function validateCategoryForSave(Kaltura_Client_Type_Category $category, array $data) {
    	$result = true;
	    // 1. see if category with same full name exists:
    	if (!empty($data['name']) && strtolower($data['name']) != strtolower($category->name)) {
	    	// required full name
	    	$fullName = implode('>', explode('>', $category->fullName, -1));
	    	$fullName .= '>' . $data['name']; 
	    	$results = null;
			$filter = new Kaltura_Client_Type_CategoryFilter();
			$filter->fullNameEqual = $fullName;
			$client = Kms_Resource_Client::getAdminClientNoEntitlement();
			try {
				$results = $client->category->listAction($filter, null);
			}
			catch (Kaltura_Client_Exception $e)
	    	{
	    		Kms_Log::log('category: failed getting categories with same full name.', Kms_Log::ERR);
	    	}
	    	
			if (!empty($results) && $results->totalCount > 0) {
				 $result = false;
			}
    	}
		return $result;
    }
}

