<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 *  Gallery Model
 */
class Application_Model_Gallery extends Application_Model_Category
{

    /**
     * get a single gallery by its name or id.
     * @param string $name - the name of the category.
     * @param boolean
     * @param string category id
     * @throws Kaltura_Client_Exception
     * @return Ambigous <boolean, unknown>
     */
    public function get($name = null, $absolutePath = false, $id = null)
    {        
        $fullPath = $name;
        if (!$absolutePath){
            $fullPath = Kms_Resource_Config::getRootGalleriesCategory().'>'.$name;
        }
        
        $this->Category = parent::get($fullPath, true, $id);
            
        // call Kms_Interface_Model_Channel_Get
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Gallery_Get');
        foreach ($models as $model)
        {
            $model->get($this);
        }
        
        return $this->Category;
    }

    /**
     * get a list of galleries by the given filter
     * @param Kaltura_Client_Type_CategoryFilter $filter
     * @param Kaltura_Client_Type_FilterPager $pager
     * @return array with galleries matching the given data
     */
    public function getListByFilter(Kaltura_Client_Type_CategoryFilter $filter, Kaltura_Client_Type_FilterPager $pager = null, $getModules = true)
    {

        // execute the modules implementing "Kms_Interface_Model_Gallery_ListFilter" for catgeory
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Gallery_ListFilter');
        foreach ($models as $model)
        {
            $filter = $model->modifyFilter($filter);
        }

        $results = parent::getListByFilter($filter, $pager, $getModules);

        if ($getModules) {
	        // execute the modules implementing "Kms_Interface_Model_Gallery_List" for catgeory
	        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Gallery_List');
	        foreach ($models as $model)
	        {
	            $model->listAction($this);
	        }
        }
        return $results;
    }
    
/**
     * get a list of all the galleries
     * @param array $params the filter params
     * @param Kaltura_Client_Type_CategoryFilter $filter a filter to modify
     * @param Kaltura_Client_Type_FilterPager $pager the pager to use
     * @return Ambigous <boolean, unknown, multitype:unknown >
     */
    public function getGalleryList(array $params = array(), Kaltura_Client_Type_CategoryFilter $filter = null, Kaltura_Client_Type_FilterPager $pager = null)
    {        
        // construct the category filter
        $rootCategory = Kms_Resource_Config::getRootGalleriesCategory();
        if (is_null($pager)){    
            $pager = new Kaltura_Client_Type_FilterPager();
            $pager->pageIndex = 1;
            $pager->pageSize = Kms_Resource_Config::getConfiguration('gallery', 'pageSize');
        }
        
        if (is_null($filter)){
            $filter = new Kaltura_Client_Type_CategoryFilter();
        }
        $filter->fullNameStartsWith = $rootCategory . '>';

        if (!empty($params['page'])){
            $pager->pageIndex = $params['page'];
        }
        if (!empty($params['sort'])){
            switch ($params['sort'])
            {
                case 'date':
                    $filter->orderBy = Kaltura_Client_Enum_CategoryOrderBy::CREATED_AT_DESC;
                    break;
                case 'name':
                    $filter->orderBy = Kaltura_Client_Enum_CategoryOrderBy::NAME_ASC;
                    break;
                case 'members':
                    $filter->orderBy = Kaltura_Client_Enum_CategoryOrderBy::MEMBERS_COUNT_DESC;
                    break;
            }
        }
        if (!empty($params['keyword'])){
            $filter->freeText = $params['keyword'];
        }

        // get the channels
        $galleries =  $this->getListByFilter($filter, $pager);
        
        return $galleries;
    }

    /**
     *  get the galleries relevant for publish 
     * 
     *  @param $rootCategoryFullId - ignored
     *  @return array of galleries
     */
    public function getCategoriesForPublish($rootCategoryFullId = null, $userContextual = Kms_Plugin_Access::ADMIN_ROLE, $keyword="")
    {
        return parent::getCategoriesForPublish(Kms_Resource_Config::getRootGalleriesCategoryfullId(),Kms_Plugin_Access::getCurrentRole(), $keyword);
    }

    /**
     *  get all the galleries for navigation
     *  @param int $maxDepth
     *  @return array with matched galleries
     */
    public function getAllGalleries($maxDepth = null)
    {
        $filter = new Kaltura_Client_Type_CategoryFilter();
        // filtering for categories (i.e. navigation) - order by partner_sort_value
        $filter->orderBy = Kaltura_Client_Enum_CategoryOrderBy::NAME_ASC;
        $filter->fullNameStartsWith = Kms_Resource_Config::getRootGalleriesCategory() . '>';
        $filter->depthEqual = $maxDepth;
        
        return $this->getListByFilter($filter);
    }

    /**
     *  get all the galleries ready to show in config forms.
     *  @return array of galleries by name
     */ 
    public function getGalleriesForForm()
    {
        // get list of categories
        $categories = $this->getAllGalleries();
        
        // retreive the root category
        $rootCategory = Kms_Resource_Config::getRootGalleriesCategory();

        // get list of restricted categories and the roles, from the configuration
        $restrictedCategories = Kms_Resource_Config::getConfiguration('categories', 'restricted');
        
        // get the user role
        $auth = Zend_Auth::getInstance();
        if($auth->hasIdentity())
        {
            $userRole = $auth->getIdentity()->getRole();
        }
        else
        {
            $userRole = false;
        }
       
        // create an array of category names ordered by name
        $categoriesByName = array();
        if(is_array($categories))
        {
            foreach($categories as $category)
            {
                // remove the public category name from the beginning of the category
                $categoriesByName[ $category->id ] = str_replace($rootCategory.'>', '', $category->fullName);
            }
            // sort alphabetically, while maintaining the keys
            asort($categoriesByName);

            // run on all the categories
            foreach($categoriesByName as $catId => $category)
            {
                // check if category is restricted
                if(count($restrictedCategories))
                {
                    foreach($restrictedCategories as $restrictedCat)
                    {
                        if($restrictedCat->category == $category || preg_match('/^'.preg_quote($restrictedCat->category, '/').'>.*/', $category))
                        {
                            // the role can use this category
                            if($userRole != Kms_Plugin_Access::PARTNER_ROLE)
                            {
                                if(!isset($restrictedCat->roles) || count($restrictedCat->roles) || in_array($userRole, (array) $restrictedCat->roles))
                                {
                                    // role cannot use this category, we remove it from the list
                                    unset($categoriesByName[$catId]);
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
            }
        }
        return $categoriesByName;
    }

 	/**
     * get the user role associated with a gallery. 
     * @param string $galleryName
     * @param string $userId
     * @param string $galleryId
     * @return integer the role
     */
    public function getUserRoleInGallery($galleryName , $userId, $galleryId = '')
    {
    	$role = $this->getUserRoleInCategory($galleryName, $userId, $galleryId);
    	$models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Gallery_Role');
        foreach ($models as $model)
        {
            $role = $model->getContextualUserRole($this, $role, $galleryName , $userId, $galleryId = '');
        }
        return $role;
    }

    /**
     * gallery open membership is for all users
     */
    protected function setOpenMembership(Kaltura_Client_Type_Category &$category)
    {
        $category->privacy = Kaltura_Client_Enum_PrivacyType::ALL;                        // view
        $category->contributionPolicy = Kaltura_Client_Enum_ContributionPolicyType::ALL;  // contrib
        $category->appearInList = Kaltura_Client_Enum_AppearInListType::PARTNER_ONLY;     // list
    }
}