<?php

/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

class Application_Model_Entry
{

    const MY_MEDIA_PAGE_SIZE = 10;
    const MY_MEDIA_LIST_PAGE_SIZE = 20;
    
    public $id;
    public $entry = NULL;
    public $Entries;
    public $modules = array();
    private $models;
    public $pageSize = false;
    
    /**
     * are all current entry's required fields filled out?
     * */
    public $readyToPublish = true;
    /**
     * are all current entry's shared repository required fields filled out?
     * */
    public $readyToPublishToSharedRepository = true;
    
    private $_lastResultsTotal = 0;
    private $liked = NULL;
    
    private static $fetchedEntries = array();
    
    const MINIMUM_SEARCH_KEYWORD_LENGTH = 1;

    const METADATA_TERMS_OF_USE_KEY_PATH = "sharedRepository";

    function __construct()
    {
//        $this->entry = new Kaltura_Client_Type_BaseEntry();
    }

    private function createEntryCacheParams($entryId, $userId)
    {
    	return array('id' => $entryId, 'userId' => $userId);
    }
    private function setEntryCache($entry, $userId)
    {
        // save cache
        $cacheTags = array('entry_' . $entry->id, 'user_' . $userId);
        $entryModerated = $entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::AUTO_APPROVED || $entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::APPROVED;
        $entryReady = $entry->status == Kaltura_Client_Enum_EntryStatus::READY;
        // only save cache if entry is ready and approved moderation and all the fields are set
        if ($entryModerated && $entryReady) 
        {
            Kms_Resource_Cache::apiSet('entry', $this->createEntryCacheParams($entry->id, $userId), $entry, $cacheTags);
        }
    }
    /**
     *
     * @param string $id
     * @return Kaltura_Client_Type_BaseEntry
     */
    public function get($id, $getModules = true)
    {        
        $this->entry = NULL;
        
        // if already fetched entry in list (or in previous "get") - simply return it from static array to not initiate modules again
        if(isset(self::$fetchedEntries[$id]))
        {
            $this->entry = self::$fetchedEntries[$id];
            return self::$fetchedEntries[$id];
        }

        $client = Kms_Resource_Client::getUserClient();
        $userId = Kms_Plugin_Access::getId();
        // try to fetch entry from cache
        $this->entry = Kms_Resource_Cache::apiGet('entry', $this->createEntryCacheParams($id, $userId));
        
        if (!$this->entry)
        {   
        	try {   
            	$this->entry = $client->baseEntry->get($id);
        	} catch (Kaltura_Client_Exception $ex)
            {
                Kms_Log::log('entry: Error in baseEntry->get: ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
            }
            if(is_null($this->entry) || !$this->entry)
            {
                throw new Kaltura_Client_Exception("Cannot get entry from API", "ENTRY_ID_NOT_FOUND"); 
            }
            $this->safeStrings($this->entry);
            $this->setEntryCache($this->entry, $userId);
        }
                
        $this->id = $this->entry->id;
        // update the models plugin to include the entry
        Kms_Resource_Models::setEntry($this);
        
        // execute the modules implementing "get" for entry
        $this->models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_Get');

        if ($getModules)
        {
            foreach ($this->models as $model)
            {
                $model->get($this);
            }
        }

        $unlistedEntry = false;
        if (Kms_Resource_Config::isBooleanFieldTrue('application', 'enableUnlisted', false)) {
        	$unlistedEntry = $this->isEntryUnlisted($this->entry->id);
        }
        //entry can be accessed if it was created by the current user or it was published to one of the categories user is entitled to 
        if (!Kms_Plugin_Access::isCurrentUser($this->entry->userId) && !$this->isPublished($this->entry) && !$unlistedEntry)
        {
            throw new Kaltura_Client_Exception("Entry should be created by current user or user is not entitled to categories entry is published to", "ENTRY_ID_NOT_FOUND");
        }
        //if it is not an owner of entry check if it is within its scheduling window
        if (!Kms_Plugin_Access::isCurrentUser($this->entry->userId) && !self::checkScheduling($this->entry->startDate, $this->entry->endDate))
        {
        	throw new Kaltura_Client_Exception("Entry should be within its scheduling window", "ENTRY_ID_NOT_FOUND");
        }
        
        $entryPartnerId = $this->entry->partnerId;
        $currentPartnerId = Kms_Resource_Config::getConfiguration('client', 'partnerId');
        if ($entryPartnerId != $currentPartnerId)
        {
            throw new Kaltura_Client_Exception("Entry should be created in the same partner id", "ENTRY_ID_NOT_FOUND");
        }
        // check that all required fields have been filled
        $this->checkReadyToPublish();
        Kms_Resource_Models::setEntry($this);
        
        $this->updateFetchedEntries(array($this->entry));

        return $this->entry;
    }
    
    private function safeStrings(Kaltura_Client_Type_BaseEntry &$entry)
    {
        $entry->tags = Kms_Resource_Wysihtml::safeString($entry->tags);
        $entry->name = Kms_Resource_Wysihtml::safeString($entry->name);
        $entry->description = Kms_Resource_Wysihtml::safeString($entry->description);
    }
    
    public static function checkScheduling($startDate, $endDate) {
    	$now = time();
    	
		//if startDate exists and in future - false
    	if (!empty($startDate) && $startDate > $now)
    	{
    		return false;
    	}
    	//if endDate exists and in past - false
    	if (!empty($endDate) && $endDate < $now)
    	{
    		return false;
    	}
    	//otherwise
    	return true; 
             
    }

    /**
     * Check if entry is ok to publish
     * 
     */
    public function checkReadyToPublish()
    {
        $this->readyToPublish = true;
        $readyToPublish = true;
        $metadataConfig = Kms_Resource_Config::getSection('metadata');
        if ($metadataConfig)
        {
            // check description
            if (isset($metadataConfig->descriptionRequired) && $metadataConfig->descriptionRequired == "1")
            {
                $readyToPublish = isset($this->entry->description) && strlen(trim($this->entry->description));
            }

            // check tags
            if (isset($metadataConfig->tagsRequired) && $metadataConfig->tagsRequired == "1")
            {
                if (isset($this->entry->tags))
                {
                    $tags = Kms_View_Helper_String::removeAuthorNameFromTags($this->entry->tags);
                    if (!strlen($tags))
                    {
                        $readyToPublish = false;
                    }
                }
                else
                {
                    $readyToPublish = false;
                }
            }
        }
        $this->checkReadyToPublishToSharedRepository();
        // call on modules to modify "ready to publish" via interface
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_ReadyToPublish');
        foreach($models as $name => $model)
        {
            $moduleReady = $model->entryReadyToPublish($this);
            if($readyToPublish && $moduleReady === false)
            {
                $readyToPublish = false;
            }
        }
        $model = $this->getModelByEntryType($this->entry);
        if (isset($model))
        	$readyToPublish = $model->readyToPublish($this->entry, $readyToPublish);
        $this->readyToPublish = $readyToPublish;
        return $this->readyToPublish;
    }
    
    /**
     * Check if entry is ok to publish to shared repository
     *
     */
    private function checkReadyToPublishToSharedRepository()
    {
        $channelModel = Kms_Resource_Models::getChannel();
        if ($channelModel->isSharedRepositoriesEnabled()){
            $customdataProfileId = Kms_Resource_Config::getConfiguration('sharedRepositories', 'customDataProfileId');
            $requiredFields = Kms_Resource_Config::getConfiguration('sharedRepositories', 'requiredFields');
           $this->readyToPublishToSharedRepository =  Kms_Helper_Metadata::entryReadyToPublish($this, 'sharedRepositories', $customdataProfileId, $requiredFields);
        }
    }

    public function getReadyToPublishToSharedRepository()
    {
        return $this->readyToPublishToSharedRepository;
    }

    /**
     * Delete entry (entryId)
     * @param long $entryId 
     * @return boolean
     */
    public function delete($entryId)
    {
        $userId = Kms_Plugin_Access::getId();
        $client = Kms_Resource_Client::getUserClient();

        try
        {
            $client->baseEntry->delete($entryId);
            // invalidate the cache
            $cacheTags = array(
                'entry_' . $entryId,
                'user_' . $userId,
            );
            Kms_Resource_Cache::apiClean('entry', array('id' => $entryId), $cacheTags);
            Kms_Resource_Cache::apiClean('entries', array(''), $cacheTags);
            Kms_Resource_Cache::apiClean('like', array('id' => $entryId, 'userId' => $userId));

            return true;
        }
        catch (Kaltura_Client_Exception $e)
        {
            Kms_Log::log('entry: Entry delete failed. ' . $e->getCode() . ': ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete multiple entries by entryId, using multirequest
     * @param array $entries 
     * @return int
     */
    public function deleteMulti($entries)
    {
        // use user client because if user has no permission to delete, then we skip
        $userId = Kms_Plugin_Access::getId();
        $client = Kms_Resource_Client::getUserClient();

        // increase the client timeout to 60 sec
        $config = $client->getConfig();
        $config->curlTimeout = 60;
        $client->setConfig($config);


        if (is_array($entries) && count($entries))
        {
            if (count($entries) == 1) // only one entry, pass it on to the usual delete function
            {
                list($entryId) = $entries;
                return $this->delete($entryId);
            }
            else
            {
                $cacheTags = array(
                    'user_' . $userId,
                );
                Kms_Resource_Cache::apiClean('entries', array(''), $cacheTags);
                try
                {
                    $client->startMultiRequest();
                    foreach ($entries as $entryId)
                    {
                        $client->baseEntry->delete($entryId);
                        $cacheTags[] = 'entry_' . $entryId;
                        Kms_Resource_Cache::apiClean('like', array('id' => $entryId, 'userId' => $userId));
					}
					// invalidate the cache
                    Kms_Resource_Cache::apiClean('entry', array('id' => $entryId), $cacheTags);
                    					
                    $res = $client->doMultiRequest();
                    foreach($res as $obj)
                    	if ($obj instanceof Kaltura_Client_Exception)
                 			Kms_Log::log('entry: Entry delete failed. ' . $obj->getCode() . ': ' . $obj->getMessage(), Kms_Log::ERR);   		
                }
                catch (Exception $e)
                {
                }
                return count($entries);
            }
        }
    }

    /**
     * create a new entry from an upload token
     * 
     * @param string $name - the file name
     * @param string $token - the upload token
     * @return Kaltura_Client_Type_BaseEntry $entry.
     */    
    public function createEntryFromToken($name, $token)
    {
        $newEntry = NULL;
        $userId = Kms_Plugin_Access::getId();
        $client = Kms_Resource_Client::getUserClient();

        try{
            // use base entry, NOT media entry - so the file suffix id will work
            $entry = new Kaltura_Client_Type_BaseEntry();
            $entry->name = $name;

            $resource = new Kaltura_Client_Type_UploadedFileTokenResource();
            $resource->token = $token;

            $newEntry = $client->baseEntry->add($entry, Kaltura_Client_Enum_EntryType::AUTOMATIC);
            $client->baseEntry->addContent($newEntry->id, $resource);

            // the new entry is our current entry
            $this->entry = $newEntry;
            $this->id = $newEntry->id;
        }
        catch(Kaltura_Client_Exception $e){
            Kms_Log::log('entry: Entry creation failed. ' . $e->getCode() . ': ' . $e->getMessage());
        }        

        return $newEntry;
    }

    /**
     * set the entry manually
     * @param Kaltura_Client_Type_BaseEntry $entry 
     */
    public function setEntry($entry)
    {
        if (isset($entry->id))
        {
            // running get here, in order for the modules to run as well
            $this->get($entry->id);
        }
    }

    /**
     * get the last results total number
     * @return int
     */
    public function getLastResultCount()
    {
        return $this->_lastResultsTotal;
    }

    /**
     * Return the standard entry filter
     * @return Kaltura_Client_Type_BaseEntryFilter
     */
    public static function getStandardEntryFilter($params = array())
    {
        // check validity of params
        if (!isset($params['type']))
        {
            $params['type'] = null;
        }

        if (!isset($params['sort']))
        {
            $params['sort'] = null;
        }

        if (!isset($params['status']))
        {
            $params['status'] = null;
        }

        if (!isset($params['keyword']))
        {
            $params['keyword'] = null;
        }

        if (!isset($params['tag']))
        {
            $params['tag'] = null;
        }

        // instantiate filter
        $filter = self::createEntryFilter($params['type']);
        
        // filter entries which are not scheduled or within their scheduling window
        $filter = self::applySchedulingOnFilter($filter);

        // apply sort filter
        $filter = self::applySortFilter($filter, $params['sort']);

        // apply keyword filter
        $filter = self::applyKeywordFilter($filter, $params['keyword']);

        $filter = self::applyTagFilter($filter, $params['tag']);

        // filter by ready status
        $filter->statusEqual = Kaltura_Client_Enum_EntryStatus::READY ;


        // filter by approved/auto approved moderation status
        $filter->moderationStatusIn = join(',', array(
                Kaltura_Client_Enum_EntryModerationStatus::APPROVED,
                Kaltura_Client_Enum_EntryModerationStatus::AUTO_APPROVED,
                Kaltura_Client_Enum_EntryModerationStatus::FLAGGED_FOR_REVIEW,
            )
        );

        return $filter;
    }

    public function entryAdded()
    {
        // execute the modules implementing "Kms_Interface_Model_Entry_EntryAdded" for entry
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_EntryAdded');

        foreach ($models as $model)
        {
            $model->entryAdded($this);
        }
        
    }
    
    
    /**
     * Return the standard entry pager
     * @return Kaltura_Client_Type_FilterPager
     */
    public static function getStandardEntryPager($params = array())
    {
        // instantiate pager
        $pager = new Kaltura_Client_Type_FilterPager();
        // set the page size
        if (isset($params['pageSize']) && $params['pageSize'] !== false)
        {
            $pager->pageSize = $params['pageSize'];
        }
        else
        {
            $pager->pageSize = Kms_Resource_Config::getConfiguration('gallery', 'pageSize');
        }
        return $pager;
    }

    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }
    
    /**
     * Apply the scheduling param on the filter
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * 
     * @return Kaltura_Client_Type_BaseEntryFilter 
     */
    public static function applySchedulingOnFilter($filter)
    {
    	$filter->startDateLessThanOrEqualOrNull = time(); 
    	$filter->endDateGreaterThanOrEqualOrNull = time();
    	return $filter;
    }

    /**
     * Apply the sort param on the filter, based on the sort parameter
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * @param string $sort
     * @return Kaltura_Client_Type_BaseEntryFilter 
     */
    public static function applySortFilter($filter, $sort)
    {
        switch ($sort)
        {
            case 'views':
                if ($filter instanceof Kaltura_Client_Type_MediaEntryFilter)
                {
                    // order by plays descending
                    $filter->orderBy = Kaltura_Client_Enum_MediaEntryOrderBy::VIEWS_DESC;
                }
                break;
            case 'name':
                // order by name ascending (alphabetical)
                $filter->orderBy = Kaltura_Client_Enum_BaseEntryOrderBy::NAME_ASC;
                break;
            case 'like':
                // order by likes descenting
                $filter->orderBy = Kaltura_Client_Enum_BaseEntryOrderBy::TOTAL_RANK_DESC;
                break;
            case 'recent':
            default:
                // order by recent
                $filter->orderBy = Kaltura_Client_Enum_BaseEntryOrderBy::CREATED_AT_DESC;
                break;
        }
        
        // execute the modules implementing "Kms_Interface_Model_Entry_FilterSort" for entry
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_FilterSort');

        foreach ($models as $model)
        {
            $filter = $model->editSortFilter($filter, $sort);
        }
        
        return $filter;
    }


    /**
     * instantiate the kaltura entry filter ( base entry or media entry, depending on the type )
     * @param string $type
     * @return Kaltura_Client_Type_MediaEntryFilter 
     */
    public static function createEntryFilter($type)
    {
		// what is a type of media
		if ($type) 
		{
			switch ($type)
			{
				case 'video' :
					$media_type = Kaltura_Client_Enum_MediaType::VIDEO;
					break;
				default :
					break;
			}
		}
		if (!empty($media_type)) 
		{
			// instantiate a media filter
			$filter = new Kaltura_Client_Type_MediaEntryFilter();
			// filter by media type
			$filter->mediaTypeEqual = $media_type;
		} 
		else 
		{
			$filter = new Kaltura_Client_Type_BaseEntryFilter();
		}
		
		$filter->typeIn = array();
						
		//add media clip if needed
		if (empty($type) || $type == "all" || !empty($media_type))
		{
			array_push($filter->typeIn, Kaltura_Client_Enum_EntryType::MEDIA_CLIP);
		}
		
		$filter->typeIn = implode(',', $filter->typeIn);
		
		// advanced search (later filled by modules, etc)
        $filter->advancedSearch = new Kaltura_Client_Type_SearchOperator();
        $filter->advancedSearch->type = Kaltura_Client_Enum_SearchOperatorType::SEARCH_AND;
        $filter->advancedSearch->items = array();
        
		$filter = self::hookModifyFilterByType($filter, $type);
        return $filter;
    }

    /**
     * Apply the freeText on the filter, based on the keyword parameter
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * @param string $keyword
     * @return Kaltura_Client_Type_BaseEntryFilter 
     */
    public static function applyKeywordFilter($filter, $keyword)
    {
        if ($keyword)
        {
            if(strlen($keyword) >= self::MINIMUM_SEARCH_KEYWORD_LENGTH)
            {
                $filter->freeText = $keyword;
            }
        }
        return $filter;
    }

    /**
     * Apply the tagsMultiLikeAnd on the filter, based on the $tag parameter
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * @param string $tag
     * @return Kaltura_Client_Type_BaseEntryFilter 
     */
    public static function applyTagFilter($filter, $tag)
    {
        if ($tag)
        {
            $filter->tagsMultiLikeAnd = '"' . addslashes($tag) . '"';
        }
        return $filter;
    }

    public function getEntriesByTag($tag, $params = array())
    {
        // init the standard entry filter
        $filter = self::getStandardEntryFilter($params);

        // init the standard entry pager
        $pager = self::getStandardEntryPager(array('pageSize' => $this->pageSize));

        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;

        // filter by $tag tag
        $filter->tagsMultiLikeAnd = '"' . addslashes($tag) . '"';

        // set root category
        $filter->categoriesMatchOr = join(',', array(Kms_Resource_Config::getRootGalleriesCategory(), Kms_Resource_Config::getRootChannelsCategory()));

        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_TAG_SEARCH);
        // get the entries
        return $this->listAction($filter, $pager, false, true, false);
    }

    public function getEntriesByUserId($userId, $params = array())
    {
        // init the standard entry filter
        $filter = self::getStandardEntryFilter($params);

        // init the standard entry pager
        $pager = self::getStandardEntryPager(array('pageSize' => $this->pageSize));

        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;

        // set root category
        $filter->categoriesMatchOr = join(',', array(Kms_Resource_Config::getRootGalleriesCategory(), Kms_Resource_Config::getRootChannelsCategory()));
        
        // filter by $userId
        $filter->userIdEqual = $userId;
        
        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_USER_SEARCH);

        // get the entries
        return $this->listAction($filter, $pager, false, true, false);
    }

    public function getEntriesByKeyword($searchKeyword, $params = array())
    {
        // init the standard entry filter
        $filter = self::getStandardEntryFilter($params);

        // init the standard entry pager
        $pager = self::getStandardEntryPager(array('pageSize' => $this->pageSize));

        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;

        // filter by search keyword
        // set root category
        $filter->categoriesMatchOr = join(',', array(Kms_Resource_Config::getRootGalleriesCategory(), Kms_Resource_Config::getRootChannelsCategory()));
        
        if ($params['keyword'])
        {// add search within keyword to free text if needed
            $filter->freeText = $searchKeyword . ' ' . $params['keyword'];
        }
        else
        {
            $filter->freeText = $searchKeyword;
        }

        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_KEYWORD_SEARCH);
        // get the entries
        return $this->listAction($filter, $pager, false, true, false);
    }

    public function getEntriesByChannel($channelId, $params = array())
    {
        // init the standard entry filter
        $filter = self::getStandardEntryFilter($params);
        
        // init the standard entry pager
        $pageSize = isset($params['pageSize']) ? $params['pageSize'] : $this->pageSize;        
        $pager = self::getStandardEntryPager(array('pageSize' => $pageSize));
        
        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;
        
        // filter by $channel channel
        $filter->categoriesIdsMatchOr = $channelId;
        
        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_CATEGORY_SEARCH);
        
        // get the entries via standard list action
        return $this->listAction($filter, $pager, false, true, false);
        
    }
    
    public function getEntriesByCategory($categoryId, $params = array())
    {
        // init the standard entry filter
        $filter = self::getStandardEntryFilter($params);

        // init the standard entry pager
        $pageSize = isset($params['pageSize']) ? $params['pageSize'] : $this->pageSize;        
        $pager = self::getStandardEntryPager(array('pageSize' => $pageSize));

        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;

        // filter by $category category
        // we use categoryAncestorIdIn and not categoriesIdsMatchOr to receive 
        // entries of sub categories
        $filter->categoryAncestorIdIn = $categoryId;   

        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_CATEGORY_SEARCH);

        // get the entries via standard list action
        return $this->listAction($filter, $pager, false, true, false);
    }

    /**
     *
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * @param Kaltura_Client_Type_FilterPager $pager 
     * @param Boolean $nocache
     * @param Boolean $getModules
     * @return array
     */
    public function listAction(Kaltura_Client_Type_BaseEntryFilter $filter, Kaltura_Client_Type_FilterPager $pager, $nocache = false, $getModules = true, $checkPublish = true)
    {
        $cacheParams = array();
        // build the caching params
        $cacheParams = $this->buildCacheParams($filter, $pager);
        $userId = Kms_Plugin_Access::getId();
        $cacheParams['userId'] = $userId;
        
        if(Kms_Resource_Cache::isEnabled() && !$nocache)
        {
        	$entryCacheTags = $this->getListCacheTags($filter);
        }
        else // originally this was out of the IF statement, so on false we set only these cache tags
        {
            $entryCacheTags = array();
            $entryCacheTags[] = 'user_' . $userId;
        }
        
        // try to fetch entry from cache ( in case nocache = false
        $entries = $nocache ? false : Kms_Resource_Cache::apiGet('entries', $cacheParams);
        if (!$entries)
        {
        	$userIds = array();
            // instantiate client
            $client = Kms_Resource_Client::getAdminClient();
            try
            {
                Kms_ClientLog::logMessage(__METHOD__.' - listing entries from entry model');
                $entries = $client->baseEntry->listAction($filter, $pager);
                if (isset($entries->objects))
                {
                    if (!$nocache && count($entries->objects))
                    {
                        foreach ($entries->objects as $entry)
                        {
                            $this->safeStrings($entry);
                            $entryCacheTags[] = 'entry_' . $entry->id;
                            //save each entry to cache as well
                            $this->setEntryCache($entry, $userId);
                            if (!in_array( $entry->userId, $userIds))
                            {
                            	array_push($userIds, $entry->userId);
                            }
                        }
						$userModel = new Application_Model_User();
						$userModel->getDisplayNames($userIds);
                        $cacheConfig = Kms_Resource_Config::getCacheConfig();
                        $expiry = null;
                        if (isset($cacheConfig->global) && isset($cacheConfig->global->entryListLifetime))
                        {
                            $expiry = $cacheConfig->global->entryListLifetime;
                        }
                        
                        Kms_Resource_Cache::apiSet('entries', $cacheParams, $entries, $entryCacheTags, $expiry);
                    }
                }
            }
            catch (Kaltura_Client_Exception $ex)
            {
                Kms_Log::log('entry: Error in baseEntry->listAction: ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
            }
        }
        
        if (isset($entries->objects))
        {
            $this->_lastResultsTotal = $entries->totalCount;
            
            foreach($entries->objects as $entryObj)
            {
                $newEntry = new Application_Model_Entry();
                $newEntry->entry = $entryObj;
                $newEntry->id = $entryObj->id;
                                        
                $this->Entries[$newEntry->id] = $newEntry;
            }
            
            // execute the modules implementing "listAction" for entry
            $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_List');

            if ($getModules)
            {
                foreach ($models as $model)
                {
                    $model->listAction($this);
                }
            }
                        
            
            // run check ready to publish on all entries models - relevant for bulk-publish action
            
            if($checkPublish && is_array($this->Entries) && count($this->Entries))
            {
                foreach($this->Entries as $entryModelObj)
                {
                    $entryModelObj->checkReadyToPublish();
                }
            }
            Kms_Resource_Models::setEntry($this);
            
            $this->updateFetchedEntries($entries->objects);
            return $entries->objects;
        }
        else
        {
        	$this->_lastResultsTotal = 0;
            return array();
        }
    }
    
    
    /**
     * get categories ids mentioned in filter
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     */
    private function getCategoriesFromFilter(Kaltura_Client_Type_BaseEntryFilter $filter) {
    	$categories = '';	// category ids/names
    	$isIds = false; 	// use category ids/names
    	
        if ($filter->categoriesMatchOr) {
            $categories = $filter->categoriesMatchOr;
        }
    	elseif ($filter->categoriesIdsMatchOr) {
			$isIds = true;
			$categories = $filter->categoriesIdsMatchOr;
		}
    	else if (isset($filter->categoryAncestorIdIn)){
			$isIds = true;
			$categories = $filter->categoryAncestorIdIn;
		}
        elseif (!empty($filter->advancedSearch)) {
        	// see if advancedSearch contains a Kaltura_Client_Type_CategoryEntryAdvancedFilter
        	$advancedSearch = null;
        	
       		if ($filter->advancedSearch instanceof Kaltura_Client_Type_CategoryEntryAdvancedFilter) {
       			$advancedSearch = $filter->advancedSearch;
       		}
       		else if ($filter->advancedSearch instanceof Kaltura_Client_Type_SearchOperator) {
       			foreach ($filter->advancedSearch->items as $item) {
       				if ($item instanceof Kaltura_Client_Type_CategoryEntryAdvancedFilter) {
       					$advancedSearch = $item;
       					break;
       				}
       			} 
       		}
       		
       		// get categories from advancedSearch
        	if (!empty($advancedSearch)) {
	        	if (isset($advancedSearch->categoriesMatchOr)){
			        $categories = $advancedSearch->categoriesMatchOr;
			    }
			    else if (isset($advancedSearch->categoriesIdsMatchOr)){
			        $isIds = true;
			        $categories = $advancedSearch->categoriesIdsMatchOr;
			    }
			    
			    else if (isset($advancedSearch->categoryAncestorIdIn)){
			        $isIds = true;
			    	$categories = $advancedSearch->categoryAncestorIdIn;
				}		
        	}
        }
        
        return array('categories' => $categories, 'isIds' => $isIds);
    }
    
    
    private function getListCacheTags(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $userId = Kms_Plugin_Access::getId();
        $entryCacheTags = array();
        $entryCacheTags[] = 'user_' . $userId;
        
        $ret = $this->getCategoriesFromFilter($filter);
		$categories = $ret['categories'];
        $isIds = $ret['isIds'];	// use category ids/names
        if (!empty($categories))
        {
            // add cache tags by category
            $entryCacheTags[] = 'category_' . $categories;
            $categoryNamesArray = explode(',', $categories);
            $categoryModel = Kms_Resource_Models::getCategory();

            // go over the categories and fetch their ids to add to the cache tags
            foreach($categoryNamesArray as $catName)
            {
                $catId = $catName;
                if (!$isIds) {
                    $catName = trim($catName,'>');
                    $categoryObj = $categoryModel->get($catName, true);
                    if ($categoryObj) {
                        $catId = $categoryObj->id; 
                    }
                }
                $entryCacheTags[] = 'categoryId_' . $catId;
            }
        }

        if ($filter->userIdEqual)
        {
            // add cache tags by user id
            $entryCacheTags[] = 'user_' . $filter->userIdEqual;
        }

        return $entryCacheTags;
    }

    public function clearMyMediaCache()
    {
        $userId = Kms_Plugin_Access::getId();
        $result = Kms_Resource_Cache::apiClean('entries', array(''), array('user_' . $userId));
    }
    
    private function updateFetchedEntries($entries = array())
    {
        foreach($entries as $entry)
        {
            self::$fetchedEntries[$entry->id] = $entry;
        }
    }

    public function getMyMedia($params = array())
    {
        $userId = Kms_Plugin_Access::getId();
        $pageSize = isset($params['pageSize']) ? $params['pageSize'] : $this->pageSize;
        $pager = self::getStandardEntryPager(array('pageSize' => $pageSize));
        // set the page number
        $pager->pageIndex = isset($params['page']) ? $params['page'] : 1;

        $params['status'] = isset($params['status']) ?  $params['status'] : 'all';

        $filter = self::getStandardEntryFilter($params);

        // apply status filter
        $filter = self::applyStatusFilter($filter, $params['status']);

        $filter->userIdEqual = $userId;
        
        //don't filter by scheduling window
        $filter->startDateGreaterThanOrEqualOrNull = null;
        $filter->endDateGreaterThanOrEqualOrNull = null;

        //call hookModifyFilter to allow modules to change filter
        $filter = self::hookModifyFilter($filter, Kms_Interface_Model_Entry_ListFilter::CONTEXT_LIST_MYMEDIA);

        $entries = $this->listAction($filter, $pager, false, true, false);

        // if cache is enabled
        $cacheConfig = Kms_Resource_Config::getCacheConfig();

        if ($cacheConfig && $cacheConfig->global && $cacheConfig->global->cacheEnabled)
        {

            $refreshEntries = array();
            // check for changes in entries that do not have status READY
            foreach ($entries as $key => $entry)
            {
                if ($entry->status != Kaltura_Client_Enum_EntryStatus::READY)
                {
                    // remove if deleted
                    if ($entry->status == Kaltura_Client_Enum_EntryStatus::DELETED)
                    {
                        unset($entries[$key]);
                    }
                    else
                    {
                        // these are the entries that must be refreshed
                        $refreshEntries[$entry->id] = array('key' => $key, 'status' => $entry->status, 'id' => $entry->id);
                    }
                }
            }

            if (count($refreshEntries))
            {
                // get the entries to be refreshed
                $client = Kms_Resource_Client::getUserClient();
                Kms_ClientLog::logMessage(__METHOD__.' - multirequesting baseentry.get to refresh specific entries\' cache');
                $client->startMultiRequest();
                foreach ($refreshEntries as $entryId => $refreshEntry)
                {
                    $client->baseEntry->get($entryId);
                }

                // execute the multirequest
                try
                {
                    $result = $client->doMultiRequest();
                }
                catch (Kaltura_Client_Exception $ex)
                {
                    Kms_Log::log('entry: Unable to get entry id ' . $refreshEntry['id'] . '. ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
                    //throw new Kaltura_Client_Exception($ex->getMessage(), $ex->getCode());
                }

                // results came back
                if (isset($result) && count($result))
                {
                    $clean = false;
                    foreach ($result as $entry)
                    {
                        // check each entry if the status has changed
                        if (isset($refreshEntries[$entry->id]))
                        {
                            $entries{ $refreshEntries[$entry->id]['key'] } = $entry;
                            $clean = true;
                        }
                    }

                    if ($clean)
                    {
                        Kms_Resource_Cache::apiClean('entries', array(''), array("user_" . $userId));
                    }
                }
            }
        }

        return $entries;
    }


   /**
     * Apply the status param on the filter, based on the status parameter.
     * This filter is tailored to my media requests. do not use in other requests.
     * 
     * @param Kaltura_Client_Type_BaseEntryFilter $filter
     * @param string $status
     * @return Kaltura_Client_Type_BaseEntryFilter 
     */
    public static function applyStatusFilter($filter, $status)
    {
        switch ($status) {
            case 'all':
                $filter = self::getAllEntriesFilter($filter);
                break; 
            case 'private':
                $filter = self::getPrivateEntriesFilter($filter);
                break;
            case 'unlisted':
            	$filter = self::getUnlistedEntriesFilter($filter);
            	break;
            case 'published':
                $filter = self::getPublishedEntriesFilter($filter);
                break;
            case 'pending':
                $filter = self::getPendingEntriesFilter($filter);
                break;  
            case 'rejected':
                $filter = self::getRejectedEntriesFilter($filter);
                break;  
            default:
                break;
        }
        return $filter;
    }

    /**
     * get all entries, regadless of presense in kms or status
     */
    private static function getAllEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->moderationStatusIn = join(',', array(
            Kaltura_Client_Enum_EntryModerationStatus::APPROVED,
            Kaltura_Client_Enum_EntryModerationStatus::AUTO_APPROVED,
            Kaltura_Client_Enum_EntryModerationStatus::FLAGGED_FOR_REVIEW,
            Kaltura_Client_Enum_EntryModerationStatus::PENDING_MODERATION,
            Kaltura_Client_Enum_EntryModerationStatus::REJECTED,
        ));

        $filter->statusEqual = NULL;
        $filter->statusIn = join(',', array(
            Kaltura_Client_Enum_EntryStatus::READY,
            Kaltura_Client_Enum_EntryStatus::PRECONVERT,
            Kaltura_Client_Enum_EntryStatus::PENDING,
            Kaltura_Client_Enum_EntryStatus::IMPORT,
            Kaltura_Client_Enum_EntryStatus::ERROR_CONVERTING,
            Kaltura_Client_Enum_EntryStatus::ERROR_IMPORTING,
            Kaltura_Client_Enum_EntryStatus::INFECTED,
                )
        );

        $categoryEntryAdvancedFilter = new Kaltura_Client_Type_CategoryEntryAdvancedFilter();
        $categoryEntryAdvancedFilter->categoryEntryStatusIn = join(',', array(
            Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE,
            Kaltura_Client_Enum_CategoryEntryStatus::PENDING,
            Kaltura_Client_Enum_CategoryEntryStatus::REJECTED,
        ));
        if ($filter->advancedSearch instanceof Kaltura_Client_Type_SearchOperator) { 
        	$filter->advancedSearch->items[] = $categoryEntryAdvancedFilter;
        }

        return $filter;
    }

    /**
     *  get only entries published in KMS
     */
    private static function getPublishedEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->categoriesMatchOr = join(',', array(Kms_Resource_Config::getRootGalleriesCategory(), Kms_Resource_Config::getRootChannelsCategory()));                
        $filter->statusIn = NULL;
        $filter->statusEqual = Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE;     
        return $filter;
    }

    /**
     *  get only the entrie not published anywhere in kms
     */
    private static function getPrivateEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->categoriesIdsNotContains = join(',', array(Kms_Resource_Config::getRootGalleriesCategoryId() , 
        	Kms_Resource_Config::getRootChannelsCategoryId() , Kms_Resource_Config::getUnlistedCategoryId()));        
        $filter->statusIn = NULL;
        $filter->statusEqual = NULL;
        return $filter;
    }
    
	/**
     *  get only the unlisted entries 
     */
    private static function getUnlistedEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->categoriesIdsMatchOr = Kms_Resource_Config::getUnlistedCategoryId();   
        $filter->statusIn = NULL;
        $filter->statusEqual = NULL;
        return $filter;
    }

    /**
     *  get only pending entries in KMS
     */
    private static function getPendingEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->categoriesMatchOr = null;
        $categoryEntryAdvancedFilter = new Kaltura_Client_Type_CategoryEntryAdvancedFilter();
        $categoryEntryAdvancedFilter->categoriesMatchOr = Kms_Resource_Config::getRootChannelsCategory() . '>,' . Kms_Resource_Config::getRootGalleriesCategory() .'>';
        $categoryEntryAdvancedFilter->categoryEntryStatusIn = Kaltura_Client_Enum_CategoryEntryStatus::PENDING;
    	if ($filter->advancedSearch instanceof Kaltura_Client_Type_SearchOperator) { 
        	$filter->advancedSearch->items[] = $categoryEntryAdvancedFilter;
        }
        $filter->statusIn = null;
        $filter->statusEqual = NULL;        
        return $filter;
    }

    /**
     *  get only rejected entries in KMS
     */
    private static function getRejectedEntriesFilter(Kaltura_Client_Type_BaseEntryFilter $filter)
    {
        $filter->categoriesMatchOr = null;
        $categoryEntryAdvancedFilter = new Kaltura_Client_Type_CategoryEntryAdvancedFilter();
        $categoryEntryAdvancedFilter->categoriesMatchOr = Kms_Resource_Config::getRootChannelsCategory() . '>,' . Kms_Resource_Config::getRootGalleriesCategory() .'>';
        $categoryEntryAdvancedFilter->categoryEntryStatusIn = Kaltura_Client_Enum_CategoryEntryStatus::REJECTED;
    	if ($filter->advancedSearch instanceof Kaltura_Client_Type_SearchOperator) { 
        	$filter->advancedSearch->items[] = $categoryEntryAdvancedFilter;
        }
        $filter->statusIn = null;
        $filter->statusEqual = NULL;        
        return $filter;
    }


    /**
     * allow modules using model hooks to keep and access data on the model
     * @param string $moduleName
     */
    public function getModuleData($moduleName)
    {
        return isset($this->modules[$moduleName]) ? $this->modules[$moduleName] : NULL;
    }

    /**
     * allow modules using model hooks to keep and access data on the model
     * @param unknown_type $data
     * @param string $moduleName
     */
    public function setModuleData($data, $moduleName)
    {
        $this->modules[$moduleName] = $data;
    }

    /**
     * saves an entry
     * 
     * @param array $data - the entry data to save
     * @param boolean $admin  - is this kms admin
     */
    public function save(array $data, $admin = false)
    {
        // get the entry
        $this->get($data['id'], false);

        // check if we have permission to update (user id matches the entry user id)
        if (Kms_Plugin_Access::isCurrentUser($this->entry->userId) || $admin)
        {
            // update entry
            $entry = new Kaltura_Client_Type_BaseEntry();

            // assign the properties
            foreach ($data as $key => $value)
            {
                if (property_exists($entry, $key))
                {
                    $entry->$key = $value;
                }
            }

            $cacheTags = array();

            // @todo - no more entry->categories - cache will not be erased
            $entryOldCategories = explode(',', $this->entry->categories);

            // use admin client to save admin tags
            if (isset($data['adminTags']) || $admin)
            {
                $client = Kms_Resource_Client::getAdminClient();
            }
            else
            {
                $client = Kms_Resource_Client::getUserClient();
            }

            try
            {
                $client->startMultiRequest();
                $client->baseEntry->update($entry->id, $entry);
                $client->baseEntry->get($entry->id);
                $res = $client->doMultiRequest();
                if (!($res[1] instanceof Kaltura_Client_Exception))
                	$this->entry = isset($res[1]) ? $res[1] : NULL;
                if ($res[0] instanceof Kaltura_Client_Exception)
                {
                    Kms_Log::log('entry: Error saving entry ' . $this->entry->id . ': ' . $res[0]->getCode() . ', ' . $res[0]->getMessage(), Kms_Log::ERR);
                	throw new Kaltura_Client_Exception($res[0]->getMessage(), $res[0]->getCode());
                }
            }
            catch(Exception $e){}
            // update the entry with what we saved
            $this->updateFetchedEntries(array($this->entry));
            $this->checkReadyToPublish();

            $channelModel = Kms_Resource_Models::getChannel();
            if ($channelModel->isSharedRepositoriesEnabled()){
                $customdataProfileId = Kms_Resource_Config::getConfiguration('sharedRepositories', 'customDataProfileId');
                $configuredDateFormat = Kms_Resource_Config::getConfiguration('sharedRepositories', 'dateFormat');
                Kms_Helper_Metadata::saveEntry($this, 'sharedRepositories', $customdataProfileId, $configuredDateFormat);
            }

            // invoke modules save hooks
            $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_Save');
            foreach ($models as $model)
            {
                $model->save($this);
            }

            // invalidate the cache for the entry
            $cacheTags[] = 'entry_' . $this->entry->id;
            $entryCategories = explode(',', $this->entry->categories);
            // $entry = $this->get($entry->id);
            // create cache tags for entry categories
            if (Kms_Resource_Cache::isEnabled())
            {
                $rootCategory = Kms_Resource_Config::getConfiguration('categories', 'rootCategory');
                // iterate over all old entry and new entry cats
                $entryCategories = array_unique(array_merge($entryOldCategories, $entryCategories));
                foreach ($entryCategories as $entryCategory)
                {
                    $catNameArr = explode('>', $entryCategory);
                    if (count($catNameArr))
                    {
                        $catTagName = '';
                        foreach ($catNameArr as $value)
                        {
                            if ($value == $rootCategory)
                            {
                                // do not clean root category cache
                                if($catTagName == '')
                                {
                                    $catTagName .= $value;
                                }
                                else
                                {
                                    $catTagName .= '>' . $value;
                                }
                            }
                            else
                            {
                                if($catTagName == '')
                                {
                                    $catTagName .= $value;
                                }
                                else
                                {
                                    $catTagName .= '>' . $value;
                                }
                                $cacheTags[] = 'category_' . $catTagName;
                            }
                        }
                    }
                }
                $cacheTags = array_unique($cacheTags);
            }

            $cacheTags[] = 'user_' . $this->entry->userId;
            Kms_Resource_Cache::apiClean('entry', array('id' => $entry->id), $cacheTags);

            $entryModerated = $this->entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::AUTO_APPROVED || $this->entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::APPROVED;
            $entryReady = $this->entry->status == Kaltura_Client_Enum_EntryStatus::READY;

            // only save cache if entry is ready and approved moderation
            if ($entryModerated && $entryReady)
            {
                // save back into cache
                Kms_Resource_Cache::apiSet('entry', array('id' => $this->entry->id), $this->entry);
            }

            // set the model entry var to the new entry
            return $this->entry;
        }
        else
        {
            Kms_Log::log('Access denied, tried to update entry that does not belong to me', Kms_Log::WARN);
            throw new Kaltura_Client_Exception('Access denied, tried to update entry that does not belong to me', Kaltura_Client_Exception::ERROR_GENERIC);
        }
    }
    
    /**
     * add category for an entry
     * @param string $entryId
     * @param string|array $categoryArray
     * @return $resultcount
     */
    public function addCategory($entryId, $categoryIdArray)
    {
        // retrieve entry
        $this->get($entryId, false);
        // get entry categories , as array
        $entryCategories = $this->getEntryCategories($entryId);
        $cacheTags = array();
        // create a hash of categories as keys


        $categoryKeysArray = array_flip(array_keys($entryCategories));
        if(!is_array($categoryIdArray))
        {
            $categoryIdArray = array($categoryIdArray);
        }
        
        $resultcount = 0;
        
        foreach($categoryIdArray as $catId)
        {
            if (isset($categoryKeysArray[$catId]))
            {
                // remove the category
                Kms_Log::log('entry: skipping publish of '.$entryId.' because already published in '.$catId, Kms_Log::DEBUG);
                //$result = false;
            }
            else
            {
                // add the category
                $categoryKeysArray[$catId] = '1';
            }
        }

        if(count($categoryKeysArray))
        {
            $result = $this->updateCategoriesFrom(array($entryId), array(),array_keys($categoryKeysArray));

            if($result)
            {
                $resultcount ++;
            }
        }
        

        return $resultcount;
    }
    
    
    public function approve($entry)
    {
        $auth = Zend_Auth::getInstance();
        if (is_object($auth->getIdentity()))
        {
            $role = $auth->getIdentity()->getRole();
        }

        if ($role == Kms_Plugin_Access::getRole(Kms_Plugin_Access::UNMOD_ROLE) && $entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::PENDING_MODERATION)
        {
			$client = Kms_Resource_Client::getAdminClient();
    	    try
        	{
                $client->baseEntry->approve($entry->id);
	        }
    	    catch (Kaltura_Client_Exception $e)
    	    {
            	Kms_Log::log('upload: Entry auto-approve failed. ' . $e->getCode() . ': ' . $e->getMessage());
                return false;
            }
        }
    }

    
    public function getPublishedInCategory($entryId, $categoryId)
    {
        if($entryId && !is_array($entryId))
        {
            $entryId = array($entryId);
        }
        
        $client = Kms_Resource_Client::getUserClient();
        $filter = new Kaltura_Client_Type_CategoryEntryFilter();
        $filter->entryIdIn = join(',', $entryId);
        $filter->categoryIdEqual = $categoryId;
        $filter->statusIn = join(',', array(Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE, Kaltura_Client_Enum_CategoryEntryStatus::PENDING));
        $res = $client->categoryEntry->listAction($filter);
        if($res && isset($res->objects) && count($res->objects))
        {
            return $res->objects;
        }
        else
        {
            return array();
        }
    }
    
    
    /**
     * get channels and galleries that contain the given entry in active and pending status.
     * @param string $entryId
     * @return array of categories
     */
    public function getEntryCategories($entryId)
    {	
        return $this->getEntryCategoriesByStatus($entryId, array(Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE, Kaltura_Client_Enum_CategoryEntryStatus::PENDING));
    }
    
 	/**
     * get channels and galleries that contain the given entry in active and pending status.
     * @param string $entryId
     * @return array of categories
     */
    public function getEntryCategoriesIds($entryId)
    {	
        return $this->getEntryCategoriesIdsByStatus($entryId, Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE .', '. Kaltura_Client_Enum_CategoryEntryStatus::PENDING);
    }

    /**
     * get channels and galleries that contain the given entry in active and rejected status.
     * @param string $entryId
     * @return array of categories
     */
    public function getRejectedEntryCategories($entryId)
    {
        return $this->getEntryCategoriesByStatus($entryId, array( Kaltura_Client_Enum_CategoryEntryStatus::REJECTED));
    }
    
    /**
     * get channels and galleries that contain the given entry in active(published) status.
     * @param string $entryId
     * @return array of categories
     */
    public function getEntryCategoriesNoPending($entryId)
    {	
        return $this->getEntryCategoriesByStatus($entryId, array(Kaltura_Client_Enum_CategoryEntryStatus::ACTIVE));
    }
    

    /**
     * get the entry`s pending categories
     * @param string $entryId
     * @return array of categories
     */
    public function getEntryPendingCategories($entryId)
    {
        return $this->getEntryCategoriesByStatus($entryId, array(Kaltura_Client_Enum_CategoryEntryStatus::PENDING));
    }
    
    /**
     * get the entry`s rejected categories
     * @param string $entryId
     * @return array of categories
     */
    public function getEntryRejectedCategories($entryId)
    {
        return $this->getEntryCategoriesByStatus($entryId, array(Kaltura_Client_Enum_CategoryEntryStatus::REJECTED));
    }

    /**
     * publish and unpublish entries from a list of categories
     * 
     * @param array $entryIdArr - array of entry id's to publish/unpublish
     * @param array $deleteArr - categories to unpublish the entries from
     * @param array $addArr - categories to publish the entries to
     */
	public function updateCategoriesFrom(array $entryIdArr, array $deleteArr, array $addArr)
    {
        $cacheTags = array();
        $commands = array();

        $client = Kms_Resource_Client::getUserClient();
        // increase the client timeout to 120 sec
        $config = $client->getConfig();
        $config->curlTimeout = 120;
        $client->setConfig($config);
               
        // compose the multirequest       
        $client->startMultiRequest();
       
        foreach ($entryIdArr as $entryId)
        {
        	$cacheTags[] = 'entry_' . $entryId;
	        // remove entry from categories
	        foreach($deleteArr as $categoryId)
	        {
                $cacheTags[] = 'categoryId_' . $categoryId;
	            $client->categoryEntry->delete($entryId, $categoryId);

                $commands[] = array('entry' => $entryId, 'cmd' => 'del', 'cat' => $categoryId);
	        }
	        
	    	// add entry to categories
	        foreach($addArr as $categoryId)
	        {
	            $categoryEntry = new Kaltura_Client_Type_CategoryEntry();
	            $categoryEntry->entryId = $entryId;
	            $categoryEntry->categoryId = $categoryId;
	            $cacheTags[] = 'categoryId_' . $categoryId;
	            $client->categoryEntry->add($categoryEntry);

                $commands[] = array('entry' => $entryId, 'cmd' => 'add', 'cat' => $categoryId);                
	        }
        }
        
        // run the multi request
    	$counter =0;
        $res = null;
        $errorArr =array();
        try 
        {
            $res = $client->doMultiRequest();
        	foreach ($res as $object)
            {
                // handle multi request errors
            	if ($object instanceof Kaltura_Client_Exception)
            	{
                    $entryId = $commands[$counter]['entry'];

                    // remove the command from the list
                    unset($commands[$counter]);

            		if($object->getCode() == 'MAX_CATEGORIES_FOR_ENTRY_REACHED')
            		{
                        // index the errors by entry - to prevent duplicates
            			if (!in_array($entryId,$errorArr))
                			$errorArr[] = $entryId;	
					}
            		else if($object->getCode() != 'CATEGORY_ENTRY_ALREADY_EXISTS' && 
                            $object->getCode() != 'ENTRY_IS_NOT_ASSIGNED_TO_CATEGORY')
            		{
                        // unknown general error
                        $errorArr[] = $entryId;    

            			Kms_Log::log('entry: Error updating categories : ' . $object->getCode() . ', ' . $object->getMessage(), Kms_Log::ERR);
					}	
            	}
            	$counter++;
            }
        }
        catch(Kaltura_Client_Exception $e)
        {
            Kms_Log::log('entry: Error updating categories : ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::ERR);
            throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
        }
        
        // get only successfuly added entries/categories
        $entries = array();
        $categories = array();
        foreach ($commands as $command) {
            if ($command['cmd'] == 'add') {
                $entries[] = $command['entry'];
                $categories[] = $command['cat'];
            }
        }

        // call the modules implementing the publish interface
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_Publish') as $module => $model) {
            $model->published($entries, $categories);
        }

        Kms_Resource_Cache::apiClean('entry', array(), $cacheTags);
        Kms_Resource_Cache::apiClean('categoryEntry', array('id' => $entryId));

        return $errorArr;
    }

    public function addAdminTag($tag)
    {
        $adminTags = array();
        $this->get($this->id);
        if (isset($this->entry->adminTags) && $this->entry->adminTags)
        {
            $adminTags = array_reverse(explode(',', $this->entry->adminTags));
        }

        $adminTags[$tag] = '';
        $entryData = array(
            'id' => $this->entry->id,
            'adminTags' => join(',', array_keys($adminTags))
        );

        $this->save($entryData);
    }

    /**
     * update the like cache, invalidate entry caches after like/unlike
     * @param bool $id
     * @param bool $liked
     */
    private function refreshEntryCache($id,$liked)
    {
        $userId = Kms_Plugin_Access::getId();
        
        // change the cached entry to reflect the new `liked` status by this user
        Kms_Resource_Cache::apiSet('like', array('id' => $id, 'userId' => $userId), array($liked));

        // invalidate the entry cache
        $cacheTags = array('entry_' . $id,);
        Kms_Resource_Cache::apiClean('entry', array('id' => $id), $cacheTags);
        Kms_Resource_Cache::apiClean('entries', array(''), $cacheTags);
        
        // reload the entry
        $this->get($id);
    }
    
    /**
     * like an entry
     * @param string $id
     * @throws Kaltura_Client_Exception
     */
    public function like($id)
    {
        $result = false;
        if (Kms_Resource_Config::getConfiguration('application', 'enableLike'))
        {
            try
            {
                $client = Kms_Resource_Client::getUserClient();    
                $likePlugin = Kaltura_Client_Like_Plugin::get($client);
                $result = $likePlugin->like->like($id);
                if ($result)
                {
                    // change the cached entry to reflect the new `liked` status by this user
                    $this->liked = true;                    
                    $this->refreshEntryCache($id,$this->liked);
                }
                Kms_Log::log('entry: entry id ' . $id . ' liked ' . $this->liked, Kms_Log::DEBUG);
            }
            catch (Kaltura_Client_Exception $ex)
            {
                // could be double like   
                Kms_Log::log('entry: Unable to like entry id ' . $id . '. ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
                $result = false;
            }
        }
        else
        {
            Kms_Log::log('entry: like feature not active', Kms_Log::NOTICE);
        }
        return $result;
    }

    /**
     * unlike an entry
     * @param string $id
     * @throws Kaltura_Client_Exception
     */
    public function unlike($id)
    {
        $result = false;
        if (Kms_Resource_Config::getConfiguration('application', 'enableLike'))
        {
            try
            {
                $client = Kms_Resource_Client::getUserClient();
                $likePlugin = Kaltura_Client_Like_Plugin::get($client);
                $result = $likePlugin->like->unlike($id);
                if ($result)
                {
                    // change the cached entry to reflect the new `unliked` status by this user
                    $this->liked = false;                    
                    $this->refreshEntryCache($id,$this->liked);
                }
                Kms_Log::log('entry: entry id ' . $id . ' unliked ' . $this->liked, Kms_Log::DEBUG);
            }
            catch (Kaltura_Client_Exception $ex)
            {
                // could be double unlike
                Kms_Log::log('entry: Unable to unlike entry id ' . $id . '. ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
                $result = false;
            }
        }
        else
        {
            Kms_Log::log('entry: like feature not active', Kms_Log::NOTICE);
        }
        
        return $result;
    }

    /**
     * check on an entry liked status
     * @param string $id
     * @throws Kaltura_Client_Exception
     * @return boolean
     */
    public function isLiked($id)
    {
        if (Kms_Resource_Config::getConfiguration('application', 'enableLike') && Kms_Plugin_Access::isLoggedIn())
        {
            // check if this entry was queried before by this user
            if (!isset($this->liked))
            {
                // check in the cache
                $userId = Kms_Plugin_Access::getId();
                $isLiked = Kms_Resource_Cache::apiGet('like', array('id' => $id, 'userId' => $userId));
                if (!$isLiked)
                {
                    // no data member - no cache - go to the api
                    try
                    {
                        $client = Kms_Resource_Client::getUserClient();
                        $likePlugin = Kaltura_Client_Like_Plugin::get($client);
                        $this->liked = $likePlugin->like->checkLikeExists($id, $userId);

                        // change the cached entry to reflect the `like` status by this user
                        Kms_Resource_Cache::apiSet('like', array('id' => $id, 'userId' => $userId), array($this->liked));
                    }
                    catch (Kaltura_Client_Exception $ex)
                    {
                        Kms_Log::log('entry: Unable to check if entry id ' . $id . '. is liked ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
                    }
                }
                else
                {
                    // cached data
                    $this->liked = $isLiked[0];
                }
            } // if (!isset($this->liked))
            Kms_Log::log('entry: entry id ' . $id . ' is liked value "' . $this->liked . '"', Kms_Log::DEBUG);
        }
        
        return $this->liked;
    }

    private static function hookModifyFilter($filter, $context)
    {
        // execute the modules implementing "Kms_Interface_Model_Entry_ListFilter" for entry
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Model_Entry_ListFilter');

        foreach ($models as $model){
            $filter = $model->modifyFilter($filter, $context);
        }

        return $filter;
    }
    
    private static function hookModifyFilterByType($filter, $type)
    {
    	// execute the modules implementing "Kms_Interface_Functional_Entry_Type" for entry
    	$models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Type');
    	foreach ($models as $model)
    	{
    		$filter = $model->modifyFilterByType($filter, $type);
    	}
    	return $filter;
    }
    
    /**
     * check if entry is published in gallery or channels
     */
    public function isPublished(Kaltura_Client_Type_BaseEntry $entry)
    {
        $published = false;
        $entryCats = array();
        try
        {
            $entryCats = $this->getEntryCategories($entry->id);
        }
        catch(Kaltura_Client_Exception $e)
        {
            Kms_Log::log('entry: failed to get entry categories in "isPublished()" - '.$e->getCode().': '. $e->getMessage(), Kms_Log::WARN);
        }

        if(count($entryCats))
        {
            $galleriesRootId = Kms_Resource_Config::getRootGalleriesCategoryFullId() . '>';
            $channelsRootId = Kms_Resource_Config::getRootChannelsCategoryFullId() . '>';
            
            foreach($entryCats as $category)
            {
                if (strpos($category->fullIds, $galleriesRootId) !== false || 
                    strpos($category->fullIds, $channelsRootId) !== false) 
                {
                    $published = true;
                    break;
                }
            }
        }
        return $published;
    }
    
    /**
     * check if entries are published/pending/rejected in KMS galleries or channels
     * 
     * the published statuses are indexed by status and not by entry id
     * becaus an entry can have several statuses at once. 
     */
    public function getEntriesPublishStatus(array $entries)
    {
        $status = array('published' => array(), 'pending' => array());
        $cacheTags = array();

        $pager = self::getStandardEntryPager(array('pageSize' => count($entries)));
        $pager->pageIndex =  1;

        //$filter = new Kaltura_Client_Type_BaseEntryFilter();
        $filter = self::createEntryFilter('all');
        foreach ($entries as $entry) {
            $filter->idIn .= ',' . $entry->id;
            // cache tags are simply all entry IDs - when publishing, entry cache is cleared by entry ID of published entries.            
            $cacheTags[] = 'entry_' . $entry->id;
        }        
        $cacheTags[] = 'user_' . Kms_Plugin_Access::getId();

        // get only those entries published in kms root cateories
        $filter = $this->getPublishedEntriesFilter($filter);

        // pending entries filter
        $pendingFilter = self::createEntryFilter('all');
        $pendingFilter->idIn = $filter->idIn;
        $pendingFilter = $this->getPendingEntriesFilter($pendingFilter);

        // rejected entries
        $rejectedFilter = self::createEntryFilter('all');
        $rejectedFilter->idIn = $filter->idIn;        
        $rejectedFilter = $this->getRejectedEntriesFilter($rejectedFilter);
        
        // is unlisted feature on?
        $unlistedOn = Kms_Resource_Config::isBooleanFieldTrue('application', 'enableUnlisted', false); 
        if ($unlistedOn) {
	        //unlisted entries
	        $unlistedFilter = self::createEntryFilter('all');
	        $unlistedFilter->idIn = $filter->idIn;  
	        $unlistedFilter = $this->getUnlistedEntriesFilter($unlistedFilter);
        }
        
        $cacheParams = array_merge($this->buildCacheParams($filter, $pager), $this->buildCacheParams($pendingFilter, $pager), $this->buildCacheParams($rejectedFilter, $pager));
        if ($unlistedOn) {
        	$cacheParams = array_merge($cacheParams, $this->buildCacheParams($unlistedFilter, $pager));
        }
        $results = Kms_Resource_Cache::apiGet('entriesPublishStatus', $cacheParams);
        if(!$results)
        {
            $client = Kms_Resource_Client::getAdminClient();
            $client->startMultiRequest();
            Kms_ClientLog::logMessage(__METHOD__." - multirequesting entries with different statuses");

            $client->baseEntry->listAction($filter, $pager);
            $client->baseEntry->listAction($pendingFilter, $pager);
            $client->baseEntry->listAction($rejectedFilter, $pager);
            if ($unlistedOn) {
            	$client->baseEntry->listAction($unlistedFilter, $pager);
            } 

            $results = $client->doMultiRequest();

            if(Kms_Resource_Cache::isEnabled()){
                Kms_Resource_Cache::apiSet('entriesPublishStatus', $cacheParams, $results, $cacheTags);
            }
        }
        foreach ($results[0]->objects as $entry) {
            $status['published'][$entry->id] = $entry->id;
        }
        foreach ($results[1]->objects as $entry) {
            $status['pending'][$entry->id] = $entry->id;
        }
        foreach ($results[2]->objects as $entry) {
            $status['rejected'][$entry->id] = $entry->id;
        }
        if ($unlistedOn) {
	        foreach ($results[3]->objects as $entry) {
	            $status['unlisted'][$entry->id] = $entry->id;
	        }
        }

        return $status;
    }

    /**
     * check if core KMS can handle this entry type, or should a module handle it.
     * KMS takes the polish attitute here - it will handle the entry if no module does.
     * @param Kaltura_Client_Type_BaseEntry $entry
     * @return boolean is this entry to be handled by a module
     */
    public function handleEntryByModule(Kaltura_Client_Type_BaseEntry $entry)
    {
        $moduleModel = $this->getModelByEntryType($entry);
        $renderByModule = is_null($moduleModel) ? false : true;

        if ($renderByModule) {
            Kms_Log::log('entry: rendering entry by module.', Kms_Log::DEBUG);
        }

        return $renderByModule;
    }

    /**
     * get the module model handling this entry type
     * @param Kaltura_Client_Type_BaseEntry $entry
     * @return Kms_Module_BaseModel/null
     */
    static public function getModelByEntryType(Kaltura_Client_Type_BaseEntry $entry)
    {
        $moduleModel = null;
        $moduleFound = false;
        $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Type');

        $iterator = new ArrayIterator($models);
        for($iterator->rewind() ; $iterator->valid() && !$moduleFound ; $iterator->next())
        {
            $model = $iterator->current();
            $moduleFound = $model->isHandlingEntryType($entry);
            $moduleModel = $moduleFound ? $model : null;
        }

        return $moduleModel; 
    }

    /**
     * get the current loaded entry, or load it if not loaded.
     * @param string $entryId
     * @param boolean $getModules if triggering "get", should we also get modules
     * @throws Zend_Controller_Action_Exception
     * @return Kaltura_Client_Type_BaseEntry entry
     */
    public function getCurrent($entryId = null, $getModules = true)
    {
       $entry = null;
    
        if (isset($this->entry))
        {
            // we have an entry
            $entry = $this->entry;
    
            // is it the right entry?
            if ($entryId != null && $this->entry->id != $entryId)
            {
                // but we want a different one
                $entry = $this->get($entryId, $getModules);
            }
        }
        else
        {
            // we have no entry loaded - lets get it.
            $entry = $this->get($entryId, $getModules);
        }
    
        if (empty($entry) || !isset($entry->id))
        {
            // error - we dont have an entry
            Kms_Log::log('entry: no entry ' . ($entryId ? $entryId : 'current'), Kms_Log::ERR);
            throw new Zend_Controller_Action_Exception('no entry id specified', 500);
        }
    
        return $entry;
    }
    
    public function getEntriesByIds($ids)
    {
    	$userId = Kms_Plugin_Access::getId();
    	$missed_ids = array();
    	$entries = array();
    	foreach ($ids as $id)
    	{
    		$entry = Kms_Resource_Cache::apiGet('entry', $this->createEntryCacheParams($id, $userId));
    		$entry ? array_push($entries, $entry) : array_push($missed_ids, $id);
    	}
    	
    	if (count($missed_ids) > 0)
    	{
    		//get all missed entries
    		$pager = self::getStandardEntryPager(array('pageSize' => $this->pageSize));
        
	        $filter = new Kaltura_Client_Type_BaseEntryFilter();
    	    $filter->userIdEqual = $userId;
        	$filter->idIn = implode(',', $missed_ids);
	        $client = Kms_Resource_Client::getAdminClient();
        	try
	        {
                $userIds = array();
    	    	$result = $client->baseEntry->listAction($filter, $pager);
        		if (isset($result->objects))
            	{
					$entries = array_merge($entries, $result->objects);
            	}
            	foreach ($result->objects as $entry)
            	{
            		if (!in_array( $entry->userId, $userIds))
            		{
            			array_push($userIds, $entry->userId);
            		}
            	}
            	$userModel = new Application_Model_User();
            	$userModel->getDisplayNames($userIds);
        	}
	        catch (Kaltura_Client_Exception $ex)
			{
        		Kms_Log::log('entry: Error in baseEntry->listAction: ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
			}
    	}
        return $entries;
    }
    
    
    /**
     * retreive the id of a media flavor playable by the HTML5 player
     * @param string $entryId id of the entry for which we want a mobile flavor
     */
    public function getMobileFlavorId($entryId) {
    	$flavorId = null;
    	
   		$pager = self::getStandardEntryPager(array('pageSize' => $this->pageSize));
       
        $filter = new Kaltura_Client_Type_FlavorAssetFilter();
   	    $filter->entryIdEqual = $entryId;
       	$filter->tagsLike = 'iphone';
        $client = Kms_Resource_Client::getAdminClient();
        
        $cacheParams = Kms_Resource_Cache::buildCacheParams($filter, $pager);
        
        $flavorId = Kms_Resource_Cache::apiGet('entry', $cacheParams);
        
        if (empty($flavorId)) {
	       	try {
	  	    	$result = $client->flavorAsset->listAction($filter, $pager);
	       		if (!empty($result->objects)) {
					$flavorId = $result->objects[0]->id;
	           	}
	           	Kms_Resource_Cache::apiSet('entry', $cacheParams, $flavorId, array('entry_' . $entryId));
	       	}
	        catch (Kaltura_Client_Exception $ex) {
	       		Kms_Log::log('entry: Error in flavorAsset->listAction: ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
			}
        }
		
		return $flavorId;
    } 
    
    
    /**
     * gets a uiconf object by its id
     * @param unknown_type $uiconfid
     */
    public function getUiconfById($uiconfid) 
    {
        $result = null;
    	$client = Kms_Resource_Client::getAdminClient();
    	try {
    		$result = $client->uiConf->get($uiconfid);
    	}
    	catch (Kaltura_Client_Exception $ex) {
       		Kms_Log::log('entry: Error in uiConf->get: ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
		}
		return $result;
    }
    
    /**
     * checks if an entry is inside a specfic category
     */
    public function isEntryInCategory($entry, $categoryId)
    {
    	// init the standard entry filter
        $filter = new Kaltura_Client_Type_BaseEntryFilter();

        // filter by $category category
        // we use categoryAncestorIdIn and not categoriesIdsMatchOr to receive 
        // entries of sub categories
        $filter->categoryAncestorIdIn = $categoryId;   
        $filter->idEqual = $entry->id;   

        // get the entries via standard list action
        $this->listAction($filter, new Kaltura_Client_Type_FilterPager(), false, false, false);
        // we don't care for the results, only for totalcount
        return $this->_lastResultsTotal > 0;
    }


    private function buildCacheParams(Kaltura_Client_Type_BaseEntryFilter $filter, $pager)
    {
        $clonedFilter = clone $filter;
        
        // remove startDate* filtering from cache params - those will be different each request and will kill caching
        unset($clonedFilter->startDateLessThanOrEqualOrNull);
        unset($clonedFilter->startDateGreaterThanOrEqual);
        unset($clonedFilter->startDateGreaterThanOrEqualOrNull);
        unset($clonedFilter->startDateLessThanOrEqual);
        unset($clonedFilter->endDateGreaterThanOrEqualOrNull);
        unset($clonedFilter->endDateGreaterThanOrEqual);
        unset($clonedFilter->endDateLessThanOrEqual);
        unset($clonedFilter->endDateLessThanOrEqualOrNull);
        
        $cacheParams = Kms_Resource_Cache::buildCacheParams($clonedFilter, $pager);
        return $cacheParams;
    }

    /**
     * get an entry`s categories of a given status
     * this method is being called several times during one request (for the same entry and status), and so stands to gain
     * from using a static member for the results.
     * @param string $entryId - the entry id
     * @param array $statuses - the statuses of the categoryEntry 
     * @return an array of categories
     */
    private function getEntryCategoriesByStatus($entryId, array $statuses)
    {   
    	$status = implode(',', $statuses);
    	
        static $categories;
        if (isset($categories[$entryId][$status])) {
           return $categories[$entryId][$status];
        }

        $categories = Kms_Resource_Cache::apiGet('categoryEntryByStatus', array('id' => $entryId, 'status' => $status));
        if(!$categories) 
        {
			$categoriesIds = $this->getEntryCategoriesIdsByStatus($entryId, $status);
            $cacheTags = array(
                    'entry_'.$entryId
            );
            
            $categories = array();
            if(count($categoriesIds))
            {
                foreach($categoriesIds as $catId){
                    $cacheTags[] = 'category_'.$catId;
                }
                
                $categories = $this->getCategoriesObjectsById($categoriesIds);
            }
            
            Kms_Resource_Cache::apiSet('categoryEntryByStatus', array('id' => $entryId), $categories, $cacheTags);
        }
        
        return $categories;
    }
    
    public function getCategoriesObjectsById(array $categoriesIds)
    {
		try
		{
            $categoryModel = Kms_Resource_Models::getCategory();
            $filter = new Kaltura_Client_Type_CategoryFilter();
            $filter->idIn = implode(',', $categoriesIds);
            $categories = $categoryModel->getListByFilter($filter);
        }
        catch(Kaltura_Client_Exception $e) {
            Kms_Log::log('entry: Error getting categories for entry ' . $this->entry->id . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::ERR);
            throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
        }
        
        return $categories;
    }
    
    public function getEntryCategoriesIdsByStatus($entryId, $statuses)
    {   
        $categoriesIds = array();
        
        $filter = new Kaltura_Client_Type_CategoryEntryFilter();
        $filter->entryIdEqual = $entryId;
        $filter->statusIn = $statuses;
        
        $filter->categoryFullIdsStartsWith = Kms_Resource_Config::getRootSiteCategoryFullId() .'>';
            
        try 
        {
            $client = Kms_Resource_Client::getUserClient();
            $categoryEntries = $client->categoryEntry->listAction($filter);

            if(isset($categoryEntries->objects) && count($categoryEntries->objects))
            {
                foreach($categoryEntries->objects as $categoryEntry)
                {
                    $categoriesIds[] = $categoryEntry->categoryId;
                }
            }
        }
        catch(Kaltura_Client_Exception $e){
            Kms_Log::log('entry: Error getting categoryEntry list for entry: ' . (isset($this->entry->id) ? $this->entry->id : '') . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::ERR);
            throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
        }

        return $categoriesIds;
    }
        
    public function isEntryUnlisted ($entryId)
    {
        try 
        {
            $filter = new Kaltura_Client_Type_CategoryEntryFilter();
            $filter->entryIdEqual = $entryId;
            $filter->categoryIdEqual = Kms_Resource_Config::getUnlistedCategoryId();
    
            $client = Kms_Resource_Client::getUserClient();
            $categoriesEntries = $client->categoryEntry->listAction($filter);
        }
        catch(Kaltura_Client_Exception $e){
            Kms_Log::log('entry: Error getting categoryEntry list for entry: ' . $entryId . ': ' . $e->getCode() . ', ' . $e->getMessage(), Kms_Log::ERR);
            throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
        }

        return ($categoriesEntries->totalCount) ? true : false;
    }

    /**
	* set the entry terms of use metadata
	* @param comma seperated string of $entryIds
	* @param comma seperated string of $sharedRepositoryIds
	*/
    public function setEntriesTermsOfUse($entryIds, $sharedRepositoryIds)
    {
        $TermsOfUseProfileId = Kms_Resource_Config::getConfiguration('sharedRepositories', 'TermsOfUseProfileId');
        $sharedRepositoryIdsArr = explode(",", $sharedRepositoryIds);
        $entriesArr = explode(",", $entryIds);
        $entriesArr = array_fill_keys($entriesArr, null);
        $entriesWithMetadata = array();

        if (count($entriesArr) && count($sharedRepositoryIdsArr) && !empty($TermsOfUseProfileId))
        {
            //get all entries metadatas
            $metadata = $this->getEntriesMetadata($TermsOfUseProfileId, $entryIds);
            if (!empty($metadata) && !empty($metadata->objects))
            {
                //go over each of them and create a XML for each shared repository
                foreach($metadata->objects as $entryMetadata){
                    foreach($sharedRepositoryIdsArr as $sharedRepositoryId){
                        if (!empty($entriesWithMetadata[$entryMetadata->objectId][$entryMetadata->id])){
                            $xmlObj = new SimpleXMLElement($entriesWithMetadata[$entryMetadata->objectId][$entryMetadata->id]->asXML());
                        }
                        else{
                            $xmlObj = new SimpleXMLElement($entryMetadata->xml);
                        }
                        $this->addTermsOfUseXmlChild($xmlObj, $sharedRepositoryId);
                        $entriesWithMetadata[$entryMetadata->objectId][$entryMetadata->id] = $xmlObj;
                    }
                }
            }

            //collect entries which didn't have terms of use metadata yet
            $entriesWithoutMetadata = array_diff_key($entriesArr, $entriesWithMetadata);
            foreach ($entriesWithoutMetadata as $entryId => $entryMetadata){
                foreach($sharedRepositoryIdsArr as $sharedRepositoryId){
                    if (is_null($entriesWithoutMetadata[$entryId])){
                        $xmlObj = new SimpleXMLElement('<metadata/>');
                    }
                    else{
                        $xmlObj = new SimpleXMLElement($entriesWithoutMetadata[$entryId]->asXML());
                    }
                    $this->addTermsOfUseXmlChild($xmlObj, $sharedRepositoryId);
                    $entriesWithoutMetadata[$entryId] = $xmlObj;
                }
            }
            if (!empty($entriesWithMetadata)){
                $this->setEntriesMetadata($TermsOfUseProfileId,$entriesWithMetadata, true);
            }
            if (!empty($entriesWithoutMetadata)){
                $this->setEntriesMetadata($TermsOfUseProfileId,$entriesWithoutMetadata, false);
            }

        }
        else
        {
            if (empty($TermsOfUseProfileId)){
                Kms_Log::log('entry: TermsOfUseProfileId not configured' , Kms_Log::DEBUG);
            }
            elseif (!count($entriesArr)){
                Kms_Log::log('entry: no entries given' , Kms_Log::DEBUG);
            }
            elseif (!count($sharedRepositoryIdsArr)){
                Kms_Log::log('entry: no shared repositories given' , Kms_Log::DEBUG);
            }
        }
    }

    private function addTermsOfUseXmlChild(SimpleXMLElement &$xmlObj, $categoryId)
    {
        $sharedRepository = $xmlObj->addChild(self::METADATA_TERMS_OF_USE_KEY_PATH);
        $sharedRepository->addChild('userId', Kms_Plugin_Access::getId());
        $sharedRepository->addChild('categoryId', $categoryId);
        $sharedRepository->addChild('time', time());
    }

    /**
	* get the entry/s metadata from the api
	* @param string $profileId - metadata profile id
	* @param string $entryIds
	* @throws Kaltura_Client_Exception
	* @return array of metadata list action
	*/
    private function getEntriesMetadata($profileId, $entryIds)
    {
        $metadata = array();

        if (!empty($profileId) || !empty($entryIds))
        {
            $filter = new Kaltura_Client_Metadata_Type_MetadataFilter();
            $filter->objectIdIn = $entryIds;
            $filter->metadataProfileIdEqual = $profileId;
            $filter->metadataObjectTypeEqual = Kaltura_Client_Metadata_Enum_MetadataObjectType::ENTRY;
            
            $cacheParams = Kms_Resource_Cache::buildCacheParams($filter);
            $cacheResult = Kms_Resource_Cache::apiGet('entriesMetadata', $cacheParams);
            
            if (!$cacheResult){
                $client = Kms_Resource_Client::getAdminClient();
                $metadataPlugin = Kaltura_Client_Metadata_Plugin::get($client);
                
                $userId = Kms_Plugin_Access::getId();
                $entryIdsArr = !empty($entryIds) ? explode(',', $entryIds): array();
                $cacheTags[] = 'user_' . $userId;
                foreach($entryIdsArr as $entryId){
                    $cacheTags[] = 'entry_' . $entryId;
                }
                
                try {
                    $metadata = $metadataPlugin->metadata->listAction($filter);
                    Kms_Resource_Cache::apiSet('entriesMetadata', $cacheParams, $metadata, $cacheTags);
                }
                catch (Kaltura_Client_Exception $e)
                {
                    Kms_Log::log('entry: Failed getting metadata for entry Ids [' . $entryIds . '] ' . $e->getCode() . ': ' . $e->getMessage(), Kms_Log::ERR);
                    throw new Kaltura_Client_Exception($e->getMessage(), $e->getCode());
                }
            }
        }
        else
        {
            Kms_Log::log('entry: Empty profile id [' . $profileId .'] or entry ids ['. $entryIds .']' , Kms_Log::ERR);
        }

        return $metadata;
    }

    /**
	* set the entry metadata in the api
	* @param string $profileId
	* @param array $entriesMetadata:
	* 			if $shouldUpdate -  keys are the entry ids, 2nd keys are the metadata id and the values are the XML obj of SimpleXMLElement
	* 								e.g: [entryId] => Array
    *								(
    *    								[metadataId] => <matadata> </metadata>
    *								)
    *			else (should add) - keys are the entry ids and the values are the XML obj of SimpleXMLElement
    *								e.g.: [entryId] => <matadata> </metadata>
	* @param bool $shouldUpdate
	* @throws Kaltura_Client_Exception
	*/
    private function setEntriesMetadata($profileId, array $entriesMetadata, $shouldUpdate = true)
    {
        if (!empty($profileId) && count($entriesMetadata))
        {
            $client = Kms_Resource_Client::getAdminClient();
            $config = $client->getConfig();
            $config->curlTimeout = 120; //increase timeout to 120 secs
            $client->setConfig($config);
            $metadataPlugin = Kaltura_Client_Metadata_Plugin::get($client);
            $client->startMultiRequest();

            $userId = Kms_Plugin_Access::getId();
            $cacheTags = array();

            if ($shouldUpdate)
            {// existing metadata - update metadata
                foreach ($entriesMetadata as $entryId => $metadata){
                   $metadataId = key($metadata);
                    $xmlObj = $entriesMetadata[$entryId][$metadataId];
                    $cacheTags[] = 'entry_' . $entryId;
                    $metadataPlugin->metadata->update($metadataId, $xmlObj->asXML());
                }
            }
            else
            {// no metadata - add new metadata
                foreach ($entriesMetadata as $entryId => $xmlObj){
                    $cacheTags[] = 'entry_' . $entryId;
                    $metadataPlugin->metadata->add($profileId,Kaltura_Client_Metadata_Enum_MetadataObjectType::ENTRY, $entryId, $xmlObj->asXML());
                }
            }

            $res = $client->doMultiRequest();

            $config->curlTimeout = 30; //restore to default
            $client->setConfig($config);
            
            foreach ($res as $object){
                // handle multi request errors
                if ($object instanceof Kaltura_Client_Exception)
                {
                    Kms_Log::log('entry: Failed adding metadata for profile id ['. $profileId .']. ' . $object->getCode() . ': ' . $object->getMessage(), Kms_Log::ERR);  
                }
            }
            
            Kms_Resource_Cache::apiClean('entriesMetadata', array(''), $cacheTags);
        }
        else
        {
            Kms_Log::log('entry: Empty profileId / entriesMetadata in ' . __FUNCTION__ , Kms_Log::DEBUG);
        }
    }

}

