<?php

/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * Description of Upgrade
 *
 * @author gonenradai
 */
class UpgradeController extends Zend_Controller_Action
{
    private $_autoUpgrade = false;
    
    public function init()
    {
        set_time_limit(0);
        $this->_translate = Zend_Registry::get('Zend_Translate');
        
        if(!defined("KMS_UPGRADE_CONTROLLER_ALLOWED"))
        {
            $message = $this->_translate->translate("This instance does not require upgrade at this time");
            Kms_Log::log('install: '.$message, Kms_Log::CRIT);
            throw new Exception($message);
        }
        
        if(defined("KMS_UPGRADE_FORCE_AUTOUPGRADE"))
        {
            $this->_autoUpgrade = true;
        }
        
        /* Initialize contexts here */
        $contextSwitch = $this->_helper->getHelper('contextSwitch');

        $ajaxC = $contextSwitch->setContext('ajax', array());
        $ajaxC->setAutoDisableLayout(false);
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->addActionContext('autoupgrade', 'ajax')->initContext();
        $this->_helper->contextSwitch()->initContext();
        
        /* Initialize action controller here */
        $this->_helper->layout->setLayout('setup');
        
        Kms_Resource_Config::setConfiguration('debug', 'logLevel', Kms_Log::DEBUG);
        Kms_Log::setDebugLevel();
        
        // tempprary enable the api debug log for the install process
        Kms_Resource_Config::setConfiguration('debug', 'kalturaDebug', 1);
    }
    
    /**
     * Action is loaded when Kms_Plugin_Upgrade identifies that an upgrade is needed, and only in "package" mode.
     * in SaaS mode - action should be called explicitly
     */
    public function upgradeAction()
    {
        if($this->_autoUpgrade)
        {
            $this->_forward('autoupgrade');
            return;
        }
        
        // 1. check requirements - if not good, forward to missing-requirements
        $reqs = new Kms_Setup_Requirements();
        $this->view->status = $reqs->getStatus();
        if(!$reqs->getStatus())
        {
            $this->_forward('missing-requirements', 'upgrade', 'default', array('reqs' => $reqs));
            return;
        }
        // TODO: should check Kms_Setup_Upgrade::checkWritePermissionsForMigration(); ???
        
        try
        {
            // 2. select upgrade class through factory
            Kms_Setup_UpgradeMgr::isUpgradeNeeded(); // call to catch exception of too-old source version
            $upgrades = Kms_Setup_UpgradeMgr::getUpgradeObjs();
        }
        catch(Kms_Setup_Exception $ex)
        {
            $this->_helper->viewRenderer('upgrade-not-supported');
            return;
        }
        
        $formElements = array();
        $firstUpgrade = reset($upgrades);
        $formElements = $firstUpgrade->getDefaultUpgradeFormElements();
        foreach($upgrades as $upgrade)
        {
            if($upgrade->requireAdditionalInfo())
            {
                $formElements = array_merge($upgrade->getAdditionalInfoFormElements(), $formElements);
            }
        }
            
        // upgrade action could be loaded in post, through additional info form submission
        if($this->getRequest()->isPost())
        {
            $form = $this->buildForm($formElements);
            // get the post data to perform validation
            $postData = $this->getRequest()->getParams();
            $formValid = $form->isValid($postData);
            // if form is valid - send post data to upgrade classes so they can use it later
            if($formValid)
            {
                foreach($upgrades as $upgrade)
                {
                    $upgrade->processFormSubmission($postData);
                }
            }
        }
        
        // check if we're not in post at all, OR if we are in post but the form is not valid
        if(!$this->getRequest()->isPost() || (isset($formValid) && !$formValid))
        {
            // if there are no form elements: (1) we are probably not in post (2) we do not want to forward to additional-info form
            if(count($formElements))
            {
                $options = array(
                    'fields' => $formElements,
                );
                // if for is not valid, means we are in POST mode - send post data to additional-info action to populate the frm with user input
                if((isset($formValid) && !$formValid))
                {
                    $options['postData'] = $postData;
                }
                $this->_forward('additional-info', 'upgrade', 'default', array('fields' => $formElements));
                return;
            }
        }
        
        try
        {
            $this->doUpgrade($upgrades, $postData);
        }
        catch(Exception $ex)
        {
            // if deployment fails - move to error page
            Kms_Log::log("Install: Deployment Failed. Error [{$ex->getMessage()}] ", Kms_Log::CRIT);
            $this->view->deploymentErrors = Kms_Setup_Deployment::getDeploymentErrors();
            $this->view->pagehead = $this->_translate->translate('Upgrade Error');
            $this->_helper->viewRenderer('deploy-error');
            return;
        }
       
        // 7. forward to complete action, can include specific "new in version" data per KMS version
        $this->_forward('upgrade-complete');
        
    }
    
    /**
     * method to perform common upgrade steps (common between UI/UX upgrade in package and automatic in SaaS)
     * 
     * @param array $upgrades array of Kms_Setup_Upgrade_Abstract objects
     * @param array $postData
     */
    private function doUpgrade($upgrades, $postData)
    {
        // 3. run configuration migration - cumulative upgrade from detected version up to latest
        foreach($upgrades as $upgrade)
        {
            $upgrade->migrateConfigurations();
        }

        // 4. run deployment on the upgradeMgr - deployment is absolute
        // TODO - how does runDeplyment gets the info of which values not to override... if needed...
        $overrideUiConfs = $postData[Kms_Setup_Upgrade_Abstract::OVERRIDE_UICONFS_FIELD_NAME];
        if($overrideUiConfs == Kms_Setup_Upgrade_Abstract::OVERRIDE_UICONFS_RADIO_VAULE_YES)
        {
            $shouldOverrideUiConfs = true;
        }
        else
        {
            $shouldOverrideUiConfs = false;
        }
        Kms_Setup_UpgradeMgr::runDeployment($shouldOverrideUiConfs);
        
        
        // make sure cache.ini is set if not existing (upgrade onto clean package)
        Kms_Setup_Common::initCacheConfigFile();
        
        // 5. update version # in config - if we reached here we completed the upgrade successfully
        Kms_Setup_UpgradeMgr::updateConfigVersion();
        
        // 6. clear cache
        Kms_Resource_Cache::apiWipe();
        Kms_Resource_Cache::appWipe();
    }
    
    /**
     * Action to run upgrade automatically for SaaS
     * @return type
     * @throws Kms_Setup_Exception
     */
    public function autoupgradeAction()
    {
        // remove layout as we want to return machine-readable output
        $this->_helper->layout->disableLayout();
        // force working in ajax context as we want to return machine-readable output
        $this->_helper->contextSwitch()->initContext('ajax');
        // check for KS in request - autoupgrade requires authentication
        $ks = $this->getRequest()->getParam('ks');
        if(!$ks)
        {
            Kms_Log::log("Autoupgrade: missing KS in request", Kms_Log::ERR);
            // no KS - render error and exit
            $this->_helper->viewRenderer('error');
            return;
        }
        
        $client = Kms_Resource_Client::getAdminClientNoEntitlement();
        try
        {
            $res = $client->session->get($ks);
            if(time() > $res->expiry)
            {
                Kms_Log::log("Autoupgrade: KS expired", Kms_Log::ERR);
                // KS expired - render error and exit
                $this->_helper->viewRenderer('error');
                return;
            }
        }
        catch(Kaltura_Client_Exception $ex)
        {
            // bad KS - render error and exit
            Kms_Log::log("Autoupgrade: caught exception opening KS - ".$ex->getMessage(), Kms_Log::ERR);
            $this->_helper->viewRenderer('error');
            return;
        }
        
        try
        {
            // 2. select upgrade class through factory
            Kms_Setup_UpgradeMgr::isUpgradeNeeded(); // call to catch exception of too-old source version
            $upgrades = Kms_Setup_UpgradeMgr::getUpgradeObjs();
            // if auto upgrade but there are no upgrade classes - exit with error
            if(!count($upgrades))
            {
                Kms_Log::log("Autoupgrade: no upgrade objects", Kms_Log::ERR);
                throw new Kms_Setup_Exception("no upgrade objects");
            }
        }
        catch(Kms_Setup_Exception $ex)
        {
            Kms_Log::log("Autoupgrade: caught exception during upgrade - ".$ex->getMessage(), Kms_Log::ERR);
            $this->_helper->viewRenderer('error');
            return;
        }
        
        // collect form values from upgrade classes - this is instead of collecting user-input.
        // in automatic mode we decide the values
        $formDefaultValues = array();
        $firstUpgrade = reset($upgrades);
        $formDefaultValues = $firstUpgrade->getDefaultUpgradeDefaultFormValues();
        foreach($upgrades as $upgrade)
        {
            if($upgrade->requireAdditionalInfo())
            {
                $elements = $upgrade->getAdditionalInfoFormElements();
                $values = $upgrade->getAdditionalInfoDefaultFormValues();
                if(count($elements) && !count($values))
                {
                    // upgrade class requires user input but does not provide any default value
                    throw new Kms_Setup_Exception("Upgrade class ".get_class($upgrade)." does not return default values for autoupgrade but has form elements");
                }
                $formDefaultValues = array_merge($values, $formDefaultValues);
            }
        }
        
        // pass values to upgrade objects as would normally be done
        foreach($upgrades as $upgrade)
        {
            $upgrade->processFormSubmission($formDefaultValues);
        }
        
        try
        {
            // perform upgrade steps, on error exit
            $this->doUpgrade($upgrades, $formDefaultValues);
        }
        catch(Exception $ex)
        {
            Kms_Log::log("Autoupgrade: caught exception during upgrade - ".$ex->getMessage(), Kms_Log::ERR);
            $this->_helper->viewRenderer('error');
            return;
        }
    }
    
    // action to display requirements screen in case something failed (in upgradeAction)
    public function missingRequirementsAction()
    {
        $reqs = $this->getRequest()->getParam('reqs');
        $this->view->list = $reqs->getList();
        $this->view->status = $reqs->getStatus();
    }
    
    public function upgradeCompleteAction()
    {
        
    }
    
    // action to display form for collecting user inupt before upgrade
    public function additionalInfoAction()
    {
        $formElements = $this->getRequest()->getParam('fields');
        $form = $this->buildForm($formElements);
        
        if($this->getRequest()->getParam('postData'))
        {
            $form->populate($this->getRequest()->getParam('postData'));
        }
        
        $this->view->form = $form->render();
    }
    
    // helper function to build form out of a collection of elements
    private function buildForm($elements)
    {
        $form = new Zend_Form();
        $form->setName('Additional Information Required');
        $form->setMethod('POST');
        $form->setAction($this->view->baseUrl('upgrade/upgrade'));
        foreach($elements as $element)
        {
            $form->addElement($element);
        }
        
        return $form;
    }
}

?>
