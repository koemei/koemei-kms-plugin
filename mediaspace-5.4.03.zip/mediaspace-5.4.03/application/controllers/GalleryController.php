<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class GalleryController extends Zend_Controller_Action
{

    private $_flashMessenger;
    
    private $_translate = null;
    
    public function init()
    {
        /* init translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');        

        /* initialize flashMessenger */
        $this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');  
        $this->_flashMessenger->setNamespace('errors');
        $this->view->errors = $this->_flashMessenger->getMessages() + $this->_flashMessenger->getCurrentMessages();
        $this->_flashMessenger->clearCurrentMessages();
        $this->_flashMessenger->clearMessages();
        $this->_flashMessenger->setNamespace('warnings');
        $this->view->warnings = $this->_flashMessenger->getMessages() + $this->_flashMessenger->getCurrentMessages();
        $this->_flashMessenger->clearCurrentMessages();
        $this->_flashMessenger->clearMessages();
        $this->_flashMessenger->setNamespace('default');
        $this->view->messages = $this->_flashMessenger->getMessages() + $this->_flashMessenger->getCurrentMessages();
        $this->_flashMessenger->clearCurrentMessages();
        $this->_flashMessenger->clearMessages();

        
        /* Initialize contexts here */
        $contextSwitch = $this->_helper->getHelper('contextSwitch');
        if(!$contextSwitch->getContext('ajax'))
        {
            $ajaxC = $contextSwitch->addContext('ajax', array());
            $ajaxC->setAutoDisableLayout(false);
        }
        if(!$contextSwitch->getContext('dialog'))
        {
            $dialogC = $contextSwitch->addContext('dialog', array());
            $dialogC->setAutoDisableLayout(false);
        }
        if(!$contextSwitch->getContext('script'))
        {
            $scriptC = $contextSwitch->addContext('script', array());
            $scriptC->setAutoDisableLayout(false);
        }
        
        $contextSwitch->setSuffix('dialog', 'dialog');
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('script', 'script');
        $contextSwitch->addActionContext('view', 'ajax')->initContext();
        $contextSwitch->addActionContext('search', 'ajax')->initContext();
        $contextSwitch->addActionContext('delete', 'dialog')->initContext();
        $this->_helper->contextSwitch()->initContext();
    }
    
	/**
     * access denied by contextual role - does not require login
     */
    public function deniedAction()
    {
        
    }
    
	/**
     * saves a gallery
     */
    private function save($data)
    {
        $model = Kms_Resource_Models::getGallery();
    
        // save the data
        $data[Application_Form_EditCategory::FORM_NAME]['moderation'] =
        	(!empty($data[Application_Form_EditCategory::FORM_NAME]['options']) 
        		&& is_array($data[Application_Form_EditCategory::FORM_NAME]['options']) 
        		&& in_array('moderation',$data[Application_Form_EditCategory::FORM_NAME]['options']) ? 1 : 0);
        
        $gallery = $model->save($data[Application_Form_EditCategory::FORM_NAME]);

        return $gallery;
    }
    
    /**
     * deletes a gallery
     */
    public function deleteAction()
    {
        $this->view->channelName = $this->getRequest()->getParam('channelname');
        $this->view->channelId = $this->getRequest()->getParam('channelid');
        $this->view->categoryId = $this->getRequest()->getParam('categoryid');
        
        // if confirmed - delete
        if ($this->getRequest()->getParam('confirm') == true){
            $model = Kms_Resource_Models::getGallery();
            
            // delete the gallery
            $model->delete($this->getRequest()->getParam('channelname'), $this->getRequest()->getParam('channelid'));
        }
    }
    
	/**
     * edit an existing gallery
     */
    public function editAction()
    {
        $model = Kms_Resource_Models::getGallery();

        // get the category
        try{
            $currentgallery = $model->get($this->getRequest()->getParam('categoryname'), false, $this->getRequest()->getParam('categoryid'));
            if (empty($currentgallery)){
                throw new Zend_Controller_Action_Exception('', 404);
            }
            
            $gallery = (array) $currentgallery;
        }
        catch (Kaltura_Client_Exception $e){
            // forward to the 404 page
            throw new Zend_Controller_Action_Exception('', 404);
        }
        $this->view->tabName = 'basic';
        $tab = $this->getRequest()->getParam('tab');
        $this->view->tabActive = (!$tab || $tab == $this->view->tabName);
        
        // get the form
        $this->view->form = new Application_Form_EditGallery();
        $this->view->form->setAction($this->view->baseUrl('gallery/edit/' . $this->getRequest()->getParam('categoryname') . '/' . $this->getRequest()->getParam('categoryid')));

        // form values
        if ($this->getRequest()->isPost())
        {
            // form submit - get the post data
            $data = $this->getRequest()->getPost();
            
            // validate the form
            if ($this->view->form->isValid($data))
            {
	            if ($model->validateCategoryForSave($currentgallery, $data[Application_Form_EditCategory::FORM_NAME]))
            	{
	                // form is valid - forward to the save action
	                $this->save($data);
                    $this->view->messages[] = $this->_translate->translate('The information was saved successfully');
            	}
            	else {
            		$error = $this->_translate->translate('A category with the same name already exists. Please choose a different category name.');
                    $this->view->form->getElement('name')->addError($error);
            	}
            }
            // override values with user input            
            $gallery = $data[Application_Form_EditGallery::FORM_NAME];
        }

        // populate the form with the gallery data
        $this->view->form->populate($gallery);
        
        // set the name for the gallery delete link
        $this->view->category = $currentgallery;
        
        // check contextual role
        $role = $model->getUserRoleInCategory($currentgallery->name, Kms_Plugin_Access::getId(), $currentgallery->id);
        if ($role != Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER)
        {
            unset($this->view->form);
        }
        
        $tabs = array();

        // details pane
        if (!empty($this->view->form)){
            $details = new Kms_Type_Tab_Core($this->_translate->translate('Details'), $this->view->form , array('id' => 'details'),'',-2);
            $tabs[] = $details;
        }

        // modules tabs
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Gallery_Edit') as $name => $module)
                $tabs = array_merge($module->getGalleryEditTabs($currentgallery),$tabs);

        // sort the tabs
        $this->view->tabs = $tabs;
        
    }
    
	/**
     * Search media inside a gallery
     */
    public function searchAction() 
    {
   		$galleryModel = Kms_Resource_Models::getGallery();
        $request = $this->getRequest();
        $gallery = $galleryModel->get(null, false, $this->getRequest()->getParam('catid'));
        
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $request->getParam('keyword'),
        );
        
        $params = $this->addSort($params);
        
        if (!empty($gallery))
        {
        	$this->view->gallery = $gallery;
            if ($gallery->membership == Application_Model_Category::MEMBERSHIP_PRIVATE){
                $role = $galleryModel->getUserRoleInGallery($gallery->name, Kms_Plugin_Access::getId(), $gallery->id);
                
                if ($role == Application_Model_Category::CATEGORY_USER_NO_ROLE){
                    // the user does not have access to this private gallery
                    Kms_Log::log('accessPlugin: Access denied to gallery:view because of contextual access');                    
                    throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
                }
            }
	                
            // pass the parameters to the view
            $entryModel = Kms_Resource_Models::getEntry();
        	$this->view->params = $params;
            $this->view->entries = $entryModel->getEntriesByCategory($gallery->id, $params);
            $this->view->totalCount = $entryModel->getLastResultCount();


            // tabs
             $tabs = array();

            // media tab
            $media = new Kms_Type_Tab_Core('<span id="mediacount" >' . $this->_translate->translate("Search Media"), $this->_translate->translate('Loading') . '&hellip;</span>', array('id'=> 'search-media'), '',-1);
            $tabs[] = $media;

            // module tabs
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Gallery_SearchTabs') as $name => $module){
                $tabs = array_merge($tabs, $module->getGallerySearchTabs($gallery, $params['keyword']));
            }    

            $this->view->tabs = $tabs;
        }
        else {
            throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
        }
    }
    

    /**
     * view a single gallery
     */
    public function viewAction()
    {
        $model = Kms_Resource_Models::getGallery();
        $gallery = $model->get($this->getRequest()->getParam('categoryname'), false, $this->getRequest()->getParam('categoryid'));
        $request = $this->getRequest();

        $isReset = $request->getParam('reset');	// is this a page reset, like following "add media"
        
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $request->getParam('keyword'),
            'tag' => $request->getParam('tag'),
            'categoryid' => $this->getRequest()->getParam('categoryid'),
            'pageSize' => Kms_Resource_Config::getConfiguration('gallery','entriesPageSize'),
        );
        
        $params = $this->addSort($params);

        if (!empty($gallery))
        {
            $this->view->gallery = $gallery;

            $userId = Kms_Plugin_Access::getId();
            $role = $model->getUserRoleInGallery($gallery->name, $userId, $gallery->id);
			
            if ($role == Application_Model_Category::CATEGORY_USER_NO_ROLE && $gallery->privacy != Kaltura_Client_Enum_PrivacyType::ALL &&
            	Zend_Auth::getInstance()->getIdentity()->getRole() == Kms_Plugin_Access::ANON_ROLE)
            {
            	$this->_forward('login', 'user', null,array('ref'=>$this->view->baseUrl('category/' . $this->getRequest()->getParam('categoryname') . '/' . $this->getRequest()->getParam('categoryid'))));
                // the user does not have access to this private channel 
               // Kms_Log::log('accessPlugin: Access denied to channel:view because of contextual access');                  
                //throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
            }

            if ($role == Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER)
            {
                $this->view->manager = true;
            }

            // pass the parameters to the view
            $this->view->params = $params;

            // get the gallery entries
            $entryModel = Kms_Resource_Models::getEntry();
            $this->view->entries = $entryModel->getEntriesByCategory($gallery->id, $params);
            
            
            $tabs = array();
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Gallery_Tabs') as $name => $module){
                $tabs = array_merge($module->getGalleryTabs($gallery),$tabs);
            }
            
            $this->view->totalCount = $entryModel->getLastResultCount();
            // add the "media" tab to the tabs we got from the controller
            $header = $this->_translate->translate("%1 Media", null, array($entryModel->getLastResultCount()));
			$media = new Kms_Type_Tab_Core($header, $this->view->partial('partials/category/tabs/media.phtml', array('category' => $gallery)), array('id'=> 'media'), '',-1);
			$tabs[] = $media;
			
			// sort the tabs
            $this->view->galleryTabs = $this->view->sort($tabs);
        }
        else{
            throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);            
        }
        
    	if (!empty($isReset)) {
        	$this->render('view-reset');
        	return;
        }
    }
    
  
    /**
     * adds value for 'sort' parameter if missing
     * @param array $params  search parameters
     * @return altered sort parameters
     */
    private function addSort(array $params) {
        if(empty($params['sort']))
        {
            //modules may define what is a default sorter for specific type
            //should be only one module per type
            $models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Type');
            foreach ($models as $model)
            {
                $sorter = $model->getDefaultSorter(($params['type']));
                //we should get only one model for type
                if (!empty($sorter))
                {
                    $params['sort'] = $sorter;
                    break;
                }
            }
            //if the module doesn't define default sorter - take default for gallery
            if (empty($params['sort']))
            {
                // load the default sort method from the configuration
                $params['sort'] = Kms_Resource_Config::getConfiguration('gallery', 'sortMediaBy');
            }
        }
        return $params;
    }    
}



