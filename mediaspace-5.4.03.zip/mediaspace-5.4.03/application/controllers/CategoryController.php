<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
* To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * Category section Controller.
 * @author nadav.b
 *
 */
class CategoryController extends Zend_Controller_Action
{   
	private $_translate = null;
    private $_flashMessenger = null;
    
    /**
     * (non-PHPdoc)
     * @see Zend_Controller_Action::init()
     */
    public function init()
    {
    	/* initialize flashMessenger */
		$this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');
		$this->_flashMessenger->setNamespace('errors');
        $this->view->errors = is_array($this->view->errors) ? $this->view->errors : array();
		$this->view->errors = array_merge($this->_flashMessenger->getMessages(), $this->view->errors, $this->_flashMessenger->getCurrentMessages());
		$this->_flashMessenger->clearCurrentMessages();
		$this->_flashMessenger->clearMessages();
		$this->_flashMessenger->setNamespace('default');
        $this->view->messages = is_array($this->view->messages) ? $this->view->messages : array();        
		$this->view->messages = array_merge($this->_flashMessenger->getMessages(), $this->view->messages, $this->_flashMessenger->getCurrentMessages());
		$this->_flashMessenger->clearCurrentMessages();
		$this->_flashMessenger->clearMessages();
        
        /* initialize translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');
        
        $contextSwitch = $this->_helper->getHelper('contextSwitch');
        if(!$contextSwitch->getContext('ajax'))
        {
            $ajaxC = $contextSwitch->addContext('ajax', array());
            $ajaxC->setAutoDisableLayout(false);
        }
        if (!$contextSwitch->getContext('dialog'))
        {
            $dialogC = $contextSwitch->addContext('dialog', array());
            $dialogC->setAutoDisableLayout(false);
        }
        
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('dialog', 'dialog');
        
        $contextSwitch->addActionContext('remove-entry', 'ajax')->initContext();
        $contextSwitch->addActionContext('remove-entry', 'dialog')->initContext();
        
        $this->_helper->contextSwitch()->initContext();
    }
    
    public function removeEntryAction()
    {
        // set allowed to false in the beginning
        $this->view->allowed = false;
        $entryId = $this->getRequest()->getParam('entry');
        $categoryId = $this->getRequest()->getParam('category');

        $category = Kms_Resource_Models::getCategory()->get('',false,$categoryId);

        if (Kms_Resource_Models::getChannel()->isCategoryAChannel($category))
        {
        	$isManager = Kms_Resource_Models::getChannel()->getUserRoleInChannel($category->name, Kms_Plugin_Access::getId(), $category->id) == Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER;
        	$this->view->type= 'channel';
        }
        else
        {
        	$isManager = Kms_Resource_Models::getGallery()->getUserRoleInGallery($category->name, Kms_Plugin_Access::getId(), $category->id) == Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER;
        	$this->view->type= 'category';
        }
        
        $this->view->confirmed = 0;
        if($entryId && $categoryId)
        {
            $model = Kms_Resource_Models::getEntry();
            $entry = $model->get($entryId);
            // check if I am the owner of this entry, or a category manager
            if(Kms_Plugin_Access::isCurrentUser($entry->userId) || $isManager)
            {
                $this->view->allowed = true;
            
                $this->view->entryId = $entryId;
                $this->view->categoryId = $categoryId;
                
                // check for confirmation
                $confirm = $this->getRequest()->getParam('confirm');
                if($confirm == '1')
                {
                    $this->view->confirmed = 1;
                    // remove the category via Entry model
	                try
					{
	            		$result = $model->updateCategoriesFrom(array($entryId),array($categoryId),array());
						if($result)
	                    {
							//$this->view->warnings[] = $this->_translate->translate('Error removing media');
						}
						else
						{
							//$this->view->messages[] = $this->_translate->translate('Media was removed');	
						}
					}
	            	catch(Kaltura_Client_Exception $e)
	              	{
					}
                }
            }
        }
    }
    
    /**
     * access denied by contextual role - does not require login
     */
    public function deniedAction()
    {
        
    }
}