<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/
/*
 * Author: Nadav.B
 */
class SearchController extends Zend_Controller_Action
{

    private $_flashMessenger;
    
    private $_translate = null;
    
    public function init()
    {
        /* init translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');        
        
        /* initialize flashMessenger */
        $this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');  
        $this->_flashMessenger->setNamespace('default');
        $this->view->messages = $this->_flashMessenger->getMessages();
        
        /* Initialize contexts here */
        $contextSwitch = $this->_helper->getHelper('contextSwitch');
        if(!$contextSwitch->getContext('ajax'))
        {
            $ajaxC = $contextSwitch->addContext('ajax', array());
            $ajaxC->setAutoDisableLayout(false);
        }
        if(!$contextSwitch->getContext('dialog'))
        {
            $dialogC = $contextSwitch->addContext('dialog', array());
            $dialogC->setAutoDisableLayout(false);
        }
        if(!$contextSwitch->getContext('script'))
        {
            $scriptC = $contextSwitch->addContext('script', array());
            $scriptC->setAutoDisableLayout(false);
        }
        
        $contextSwitch->setSuffix('dialog', 'dialog');
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('script', 'script');
        
        $contextSwitch->addActionContext('index', 'ajax')->initContext();
        $contextSwitch->addActionContext('search', 'ajax')->initContext();
        
        $this->_helper->contextSwitch()->initContext();
        
    }
    
    public function createdbyAction()
    {
    	$request = $this->getRequest();
    	
    	$this->view->name = $request->getParam('name');
    	
    	$entryModel = Kms_Resource_Models::getEntry();
    	
    	$this->view->title = $this->_translate->translate("Search for media from:");
    	
    	$this->view->searchKeyword = $this->view->name;
    	
    	$params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $this->view->searchKeyword,
        );

		$this->view->params = $params;
    	
    	$this->view->entries  = $entryModel->getEntriesByUserId($this->view->name, $params);
    	
    	$this->view->renderOnlyIndexTab = true;
    	
    	if ($request->getParam('format') == 'ajax')
    		$this->renderScript('search/index.ajax.phtml');
    	else
    		$this->renderScript('search/index.phtml');
    }

    public function indexAction()
    {        
        $request = $this->getRequest();
        
        if ($request->getParam('tagid'))
        	$this->view->title = $this->_translate->translate("Search for tag:");	
        else
        	$this->view->title = $this->_translate->translate("Search for:");
        
        
        $searchKeyword = $request->getParam('searchkeyword');
        
        $this->view->activeTab = $request->getParam('tab');
        
        $entryModel = Kms_Resource_Models::getEntry();
        
        $totalEntries=0;
                
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $searchKeyword,
            'tag' => $request->getParam('tagid'),
        );

		$this->view->params = $params;
		
		$this->view->renderOnlyIndexTab = false;
		            
		if ($request->getParam('tagid'))
        	$this->view->searchKeyword = $request->getParam('tagid');	
        else
        	$this->view->searchKeyword = $searchKeyword;
		
		// set page size to the wide page size
		$entries = $entryModel->getEntriesByKeyword($searchKeyword, $params);
		

            
        // get the total number of entries
        $totalEntries = $totalEntries ? $totalEntries: $entryModel->getLastResultCount();
		        
        $this->view->totalEntries = $totalEntries;
        $this->view->entries = $entries;
    }
    
    public function channelsAction()
    {
    	$model = Kms_Resource_Models::getChannel();
        
    	$searchKeyword = $this->getRequest()->getParam('searchkeyword');
    	
        $params = array(
				'type' => $this->getRequest()->getParam('type'),
                'page' => $this->getRequest()->getParam('page'),
                'sort' => $this->getRequest()->getParam('sort'),
                'keyword' => $this->getRequest()->getParam('searchkeyword'),
        		'tag' => $this->getRequest()->getParam('tagid'),
        );
        
        if (!$params['sort']){
            $params['sort'] = 'date';
        }
    
        $this->view->searchKeyword = $searchKeyword;
        
        $this->view->params = $params;
        $this->view->channels = $model->getChannelsThumbnail($model->getChannelList($params));
        
        $this->view->renderOnlyIndexTab = false;
        
        $this->view->totalCount = $model->getTotalCount();

        $this->view->channelStatsHtmlElements = Kms_Helper_Channel_Stats::getChannelStatsHtmlElements($this->view->channels);

        $this->renderScript('search/channels.ajax.phtml');
     
    }
    
	public function galleriesAction()
    {
    	$model = Kms_Resource_Models::getGallery();
        
    	$searchKeyword = $this->getRequest()->getParam('searchkeyword');
    	
        $params = array(
				'type' => $this->getRequest()->getParam('type'),
                'page' => $this->getRequest()->getParam('page'),
                'sort' => $this->getRequest()->getParam('sort'),
                'keyword' => $this->getRequest()->getParam('searchkeyword'),
        );
        
      
        if (!$params['sort']){
            $params['sort'] = 'date';
        }
        
        $this->view->renderOnlyIndexTab = false;
                
        $this->view->searchKeyword = $searchKeyword;
        
        $this->view->params = $params;
        $this->view->galleries = $model->getGalleryList($params);      
        $this->view->totalCount = $model->getTotalCount();          
        
        $this->renderScript('search/gallery.ajax.phtml');
     
    }

}



