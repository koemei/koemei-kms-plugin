<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
* To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

/**
 * Channels section Controller.
 * @author talbone
 *
 */
class ChannelsController extends Zend_Controller_Action
{   
	private $_translate = null;
    private $_flashMessenger = null;
    
    /**
     * (non-PHPdoc)
     * @see Zend_Controller_Action::init()
     */
    public function init()
    {
    	/* initialize flashMessenger */
		$this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');
		$this->_flashMessenger->setNamespace('errors');
        $this->view->errors = is_array($this->view->errors) ? $this->view->errors : array();        
		$this->view->errors = array_merge($this->_flashMessenger->getMessages(), $this->view->errors, $this->_flashMessenger->getCurrentMessages());
		$this->_flashMessenger->clearCurrentMessages();
		$this->_flashMessenger->clearMessages();
		$this->_flashMessenger->setNamespace('default');
        $this->view->messages = is_array($this->view->messages) ? $this->view->messages : array();                
		$this->view->messages = array_merge($this->_flashMessenger->getMessages(), $this->view->messages, $this->_flashMessenger->getCurrentMessages());
		$this->_flashMessenger->clearCurrentMessages();
		$this->_flashMessenger->clearMessages();
		$this->_flashMessenger->setNamespace('warnings');
        $this->view->warnings = is_array($this->view->warnings) ? $this->view->warnings : array();                
		$this->view->warnings = array_merge($this->_flashMessenger->getMessages(), $this->view->warnings, $this->_flashMessenger->getCurrentMessages());
		$this->_flashMessenger->clearCurrentMessages();
		$this->_flashMessenger->clearMessages();
        
        /* initialize translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');
        
        $contextSwitch = $this->_helper->getHelper('contextSwitch');
        if(!$contextSwitch->getContext('ajax'))
        {
            $ajaxC = $contextSwitch->addContext('ajax', array());
            $ajaxC->setAutoDisableLayout(false);
        }
        if (!$contextSwitch->getContext('dialog'))
        {
            $dialogC = $contextSwitch->addContext('dialog', array());
            $dialogC->setAutoDisableLayout(false);
        }
        
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('dialog', 'dialog');
        
        $contextSwitch->addActionContext('index', 'ajax')->initContext();
        $contextSwitch->addActionContext('mychannels', 'ajax')->initContext();
        $contextSwitch->addActionContext('delete', 'dialog')->initContext();
        $contextSwitch->addActionContext('delete', 'ajax')->initContext();
        $contextSwitch->addActionContext('search', 'ajax')->initContext();
        $contextSwitch->addActionContext('view', 'ajax')->initContext();
        $contextSwitch->addActionContext('view-side-bar', 'ajax')->initContext();
        
        $this->_helper->contextSwitch()->initContext();
    }
    
    /**
     * list all channels
     */
    public function indexAction()
    {
        $model = Kms_Resource_Models::getChannel();
        
        $params = $this->getRequest()->getParams();
        unset($params['action']);
        unset($params['controller']);
        unset($params['format']);
        
        if (empty($params['sort'])){
            $params['sort'] = 'date';
        }
        //todo: change getChannelList function to get 2 "brute force" objects(pager&filter) instead of params
        $this->view->params = $params;
        $this->view->channels = $model->getChannelsThumbnail($model->getChannelList($params));
        
        $this->view->showUserTypeFilter = false;
        $this->view->ChannelNumber = $model->getTotalCount();
        $this->view->admin = false;
        $this->view->allowCreateChannel = Zend_Controller_Front::getInstance()
            ->getPlugin('Kms_Plugin_Access')->hasPermission('channels', 'create');
        $this->view->channelStatsHtmlElements = Kms_Helper_Channel_Stats::getChannelStatsHtmlElements($this->view->channels);
    }

    
    /**
     * adds value for 'sort' parameter if missing
     * @param array $params	search parameters
     * @return altered sort parameters
     */
    private function addSort(array $params) {
    	if(empty($params['sort']))
        {
        	//modules may define what is a default sorter for specific type
        	//should be only one module per type
        	$models = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Type');
        	foreach ($models as $model)
        	{
        		$sorter = $model->getDefaultSorter(($params['type']));
        		//we should get only one model for type
        		if (!empty($sorter))
        		{
        			$params['sort'] = $sorter;
        			break;
        		}
        	}
        	//if the module doesn't define default sorter - take default for gallery
        	if (empty($params['sort']))
        	{
            	// load the default sort method from the configuration
            	$params['sort'] = Kms_Resource_Config::getConfiguration('gallery', 'sortMediaBy');
        	}
        }
        return $params;
    }
    
    
    /**
     * Search media inside a channel
     */
    public function searchAction() {
   		$channelModel = Kms_Resource_Models::getChannel();
        $request = $this->getRequest();
        $channel = $channelModel->get($request->getParam('channelname'), false, $this->getRequest()->getParam('channelid'));
        
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $request->getParam('keyword'),
        );
        
        $params = $this->addSort($params);
        
        if (!empty($channel))
        {
        	$this->view->channel = $channel;
            if ($channel->membership == Application_Model_Category::MEMBERSHIP_PRIVATE){
                $role = $channelModel->getUserRoleInChannel($channel->name, Kms_Plugin_Access::getId(), $channel->id);
                
                if ($role == Application_Model_Category::CATEGORY_USER_NO_ROLE){
                    // the user does not have access to this private channel
                    Kms_Log::log('accessPlugin: Access denied to channel:view because of contextual access');                    
                    throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
                }
            }
	                
            // pass the parameters to the view
            $entryModel = Kms_Resource_Models::getEntry();
        	$this->view->params = $params;
            $this->view->entries = $entryModel->getEntriesByChannel($channel->id, $params);
            $this->view->totalCount = $entryModel->getLastResultCount();

            // tabs
            $tabs = array();

            // media tab
            $media = new Kms_Type_Tab_Core('<span id="mediacount" >' . $this->_translate->translate("Search Media"), $this->_translate->translate('Loading') . '&hellip;</span>', array('id'=> 'search-media'), '',-1);
            $tabs[] = $media;

            // module tabs
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Channel_SearchTabs') as $name => $module){
                $tabs = array_merge($tabs, $module->getGallerySearchTabs($channel, $params['keyword']));
            }    

            $this->view->tabs = $tabs;            
        }
        else {
            throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
        }
    }
    
    
    /**
     * show a channel
     */
    public function viewAction()
    {       
        $channelModel = Kms_Resource_Models::getChannel();
        $channel = $channelModel->get($this->getRequest()->getParam('channelname'), false, $this->getRequest()->getParam('channelid'));
        $request = $this->getRequest();
        
        $isReset = $request->getParam('reset');	// is this a page reset, like following "add media"
        
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
            'keyword' => $request->getParam('keyword'),
            'tag' => $request->getParam('tag'),
            'pageSize' => Kms_Resource_Config::getConfiguration('channels','entriesPageSize'),
        );
        
        $params = $this->addSort($params);
        
        if (!empty($channel))
        {
        	//$channelModel->getChannelsThumbnail(array($channel));
        	$this->view->channel = $channel;

            $userId = Kms_Plugin_Access::getId();
            $role = $channelModel->getUserRoleInChannel($channel->name, $userId, $channel->id);

            if ($channel->membership == Application_Model_Category::MEMBERSHIP_PRIVATE && $role == Application_Model_Category::CATEGORY_USER_NO_ROLE){
                // the user does not have access to this private channel
                Kms_Log::log('accessPlugin: Access denied to channel:view because of contextual access');                    
                throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
            }

            if ($role == Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER)
            {
            	$this->view->manager = true;
            }
            
            // pass the parameters to the view
        	$this->view->params = $params;
        	$entryModel = Kms_Resource_Models::getEntry();
            $this->view->entries = $entryModel->getEntriesByChannel($channel->id, $params);
            
            $tabs = array();
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Channel_Tabs') as $name => $module){
                $tabs = array_merge($module->getChannelTabs($channel),$tabs);
            }
            // add media tab	
            $header = $this->_translate->translate("%1 Media", null, array($entryModel->getLastResultCount()));
            $media = new Kms_Type_Tab_Core($header, $this->view->partial('partials/category/tabs/media.phtml',array('category' => $channel)), array('id'=> 'media'), '',-1);
			$tabs[] = $media;
            // sort the tabs
			$tabs = $this->view->sort($tabs);
            $this->view->channelTabs = $tabs;
        }
        else {
            throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
        }
        if (!empty($isReset)) {
        	$this->render('view-reset');
        	return;
        }
	}
	
	
	/**
	 * show the side bar on the channel/view page
	 */
	public function viewSideBarAction() {
		//TODO consider view-reset
		$channelModel = Kms_Resource_Models::getChannel();
        $channel = $channelModel->get($this->getRequest()->getParam('channelname'), false, $this->getRequest()->getParam('channelid'));
        $channelModel->getChannelsThumbnail(array($channel));
		$this->view->channel = $channel;
	}
	

    /**
     * edit an existing channel
     */
    public function editAction()
    {
        $model = Kms_Resource_Models::getChannel();

        // get the channel
        try {
            $currentChannel = $model->get($this->getRequest()->getParam('channelname'), false, $this->getRequest()->getParam('channelid'));
            if (empty($currentChannel)){
                throw new Zend_Controller_Action_Exception('', 404);
            }
            
            $channel = (array) $currentChannel;
        }
        catch (Kaltura_Client_Exception $e){
            // forward to the 404 page
            throw new Zend_Controller_Action_Exception('', 404);
        }
        $this->view->tabName = 'basic';
        $tab = $this->getRequest()->getParam('tab');
        $this->view->tabActive = (!$tab || $tab == $this->view->tabName);
        
        // get the form
        $this->view->form = new Application_Form_EditChannel();
        $this->view->form->setAction($this->view->baseUrl('channels/edit/' . $this->getRequest()->getParam('channelname') . '/' . $this->getRequest()->getParam('channelid')));

        // ignore post if this is _forward from createAction
        $nosave = $this->getRequest()->getParam('nosave');
        if ($this->getRequest()->isPost() && empty($nosave))
        {
            // form submit - get the post data
            $data = $this->getRequest()->getPost();
            
            // validate the form
            if ($this->view->form->isValid($data)){
            	if ($model->validateCategoryForSave($currentChannel, $data[Application_Form_EditCategory::FORM_NAME]))
            	{
	                // form is valid - forward to the save action
	                $this->save($data);
                    $this->view->messages[] = $this->_translate->translate('The information was saved successfully');
            	}
            	else {
            		$error = $this->_translate->translate('A channel with the same name already exists. Please choose a different channel name.');
                    $this->view->form->getElement('name')->addError($error);
            	}
            }
           	// override values with user input 
           	$channel = $data[Application_Form_EditCategory::FORM_NAME];
        }

        // populate the form with the channel data
        $this->view->form->populate($channel);
        
        // set the name for the channel delete link
        $this->view->channel = $currentChannel;
        
        // check contextual role
        $role = $model->getUserRoleInChannel($currentChannel->name, Kms_Plugin_Access::getId(), $currentChannel->id);
        if ($role != Kaltura_Client_Enum_CategoryUserPermissionLevel::MANAGER)
        {
            unset($this->view->form);
        }
        
        $tabs = array();

        // details pane
        if (!empty($this->view->form)){
            $details = new Kms_Type_Tab_Core($this->_translate->translate('Details'), $this->view->form , array('id' => 'details'), '',-2);
            $tabs[] = $details;
        }

        // modules tabs
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Channel_Edit') as $name => $module)
                $tabs = array_merge($module->getChannelEditTabs($currentChannel), $tabs);

        // sort the tabs
        $this->view->tabs = $tabs;
    }
    
    
    /**
     * creates a new channel
     */
    public function createAction()
    {
        // get the form
        if(!isset($this->view->form))
        {
            $this->view->form = new Application_Form_EditChannel();
        }
        
        // default values
        if ($this->getRequest()->isPost())
        {
            // get the post data
            $data = $this->getRequest()->getPost();
            $channel = $data[Application_Form_EditCategory::FORM_NAME];
            // populate the form with the channel data
            $this->view->form->populate($channel);
            
            // validate the form
            if ($this->view->form->isValid($data))
            {
                // form is valid - forward to the save action
                $channelName = $channel['name'];
                $exists = Kms_Resource_Models::getChannel()->isExists($channelName);
                if($exists)
                {
                    $error = $this->_translate->translate('Channel %1 already exists.', null, $channelName);
                    $this->view->form->getElement('name')->addError($error);
                }
                else
                {
                	$channel = $this->save($data);
                	$this->_flashMessenger->setNamespace('default');
	                $this->_flashMessenger->addMessage($this->_translate->translate('The information was saved successfully'));
                    $this->_forward('edit', 'channels', 'default', array('channelname' => $this->view->categoryNameForUrl($channel->name), 'channelid' => $channel->id, 'nosave' => true));
                }
            }
        }
    }

    
    /**
     * saves a channel
     */
    private function save($data)
    {
        $model = Kms_Resource_Models::getChannel();
    	$form_data = $data[Application_Form_EditCategory::FORM_NAME];
    	if (is_array($form_data) && 
    		array_key_exists('options', $form_data) &&
    		is_array($form_data['options']) &&
    		in_array('moderation',$form_data['options']))
    	{
    		$data[Application_Form_EditCategory::FORM_NAME]['moderation'] = 1;
    	}
    	else 
    	{
    		$data[Application_Form_EditCategory::FORM_NAME]['moderation'] = 0;
    	}
    	
        // save the data
        $channel = $model->saveChannel($data[Application_Form_EditCategory::FORM_NAME]);
    	
        return $channel;
    }
    
    /**
     * deletes a channel
     */
    public function deleteAction()
    {
        $this->view->channelName = $this->getRequest()->getParam('channelname');
        $this->view->channelId = $this->getRequest()->getParam('channelid');
        $this->view->categoryId = $this->getRequest()->getParam('categoryid');
        $this->view->redirectUrl = $this->view->baseUrl('channels');
        
        // if confirmed - delete
        if ($this->getRequest()->getParam('confirm') == true){
            $model = Kms_Resource_Models::getChannel();
            
            // delete the channel
            $model->delete($this->getRequest()->getParam('channelname'), $this->getRequest()->getParam('channelid'));
            $this->_flashMessenger->setNamespace('default');
	        $this->_flashMessenger->addMessage($this->_translate->translate('Channel "%1" was deleted', null, $this->view->channelName));
        }
    }

    /**
     * shows a user's channels
     */
    public function mychannelsAction()
    {
        $model = Kms_Resource_Models::getChannel();
	
        $params = array(
                'page' => $this->getRequest()->getParam('page'),
                'sort' => $this->getRequest()->getParam('sort'),
                'keyword' => $this->getRequest()->getParam('keyword'),
                'type' => $this->getRequest()->getParam('type')
        );
        
        // search defaults:
        if (!$params['sort']){
            $params['sort'] = 'date';
        }
        if (!$params['type'])
        	$params['type'] = 'manager';
        
        
        $this->view->showUserTypeFilter = true;
        
        $this->view->params = $params;
        $this->view->channels = $model->getChannelsThumbnail($model->getMyChannelsList($params));
        
        if ($params['type'] == 'manager'){
            $this->view->admin = true;
        }
        
        $this->view->allowCreateChannel = Zend_Controller_Front::getInstance()
            ->getPlugin('Kms_Plugin_Access')->hasPermission('channels', 'create');

        $this->view->channelStatsHtmlElements = Kms_Helper_Channel_Stats::getChannelStatsHtmlElements($this->view->channels);

        // ajax calls use the same view as index
        if ($this->getRequest()->getParam('format', false) && $this->getRequest()->getParam('format') == 'ajax')
        {
            $this->renderScript('channels/index.ajax.phtml');
        }
    }
    
    /**
     * access denied by contextual role - does not require login
     */
    public function deniedAction()
    {
        
    }
}