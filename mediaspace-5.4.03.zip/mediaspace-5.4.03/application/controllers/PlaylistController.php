<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class PlaylistController extends Zend_Controller_Action
{

    private $_translate = null;
    
    public function init()
    {
        /* init translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');        
        
        /* initialize flashMessenger */
        $this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');  
        $this->_flashMessenger->setNamespace('default');
        $this->view->messages = $this->_flashMessenger->getMessages();
        
        /* Initialize contexts here */
        $contextSwitch = $this->_helper->getHelper('contextSwitch');
        
        $ajaxC = $contextSwitch->setContext('ajax', array());
        $ajaxC->setAutoDisableLayout(false);

        $dialogC = $contextSwitch->setContext('dialog', array());
        $dialogC->setAutoDisableLayout(false);

        $scriptC = $contextSwitch->setContext('script', array());
        $scriptC->setAutoDisableLayout(false);
        
        
        $contextSwitch->setSuffix('dialog', 'dialog');
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('script', 'script');
        $contextSwitch->addActionContext('view', 'ajax')->initContext();        
        $contextSwitch->addActionContext('set-private', 'dialog')->initContext();
        $contextSwitch->addActionContext('delete', 'dialog')->initContext();
        $contextSwitch->addActionContext('delete', 'ajax')->initContext();
        $contextSwitch->addActionContext('update-entries', 'ajax')->initContext();
        $this->_helper->contextSwitch()->initContext();

    }

    public function indexAction()
    {
        // action body
    }

    
    public function updateEntriesAction()
    {
        $playlistId = $this->getRequest()->getParam("id");
        $entriesArray = explode(',', $this->getRequest()->getParam('entries'));
        
        if($playlistId && count($entriesArray))
        {
            $playlistModel = new Application_Model_Playlist();
            if($playlistModel->updatePlaylist($playlistId, $entriesArray))
            {
            	$this->_flashMessenger->setNamespace('default');
				$this->_flashMessenger->addMessage($this->_translate->translate('Playlist successfully updated').'.');	
            }
            else
            {
            	$this->_flashMessenger->setNamespace('errors');
                $this->_flashMessenger->addMessage($this->_translate->translate('The playlist could not be updated').'.');  
            }
        }
        $this->_forward('my-playlists', 'user');
        
        
    }
    
    public function deleteAction()
    {
        
        // get the entry from the entry id requested
        $id = $this->getRequest()->getParam('id');
        $this->view->id = $id;
        
        $playlistModel = new Application_Model_Playlist();
        
        $playlist = $playlistModel->get($id);
        $this->view->playlist = $playlist;
        // check if the user is allowed to delete
        if(Kms_Plugin_Access::isCurrentUser($playlist->userId))
        {
            $this->view->allowed = true;
            // check if confirmation was sent
            if($this->getRequest()->getParam('confirm') == '1')
            {
                $this->view->confirmed = true;
                $playlistModel->delete($playlist->id);
               
            }
            else
            {
                $this->view->confirmed = false;
            }
        }
        else
        {
            $this->view->allowed = false;
        }
    }

    /**
     * view a playlist as a gallery
     */
    public function viewAction()
    {
        $request = $this->getRequest();        
        $playlistId = $request->getParam('playlistid');        
        $model = Kms_Resource_Models::getPlaylist();
        $playlist = $model->get($playlistId);
        
        $params = array(
            'page' => $request->getParam('page'),
            'sort' => $request->getParam('sort'),
            'type' => $request->getParam('type'),
        );

        if(!empty($playlist)){
            
            // pass the playlist to the view
            $this->view->playlist = $playlist;

            // pass the parameters to the view
            $this->view->params = $params;

            $this->view->entries = $model->getEntries($playlistId, Kms_Resource_Config::getConfiguration('gallery', 'pageSizeWide'), $params);
        }
        else{
            // throw a 404 error in case playlist does not exist            
            $msg = $this->_translate->translate('Playlist').' "'. $playlistId .'" '.$this->_translate->translate('not found');
            Kms_Log::log('gallery: '.$msg, Kms_Log::WARN);
            throw new Zend_Controller_Action_Exception($msg, 404);
        }
    }
}

