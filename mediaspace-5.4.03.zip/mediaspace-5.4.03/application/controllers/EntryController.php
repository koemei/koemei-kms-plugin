<?php

/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

class EntryController extends Zend_Controller_Action
{

    private $_flashMessenger = null;
    private $_translate = null;

    public function init()
    {
        /* initialize translator */
        $this->_translate = Zend_Registry::get('Zend_Translate');
        /* initialize flashMessenger */
        $this->_flashMessenger = $this->_helper->getHelper('FlashMessenger');
        $this->_flashMessenger->setNamespace('default');
        $this->view->messages = $this->_flashMessenger->getMessages();

        /* Initialize contexts here */
        $contextSwitch = $this->_helper->getHelper('contextSwitch');

        $ajaxC = $contextSwitch->setContext('ajax', array());
        $ajaxC->setAutoDisableLayout(false);

        $dialogC = $contextSwitch->setContext('dialog', array());
        $dialogC->setAutoDisableLayout(false);

        $scriptC = $contextSwitch->setContext('script', array());
        $scriptC->setAutoDisableLayout(false);


        $contextSwitch->setSuffix('dialog', 'dialog');
        $contextSwitch->setSuffix('ajax', 'ajax');
        $contextSwitch->setSuffix('script', 'script');
        $contextSwitch->addActionContext('set-private', 'dialog')->initContext();
        $contextSwitch->addActionContext('delete', 'dialog')->initContext();
        $contextSwitch->addActionContext('delete', 'ajax')->initContext();        
        $contextSwitch->addActionContext('add', 'ajax')->initContext();
        $contextSwitch->addActionContext('view', 'ajax')->initContext();
        $contextSwitch->addActionContext('sidebar', 'ajax')->initContext();        
        $contextSwitch->addActionContext('get', 'ajax')->initContext();
        $contextSwitch->addActionContext('edit-options', 'ajax')->initContext();        
        $contextSwitch->addActionContext('edit', 'ajax')->initContext();
        $contextSwitch->addActionContext('save', 'ajax')->initContext();
        $contextSwitch->addActionContext('done', 'ajax')->initContext();
        $contextSwitch->addActionContext('add-entry-form', 'ajax')->initContext();
        $contextSwitch->addActionContext('view', 'script')->initContext();
        $contextSwitch->addActionContext('check-status', 'ajax')->initContext();
        $contextSwitch->addActionContext('like', 'ajax')->initContext();
        $contextSwitch->addActionContext('unlike', 'ajax')->initContext();
        $contextSwitch->addActionContext('my-media-details', 'ajax')->initContext();
        $contextSwitch->addActionContext('post-upload-token', 'ajax')->initContext();
        $contextSwitch->addActionContext('terms-of-use', 'ajax')->initContext();
        $contextSwitch->addActionContext('remove-rejected-categories-entry', 'ajax')->initContext();

        $this->_helper->contextSwitch()->initContext();
    }

    public function indexAction()
    {
        // action body
    }


    /**
     * validate and save the entry options form
     */
    public function editOptionsAction()
    {
        if ($this->getRequest()->isPost())
        {
            $entryId = $this->getRequest()->getParam('entryid');
            $this->view->form = new Application_Form_EntryOptions(array('entryId' => $entryId));

            // get the post data
            $data = $this->getRequest()->getPost();
            
            // validate the form
            if ($this->view->form->isValid($data))
            {
                // form is valid - allow modules to save their data
                foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_Options') as $name => $model)
                {
                    $model->saveEntryOptionsValues($data);
                }
            } 
        }
    }


    /**
     * display the form for editing an entry
     *
     */
    public function editAction()
    {
        $request = $this->getRequest();
        $id = $request->getParam('id'); // edited entry id
    	$model = Kms_Resource_Models::getEntry();
        $entry = $model->get($id);
        $this->view->renderByModule = $model->handleEntryByModule($entry);
        $this->view->enableDelete = Kms_Resource_Config::getConfiguration('application', 'enableEntryDelete');
        
        // if the user is allowed to edit the entry
        if(Kms_Plugin_Access::isCurrentUser($entry->userId)) {
        	$this->view->noPlayer = $this->getRequest()->getParam('noplayer') == '1';
            $this->view->error = ($entry->status == Kaltura_Client_Enum_EntryStatus::ERROR_CONVERTING || $entry->status == Kaltura_Client_Enum_EntryStatus::ERROR_IMPORTING);
            $this->view->converting = $entry->status != Kaltura_Client_Enum_EntryStatus::READY && !($this->view->error);
            
            $form = new Application_Form_EditEntry();
            $isAsyncRequest = $this->getRequest()->getParam('format') == 'ajax';
            // check if the form should be submitted via ajax or not
            if ($isAsyncRequest) {
                $form->setAttrib('ajax', '1');
            }
            $form->setAction($this->view->baseUrl('/entry/edit/id/' . $id));

            if ($request->isPost()) {
            	// form submission
                $entryPost = $request->getParam('Entry');
                $data = $request->getPost();
                if ($form->isValid($data)) {
                    // redirect to the save action
                    $this->view->formValid = true;

                    try {
                        $newEntry = $model->save($entryPost);
                    }
                    catch(Kaltura_Client_Exception $e)
                    {
                        $this->view->saveError = true;
                        $this->view->formValid = false;
                    }

                    // if saved ok
                    if(!$this->view->saveError) {
                        $newEntryBoxId = $this->_request->getParam('new');
                        if ($newEntryBoxId) {
                            // new entry was added
                            if ($this->_request->getParam('format') == 'ajax') {
                                $this->_request->setParam('boxId', $newEntryBoxId);
                                $this->_forward('done');
                                return;
                            }
                        }
                        else {
                        	// existing entry was edited
                            $this->_flashMessenger->addMessage($this->_translate->translate('The information was saved successfully'));

                            if ($this->_request->getParam('format') == 'ajax') {
                                $this->_redirect('/edit/'.$id . '?format=ajax&nocache');
                            }
                            else {
                                $this->_redirect('/edit/'.$id . '?nocache');
                            }
                        }
                    }
                }
                else {
                	// invalid form data
                    $this->view->formValid = false;
                    $form->populate($data[Application_Form_EditEntry::FORM_NAME]);
                }
            }
            else {
            	// initial form view (not submission), populate the form with entry details
            	$form->populate((array) $entry);
                $form->getElement('tags')->setValue($this->view->getHelper('String')->removeAuthorNameFromTags($entry->tags));
            }

            $this->view->entry = $entry;
            $this->view->form = $form;
            $entriesStatus = $model->getEntriesPublishStatus(array($entry));
            $this->view->status = $this->view->entryPublishingStatus()->getStatus($entry, $entriesStatus);
            
            if ($this->view->entryPublishingStatus()->hasCategories($entry, $entriesStatus)) {
	            // get categories / publish info 
	            $details = array();
		        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Details') as $name => $module){
		            $details = array_merge($module->getEntryDetails($entry->id));
		        }
		        $this->view->details = $details;
            }
            
            $tabs = array();
            // options tab
            $optionsModules = Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_Options');
            if (!empty($optionsModules)) {
                $optionsForm = new Application_Form_EntryOptions(array('entryId' => $entry->id));
                $optionsForm->populate((array) $entry);

                $options = new Kms_Type_Tab_Core($this->_translate->translate('Options'), $optionsForm , array('id' => 'options'),'',-1);
                $tabs[] = $options;
            }

            // get the module tabs
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Edit_Tabs') as $name => $module){
                if ($module->isHandlingTabType($entry)) {
                        $tabs = array_merge($module->getEntryEditTabs($entry),$tabs);
                }
            }
            
            $this->view->editTabs = $tabs;
        }
        else {
        	// the user is not allowed to edit this entry
            throw new Zend_Controller_Action_Exception($this->_translate->translate('Sorry, you cannot access this page. Either access has been denied or page was not found.'), Kms_Plugin_Access::EXCEPTION_CODE_ACCESS);
        }
    }

    /**
     * Remove all the Category entry objects that are in rejected status for a given entry
     */
    public function removeRejectedCategoriesEntryAction()
    {
        $request = $this->getRequest();
        $this->view->entryId = $request->getParam('entryId');

        $model = Kms_Resource_Models::getEntry();

        $categories = $model->getRejectedEntryCategories($this->view->entryId);

        $catArr = array();
        foreach ($categories as $cat)
        {
            $catArr[]=$cat->id;
        }

        //remove/unpublish categories from entry
        $model->updateCategoriesFrom(array($this->view->entryId),$catArr,array());

        $model = Kms_Resource_Models::getEntry();
        $entry = $model->get($this->view->entryId);
        $this->view->entry = $entry;
        $entriesStatus = $model->getEntriesPublishStatus(array($entry));
        $this->view->status = $this->view->entryPublishingStatus()->getStatus($entry, $entriesStatus);

        if ($this->view->entryPublishingStatus()->hasCategories($entry, $entriesStatus)) {
            // get categories / publish info
            $details = array();
            foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Details') as $name => $module){
                $details = array_merge($module->getEntryDetails($entry->id));
            }
            $this->view->details = $details;
        }



    }

    /**
     * add new entry (upload)
     */
    public function addEntryFormAction()
    {
    	$request = $this->getRequest();
        $this->view->uploadBoxId = $request->getParam('id') ? $request->getParam('id') : '1';
        
        $categoryId = $request->getParam('catid', -1);

		$form = new Application_Form_EditEntry(array(Application_Form_EditEntry::CATEGORY_ID => $categoryId));
        $isAsyncRequest = $request->getParam('format') == 'ajax';
        // check if the form should be submitted via ajax or not
        if ($isAsyncRequest) {
            $form->setAttrib('ajax', '1');
        }
        $formAction = $form->getAction();
        if (empty($formAction)) {
            $form->setAction($this->view->baseUrl('/entry/add-entry-form/id/' . $this->view->uploadBoxId . '/catid/' . $categoryId));
        }

        if ($request->isPost()) {
            $data = $request->getPost();

            if ($form->isValid($data)) {
            	$this->view->formValid = true;
                $entryPost = $request->getParam('Entry');
                if ($entryPost['id']) {
                    $this->_request->setParam('new', $this->view->uploadBoxId);
                    $this->view->form = $form;
                   
                    // set the category id - if exists
                    $entryPost['category'] = $categoryId;

                    // save entry
                    try {
                        $newEntry = Kms_Resource_Models::getEntry()->save($entryPost);
                    }
                    catch(Kaltura_Client_Exception $e) {
                        $this->view->saveError = true;
                        $this->view->formValid = false;
                    }

                    if(!$this->view->saveError) {
                        $newEntryBoxId = $this->_request->getParam('new');
                        if ($newEntryBoxId) {
                            // new entry was added
                            if ($this->_request->getParam('format') == 'ajax') {
                                $this->_request->setParam('boxId', $newEntryBoxId);
                                $this->_request->setParam('catid', $categoryId);                                
                                $this->_forward('done');
                                return;
                            }
                        }
                        else {
                            $this->_flashMessenger->addMessage($this->_translate->translate('The information was saved successfully'));
                            if ($this->_request->getParam('format') == 'ajax') {
                                $this->_redirect($this->view->EntryLink($id, $newEntry->name, true) . '?format=ajax&nocache');
                            }
                            else {
                                $this->_redirect($this->view->EntryLink($id, $newEntry->name, true) . '?nocache');
                            }
                        }                    
                    }
                }
            }
            else {
                $this->view->formValid = false;
            }
            $form->populate($data[Application_Form_EditEntry::FORM_NAME]);
        }
        else {
        	// form first view 
        	// get the filename from the parameters
	        $name = $request->getParam('name');
	        // remove extension from name
	        $name = preg_replace('/^(.*)\.+.{3,4}$/', '$1', $name);
	        $params = array('name' => $name);
	        if ($categoryId != -1)
	        	$params['categoryId'] = $categoryId;
            $form->populate($params);
        }

        $this->view->form = $form;
    }

    
    /**
     * parse the form and save the entry
     * @return void
     */
    public function saveAction()
    {
        $id = $this->getRequest()->getParam('id');
        $request = $this->getRequest();

        // check if we have the request and it's a POST
        if ($request->isPost())
        {
            // create a model instance
            $entryModel = new Application_Model_Entry();

            // get the Entry submitted form
            $entry = $request->getParam('Entry');

            $newEntry = $entryModel->save($entry);

            $newEntryBoxId = $this->_request->getParam('new');
            if ($newEntryBoxId)
            {
                // new entry was added
                if ($this->_request->getParam('format') == 'ajax')
                {
                    //$this->_redirect('/entry/done/boxId/'.$newEntryBoxId.'/id/'.$id.'?format=ajax');
                    $this->_request->setParam('boxId', $newEntryBoxId);
                    $this->_forward('done');
                    return;
                }
            }
            else
            {
                $this->_flashMessenger->addMessage($this->_translate->translate('The information was saved successfully'));

                if ($this->_request->getParam('format') == 'ajax')
                {
                    $this->_redirect($this->view->baseUrl('/edit/'.$id) . '?format=ajax&nocache');
                }
                else
                {
                    $this->_redirect($this->view->baseUrl('/edit/'.$id) . '?nocache');
                }
            }
        }
    }

    /**
     * invoked when entry is done uploading and saved
     */
    public function doneAction()
    {
        $entry = $this->getRequest()->getParam('Entry');
        $this->view->form->populate($entry);
        $this->view->uploadBoxId = $this->getRequest()->getParam('boxId');

        // check if we must approve this entry for unmoderated role
    }

    /**
     * post upload action for widgets that return an upload token (jquery.fileupload)
     */
    public function postUploadTokenAction()
    {
        $name = $this->getRequest()->getParam('name');
        $token = $this->getRequest()->getParam('token');

        $entryModel = Kms_Resource_Models::getEntry();
        $entry = $entryModel->createEntryFromToken($name,$token);

        // auto approve entry if applicable
        $entryModel->approve($entry);

        // run interface
        $entryModel->entryAdded();

        // clear the my media cache
        $entryModel->clearMyMediaCache();

        $this->view->uploadBoxId = $this->getRequest()->getParam('boxId');
        $this->view->entry = $entry;
        $this->view->formSaved = $this->getRequest()->getParam('save');

        $categoryId = $this->getRequest()->getParam('catid');
        if ($categoryId > 0 && $entryModel->checkReadyToPublish()){ //we need this check because the "go to media" won't work with category id if the entry was not yet added into it
            $this->view->categoryId = $categoryId;
        }
        else{
            $this->view->categoryId = null;
        }
    }

    /**
     * post upload action for widgets that return an entry (flash widgets)
     */
    public function postUploadAction()
    {
        $entryId = $this->getRequest()->getParam('entryid');
        $entryModel = Kms_Resource_Models::getEntry();
        $entry = $entryModel->get($entryId);

        // auto approve entry if applicable
        $entryModel->approve($entry);

        // run interface
        $entryModel->entryAdded();
        
        // clear the my media cache
        $entryModel->clearMyMediaCache();
        exit;
    }

    /**
     *  view an entry page
     */
    public function viewAction()
    {
    	$categoryId = $this->getRequest()->getParam('categoryid');
    	
        // action body
        $id = $this->getRequest()->getParam('id');
        $entryModel = Kms_Resource_Models::getEntry();
        try
        {
            $entry = $entryModel->get($id);
        }
        catch (Kaltura_Client_Exception $ex)
        {
            Kms_Log::log('entry: Unable to get entry id ' . $id . '. ' . $ex->getCode() . ': ' . $ex->getMessage(), Kms_Log::NOTICE);
            $this->denyAccessToEntry();
            return;
        }

        // in case it's not my-media page
        if ($categoryId)
        {
	        //---------------------------------------------------------------------
	        //check that the user can view this category (SECURITY ISSUES)
	        $catModel = Kms_Resource_Models::getCategory();
	        $category = $catModel->get(null, null, $categoryId);

            if ($catModel->isCategoryAChannel($category)){
                $channelModel = Kms_Resource_Models::getChannel();
                $isAllowedToViewCat = $channelModel->isUserAllowedViewingCategory($categoryId);
            }
            else{
                $galleryModel = Kms_Resource_Models::getGallery();
	            $isAllowedToViewCat = $galleryModel->isUserAllowedViewingCategory($categoryId);
            }

	        if (!$isAllowedToViewCat)
	        {
	        	Kms_Log::log('entry: category is not allowed for this member ' . $categoryId , Kms_Log::NOTICE);
	        	$this->denyAccessToEntry();
	        	return;
	        }
	        //-----------------------------------------------------------------------
        
			//check that this entry is in the category or one of its sub-categories (SECURITY ISSUES)
	        $isEntryInCat = $entryModel->isEntryInCategory($entry, $categoryId);
	    	if (!$isEntryInCat)
	        {
	        	Kms_Log::log('entry: entry ' . $entry->id . ' is not allowed being navigated from category ' . $categoryId , Kms_Log::NOTICE);
	        	$this->denyAccessToEntry();
	        	return;
	        }
	        //-------------------------------------------------------------------------
        }

        $this->view->isLiked = $entryModel->isLiked($id);
        
        $entryUser = $entry->userId;
        $currentUser = null;
        $identity = Zend_Auth::getInstance()->getIdentity();
        if ($identity)
        {
            $currentUser = $identity->getId();
        }

        $this->view->entry = $entry;
        $this->view->entryUser = $entryUser;
        $this->view->isEntryOwner = Kms_Plugin_Access::isCurrentUser($entryUser);
        $this->view->error = (!$entry || $entry->status == Kaltura_Client_Enum_EntryStatus::ERROR_CONVERTING || $entry->status == Kaltura_Client_Enum_EntryStatus::ERROR_IMPORTING) ? true : false;
        $this->view->pending = $entry->moderationStatus == Kaltura_Client_Enum_EntryModerationStatus::PENDING_MODERATION ? true : false;
        $this->view->converting = (!$entry || $entry->status == Kaltura_Client_Enum_EntryStatus::READY) ? false : true;
        $this->view->categoryId = $categoryId;
        
        $this->view->contentClass = 'entrypage';     
        
        // should the entry page be handled by a module
        $this->view->renderByModule = $entryModel->handleEntryByModule($entry);
        
        $actions = array();
        // module actions
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Actions') as $name => $module)
        {
            if ($module->isHandlingTabType($entry)) {
                $actions = array_merge($actions, $module->getEntryActions($entry));
            }
        }
        $this->view->actionTabs = $actions;
        
        $buttons = array();
        // module tabs
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Buttons') as $name => $module){
            if ($module->isHandlingTabType($entry)) {
                $buttons = array_merge($buttons, $module->getEntryButtons($entry));
            }
        }
        
        $this->view->buttonTabs = $buttons;
        
        $bottomTabs = array();

        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Tabs') as $name => $module){
            if ($module->isHandlingTabType($entry)) {
                $bottomTabs = array_merge($module->getEntryTabs($entry,$this->getFrontController()->getRequest()),$bottomTabs);
            }
        }
        $this->view->bottomTabs = $bottomTabs;
        
        $sideBarItems = array();
        $index = 1;

        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_SideBar') as $name => $module){
            foreach ($module->getEntrySideBars($entry) as $item){
                if ($item instanceof Kms_Type_Action) {
                    $index++;

                    $sideBarContenturl = '/entry/sidebar/' . strtolower($name) . '/' .$entry->id ;
                    if (!empty($item->link->attributes)) {
                        foreach ($item->link->attributes as $key => $value) {
                            $sideBarContenturl .= "/$key/$value";
                        }
                    }

                    $item->link->href = $sideBarContenturl;
                    $item->link->attributes = array();
                    $sideBarItem = new Kms_Type_Tab_Async($item->link, $item->label, "entrySideBarPane-$name-$index");
                    $sideBarItems[] = $sideBarItem;
                }    
            }
        }
        $this->view->sideBarItems = $sideBarItems;

        $this->view->playerBarHeightPixels = Kms_Resource_Config::getConfiguration('player', 'playerBarHeightPixels');
        $this->view->playerVideoRatioPercent = Kms_Resource_Config::getConfiguration('player', 'playerVideoRatioPercent');
    }
    
    private function denyAccessToEntry()
    {
   		$access_denied = Kms_Resource_Config::getConfiguration('auth', 'accessDenied');
    	$this->_forward($access_denied->action, $access_denied->controller, $access_denied->module);
	}


    /**
     *  entry page sidebar
     */
    public function sidebarAction()
    {
        $moduleName = $this->getRequest()->getParam('modulename');
        $entry = Kms_Resource_Models::getEntry()->getCurrent($this->getRequest()->getParam('id'));

        // call only the module specified in the request
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_SideBar') as $name => $module){
            if (strcasecmp($moduleName, $name) == 0) { 
                $this->view->entries = $module->getSideBarEntries($entry, $this->getRequest()->getParams());
            }
        }
    }

    /**
     *  delete entry 
     */
    public function deleteAction()
    {
        // get the entry from the entry id requested
        $id = $this->getRequest()->getParam('id');

        if (empty($id))
        {
            //nothing was chosen
            $this->view->errMsg = $this->_translate->translate('You must choose entries to delete.');
            $this->view->allowed = false;
            $this->view->confirmed == ($this->getRequest()->getParam('confirm') == '1');
            return;
        }

        // get the user id
        $identity = Zend_Auth::getInstance()->getIdentity();
        if ($identity)
        {
            $currentUser = $identity->getId();
        }
      
        //get redirect url from the params
        $redir = $this->getRequest()->getParam('redir');
        if ($redir)
        {
            $this->view->redirectUrl = $redir;
        }
        else
        {
            // redirect after delete, defaults to my-media
            $this->view->redirectUrl = $this->view->baseUrl('my-media');
        }
        $this->view->id = $id;
        $idArray = explode(',', $id);

        //number of entries sent for deletion
		$numSentForDeletion = count($idArray);
		
		//get entries - should be in cache
        $entryModel = Kms_Resource_Models::getEntry();
        $entries = $entryModel->getEntriesByIds($idArray);
        
        //filter out not owned and external (not editable) entries
        $idArray = $this->filterAllowDeleteIds($entries);
        //if there were not allowed entries - give a message
        $this->view->notAllowedMessage = '';
        if (count($idArray) < $numSentForDeletion)
		{
        	$this->view->notAllowedMessage = $this->_translate->translate(' (You are not allowed to delete other %1 entries', null, ($numSentForDeletion - count($idArray))); 
		}
		
        if (count($idArray) == 0)
        {
            //nothing to delete
            $this->view->allowed = false;
            $this->view->confirmed == ($this->getRequest()->getParam('confirm') == '1');
            return;
        }

        //there are entries to delete
        $this->view->allowed = true;
        if (count($idArray) > 1) // multiple entries to delete
        {
            $this->view->multi = count($idArray);
            
            if ($this->getRequest()->getParam('confirm') == '1')
            {
                $this->view->confirmed = true;
                $numDeleted = $entryModel->deleteMulti($idArray);
                if ($numDeleted)
                {
                	$this->_flashMessenger->addMessage($this->_translate->translate('Successfully deleted %1 items!', null, $numDeleted) . $this->view->notAllowedMessage);
                }
            }
            else
            {
                $this->view->confirmed = false;
            }
        }
        else
        {
        	// only one entry to delete
        	$id = array_pop($idArray);
            $this->view->multi = false;
            $entry = $entryModel->get($id);
            $this->view->entry = $entry;
            
            // check if confirmation was sent
            if ($this->getRequest()->getParam('confirm') == '1')
            {
            	$this->view->confirmed = true;
                if ($entryModel->delete($entry->id))
                {
                	$this->_flashMessenger->addMessage($this->_translate->translate('Successfully deleted "%1"', null, $entry->name) . $this->view->notAllowedMessage);
				}
            }
            else
            {
            	$this->view->confirmed = false;
			}
        }
    }
    
    private function filterAllowDeleteIds($entries) 
    {
    	
    	$allowedIds = array();
    	$isEntryEditableHelper = new Kms_View_Helper_IsEntryEditable();
    	foreach ($entries as $entry)
    	{
    		//entries are allowed for deletion if the user owns them and the entry is editable
    		if (Kms_Plugin_Access::isCurrentUser($entry->userId) && !($isEntryEditableHelper->IsEntryEditable($entry) === false))
    		{
    			array_push($allowedIds, $entry->id);	
    		}
    	} 
    	return $allowedIds;
    }

    /**
     * action for upload of entries (ajaxable)
     */
    public function addAction()
    {
        $this->view->categoryId = $this->getRequest()->getParam('catid',-1);
        $uploadType = $this->getRequest()->getParam('type');

        if ($uploadType == 'webcam')
        {
            // enable the edit entry form right away, in case of webcam upload
            $form = new Application_Form_EditEntry(array(Application_Form_EditEntry::CATEGORY_ID => $this->view->categoryId));
            // empty form for new entry
            $form->setAttrib('ajax', '1');
            $formAction = $form->getAction();
            if (empty($formAction)) {
                $form->setAction($this->view->baseUrl('/entry/add-entry-form/id/1/catid/' . $this->view->categoryId));
            }
            $form->populate(array());
            $this->view->form = $form;
            //get the filename from the parameters
            $this->view->uploadBoxId = '1';
            // get uiconf for krecord version
            $entryModel = Kms_Resource_Models::getEntry();
            $uiconf = $entryModel->getUiconfById(Kms_Resource_Config::getConfiguration('widgets', 'krecordId'));
            if (!empty($uiconf->swfUrlVersion)) {
                $this->view->uiconfVersion = $uiconf->swfUrlVersion;
            }
            else {
                $this->view->uiconfVersion = null;
            }
        }
        $this->view->uploadType = $uploadType;

        $this->view->ks = Kms_Resource_Client::getUserClient()->getKs();
        $this->view->partnerId = Kms_Resource_Config::getConfiguration('client', 'partnerId');

        $identity = Zend_Auth::getInstance()->getIdentity();
        if ($identity)
        {
            $this->view->userId = $identity->getId();
        }
        else
        {
            $this->view->userId = null;
        }
        $this->view->uploadBoxId = $this->getRequest()->getParam('boxId') ? $this->getRequest()->getParam('boxId') : '1';

        $this->view->uploadButtonText = $this->view->uploadBoxId == 1 ? $this->_translate->translate('Choose a file to upload') : $this->_translate->translate('Choose another file');
        $this->view->uploadHeading = $this->view->uploadBoxId == 1 ? $this->_translate->translate('Upload Media') : $this->_translate->translate('Upload another file');
    }

    public function noEntryAction()
    {
        // action body
    }

    public function checkStatusAction()
    {
        $this->view->uiconfId = $this->getRequest()->getParam('uiconfid');
        $entryId = $this->getRequest()->getParam('id');
        $entryModel = Kms_Resource_Models::getEntry();
        $entry = $entryModel->get($entryId);
        $this->view->entry = $entry;
        $entryReady = $entry->status == Kaltura_Client_Enum_EntryStatus::READY;

        if ($entryReady)
        {
            $this->view->ready = true;
        }
        else
        {
            $this->view->ready = false;
        }
    }

    /**
     * ajax action for "like"
     */
    public function likeAction()
    {
        $id = $this->getRequest()->getParam('entryid');
        if ($id)
        {
            $model = Kms_Resource_Models::getEntry();
            $this->view->success = $model->like($id);
            if ($this->view->success){
                $entry = $model->entry;
                $this->view->id = $entry->id;
                $this->view->likes = $entry->votes;
            }
        }
    }

    /**
     * ajax action for "unlike"
     */
    public function unlikeAction()
    {
    	$id = $this->getRequest()->getParam('entryid');
    	if ($id)
    	{
    		$model = Kms_Resource_Models::getEntry();
    		$this->view->success = $model->unlike($id);
    		if ($this->view->success){
    		    $entry = $model->entry;
    		    $this->view->id = $entry->id;
                $this->view->likes = $entry->votes;
    		}       	
    	}
    }

    /**
     * ajax action for entry details in my media view
     */
    public function myMediaDetailsAction()
    {
        $this->view->entryId = $this->getRequest()->getParam('entryid');

        $details = array();
        foreach (Kms_Resource_Config::getModulesForInterface('Kms_Interface_Functional_Entry_Details') as $name => $module){
            $details = array_merge($module->getEntryDetails($this->view->entryId));
        }
        $this->view->details = $details;
    }

    /**
     * ajax action for setting entry terms of use
     */
    public function termsOfUseAction()
    {
        $tou = $this->getRequest()->getParam('tou');
        if (empty($tou)) //show pop-up
        {
            $this->view->publishParams = $this->getRequest()->getParams();
        }
        else
        {
            //add terms of use
            $entryModel = Kms_Resource_Models::getEntry();
            //publish model sends 'entry', addContent model sends 'id'
            $entryIds = $this->getRequest()->getParam('entry') ? $this->getRequest()->getParam('entry') : $this->getRequest()->getParam('id');
            if (empty($entryIds)){
                $entryIds = $this->getRequest()->getParam('Entry');
                $entryIds = $entryIds['id'];
            }

            $sharedRepositoryIds = $this->getRequest()->getParam('repositoryids');
            $entryModel->setEntriesTermsOfUse($entryIds, $sharedRepositoryIds);
            //forward back to where we came from (publish/addContent)
            $action = $this->getRequest()->getParam('referrer_action');
            $controller = $this->getRequest()->getParam('referrer_controller');
            $module = $this->getRequest()->getParam('referrer_module');
            $params = $this->getRequest()->getParams();
            $params['tou'] = true;
            $this->_forward($action, $controller, $module, $params);
        }
    }
}

