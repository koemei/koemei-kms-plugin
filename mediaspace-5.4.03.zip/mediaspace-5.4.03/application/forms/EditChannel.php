<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * form to change channel settings
 * the members of this form corresponds to the members of Kaltura_Client_Type_Category - 
 * this in order for the populate to work.
 * This form is identical to Application_Form_EditCategory, but calls an additional channel interface.
 */
class Application_Form_EditChannel extends Application_Form_EditCategory
{
	const FORM_NAME = 'Category';
	
    public function init()
    {
        parent::init();
        $this->setAttrib('id','edit_channel');
        
        // goto channel link - create hidden with no url
        $element = new Kms_Form_Element_Note(
                        array(  'belongsTo' => Application_Form_EditChannel::FORM_NAME,
                                'name' => 'back',
                                'value' => '<a href="#" class="btn btn-link hidden" id="back">back</a>'));
        $this->addElement($element);
        
        // actions group
        $group = $this->getDisplayGroup('actions');
        $elements = array();
        foreach ($group->getElements() as $name => $e) {
        	$elements[] = $name;
        }
        $elements[] = 'back';
        $this->removeDisplayGroup('actions');
        $this->addDisplayGroup(
            $elements,
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
                'order' => 101
            )
        );
        
        // allow modules to modify the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Channel_Edit') as $name => $model)
        {
            $model->editChannelForm($this);
        }
    }

    protected function getMembershipMultiOptions(){
        $allowedMemberships = Kms_Helper_Channel_Privacy::getChannelMembershipOptions();
        $parentMembershipMultiOptions = parent::getMembershipMultiOptions();
        $membershipMultiOptions = array();
        foreach ($allowedMemberships as $type => $membership){
            if (isset($parentMembershipMultiOptions[$membership]))
                $membershipMultiOptions[$membership] = $parentMembershipMultiOptions[$membership];
            else 
                $membershipMultiOptions[$membership] = $this->getMembershipTranslation($membership);
        }
        
        return $membershipMultiOptions;
    }
    
    protected function getMembershipTranslation($membership){
        $translation = parent::getMembershipTranslation($membership);
        if (!$translation){
            $translate = Zend_Registry::get('Zend_Translate');
            switch ($membership){
                case Application_Model_Channel::MEMBERSHIP_SHARED:
                   $translation = '<strong>' . $translate->translate('Shared Repository') . '</strong> - <span>' . $translate->translate('Membership is by invitation only. Members can publish content from this channel to any other channel according to their entitlements.') . '</span>'; 
                   break;                  
            }
        }
        
        return $translation;
    }
    
    public function populate(array $values)
    {
        parent::populate($values);
     	if ($this->getElement('id')->getValue()) {
        	// have id, this is an existing (saved) entry
        	$translate = Zend_Registry::get('Zend_Translate');
        	$view = new Zend_View_Helper_BaseUrl();
        	// go to category (assume it's a channel)	
	        $url = $view->baseUrl('/channel/channelid/'.$this->getElement('id')->getValue());
	        $text = $translate->translate('Back to Channel');
        	$element = $this->getElement('back');
        	$element->setValue('<a href="'. $url .'" class="btn btn-link" id="back">'. $text .'</a>');
        }
    
        // allow modules to populate the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Channel_EditPopulate') as $name => $model)
        {
            $model->populate($this, $values);
        }
    }
}