<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class Application_Form_Login extends Kms_Form_Twitter_Bootstrap_Vertical
{
	const FORM_NAME = 'Login';
        
    public function init()
    {
        parent::init();
        $translate = Zend_Registry::get('Zend_Translate');
        $front = Zend_Controller_Front::getInstance();
        $view = $front->getParam('bootstrap')->getResource('view');

        // username
		$this->addElement('text', 'username', array(
            'belongsTo' => self::FORM_NAME,
			'placeholder' => $translate->translate('User ID'),
			'class' => 'input-xlarge',
			'autofocus' => 'autofocus',
			'required' => true,
        ));
      
      
        $validator = new Zend_Validate_StringLength(array('min'=>6));
        $validator->setMessage($translate->translate('Password too short'), Zend_Validate_StringLength::TOO_SHORT);
        
        $username = $this->getElement('username');
        $username->removeDecorator('Errors');
        
        // password
		$this->addElement('password', 'password', array(
            'belongsTo' => self::FORM_NAME,
			'placeholder' => $translate->translate('Password'),
			'class' => 'input-xlarge',
			'filters' => array(
            	'StringTrim',  
            ),
            'validators' => array(
            	$validator,
            ),
            'required' => true,
        ));
        
        
        $password = $this->getElement('password');
        $password->removeDecorator('Errors');
      
    	if (Kms_Resource_Config::getConfiguration('auth', 'authNAdapter') != 'Kms_Auth_AuthN_Kaltura') {
        	// only restrict length if this is Kaltura AuthN
        	$password->removeValidator('StringLength');
        }
		
        
        
        $this->addElement('button', 'login', array(
            'belongsTo' => self::FORM_NAME,
            'label'         => $translate->translate('Sign in'),
            'type'          => 'submit',
            'class'         => 'btn btn-large btn-primary',
        ));
		
        $element = new Kms_Form_Element_Note(
                        array(  'belongsTo' => self::FORM_NAME,
                                'name' => 'forgot',
                                'value' => $view->ForgotPasswordLink()
                        ));
        $this->addElement($element);

        $this->addDisplayGroup(
            array('login', 'forgot'),
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
                'order' => 10
            )
        );
        
        
		$this->setDecorators(array(
            'FormElements',
            array('Description', array('placement' => 'prepend')),
            array('FormErrors', array('placement' => 'prepend', 
            							'markupElementLabelStart' => '<div style="display:none">',
            							'markupElementLabelEnd' => '</div>',
            							/* 'onlyCustomFormErrors' => 'true'*/
            )),
            'Form',
        ));
    }
    
	/** 
	 * insert referer info into the form
     *
     * @param Zend_Controller_Request_Abstract $request
     * @return Application_Form_Login 
     */
    public function trackReferrer(Zend_Controller_Request_Abstract $request)
    {
        $this->addElement('hidden', 'referrer');
        $this->setDefault(
            'referrer', 
            $request->getParam(
                'ref', 
                $request->getServer('HTTP_REFERER')
            )
        );
        return $this;
    }
    
    
	public function removeForgotPassword()
    {
        $this->removeElement('forgot');
    }
    
    
	/**
     *
     * @param type $default
     * @return type 
     */
    public function getReferrer($default = false)
    {
        if (!isset($this->referrer)) {
            return $default;
        }
        else {
            $val = $this->referrer->getValue();
            if ($val) {
                return $val;
            }
            else {
                return $default;
            }
        }
    }
    
	/**
     * Method for changing the form method and validator for the admin login form
     */
    public function adminLogin()
    {
        // add an email address validator instead of the alphanum validator for username(email)
        $username = $this->getElement('username');
        $username->clearValidators();
        $username->addValidator(new Zend_Validate_EmailAddress(Zend_Validate_Hostname::ALLOW_DNS |
                    Zend_Validate_Hostname::ALLOW_LOCAL));
        $this->removeForgotPassword();
        // change action to partner-authenticate
        $front = Zend_Controller_Front::getInstance();
        $view = $front->getParam('bootstrap')->getResource('view');
        $this->setAction($view->baseUrl('/admin/authenticate'));
    }

}

