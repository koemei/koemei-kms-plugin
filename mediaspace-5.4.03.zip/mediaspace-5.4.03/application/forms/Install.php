<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class Application_Form_Install extends Application_Form_Base
{

	const FORM_NAME = 'Login';
	private $view;
    private $_translate = null;
    
    public function init()
    {
        parent::init();
        $this->_translate = Zend_Registry::get('Zend_Translate');
        
        $front = Zend_Controller_Front::getInstance();
        $this->view = $front->getParam('bootstrap')->getResource('view');
        $this->setAttrib('id', 'loginForm');
        $this->setMethod(self::METHOD_POST);
        
        $username = new Zend_Form_Element_Text(
            'username', 
            array(
                'label' => $this->_translate->translate('Username').':', 
                'filters' => array(
                  'StringTrim', 'StringToLower',  
                ),
                'required' => true,
                'decorators' => array(
                    'ViewHelper',
                    'Label',
                    array('HtmlTag', array('tag'=>'div', 'class' => 'element')),
                ),
                'tabindex' => 1,
            )
        );
        $username->setAttrib('autocorrect', 'off');
        $username->setAttrib('autocapitalize', 'off');
        
        $forgotPassword = $this->view->ForgotPasswordLink();
        // for ipad/iphone
        $password = new Zend_Form_Element_Password(
            'password', 
            array(
                'label' => $this->_translate->translate('Password').':', 
                'filters' => array(
                  'StringTrim',  
                ),
                'validators' => array(
                    array('StringLength', false, array(6, 20)),
                ),
                'required' => true,
                'decorators' => array(
                    'ViewHelper',
                    array('Label', array('requiredSuffix' => $forgotPassword, 'escape' => false)),
  //                  array('Errors', array('HtmlTag' => 'div', 'placement' => 'PREPEND')),
                    array('HtmlTag', array('tag'=>'div', 'class' => 'element')),
                ),
                'tabindex' => 2,
            )
                
        );
        
        if (Kms_Resource_Config::getConfiguration('auth', 'authNAdapter') != 'Kms_Auth_AuthN_Kaltura') {
        	// only restrict length if this is Kaltura AuthN
        	$password->removeValidator('StringLength');
        }
        
        $login = new Zend_Form_Element_Button(
            'login', 
            array(
                'required' => false,
                'ignore'   => true,
                'label'    => $this->_translate->translate('Login'),
                'type'  => 'submit',
                'decorators' => array(
                    'ViewHelper',
                    array('HtmlTag', array('tag'=>'div', 'class' => 'button')),
                ),
                'tabindex' => 3,

            )
        );
        
        $this->addElement( $username );
        $this->addElement( $password );
        $this->addElement( $login );
        $this->setElementsBelongTo(self::FORM_NAME);
        
        
        $this->setDecorators(array(
            'FormElements',
            array('Description', array('placement' => 'prepend')),
            array('FormErrors', array('placement' => 'prepend')),
            'Form',
        ));
        
        //-------------------
        $hostElement = new Zend_Form_Element_Text(
            'host', 
            array(
                'label' => $this->_translate->translate('Kaltura Server URL').':', 
                'required' => true,
                'value' => 'http://www.kaltura.com', 
            )
        );

        $pidElement = new Zend_Form_Element_Text(
            'partnerId', 
            array(
                'label' => $this->_translate->translate('Partner ID').':', 
                'validators' => array(
                    'Alnum', 
                    array('StringLength', false, array(3, 20)),
                ),
                'required' => true,
            )
        );

        $instanceId = new Zend_Form_Element_Text(
            'instanceId',
            array(
                'label' => $this->_translate->translate('Instance ID').':',
                'validators' => array(
                    'Alnum',
                    array('StringLength', false, array(4,10)),
                ),
                'required' => true,
            )
        );
        $instanceId->setDescription($this->_translate->translate('Unique ID for this instance of MediaSpace installation.'));
        
        $privacyContext = new Zend_Form_Element_Text(
            'privacyContext',
            array(
                'label' => $this->_translate->translate('Privacy Context').':',
                'validators' => array(
                    'Alnum',
                    array('StringLength', false, array(1,10)),
                ),
                'required' => false, // setting empty context means no entitlement is enforced in KMS
            )
        );
        $privacyContext->setDescription($this->_translate->translate('String to be set as privacy context on KMS root category to enforce entitlement.'));

        $this->addElement($hostElement);
        $this->addElement($pidElement);
        $this->addElement($instanceId);
        $this->addElement($privacyContext);
        $this->getElement('username')->setOrder(1)->setAttrib('tabindex', 1);
        $this->getElement('password')->setOrder(2)->setAttrib('tabindex', 2);
        $this->getElement('partnerId')->setOrder(3)->setAttrib('tabindex', 3);
        $this->getElement('instanceId')->setOrder(4)->setAttrib('tabindex', 4);
        $this->getElement('privacyContext')->setOrder(6)->setAttrib('tabindex', 6);
        $this->getElement('host')->setOrder(15)->setAttrib('tabindex', 15);
        $this->getElement('login')->setOrder(16)->setAttrib('tabindex', 16);
        $this->getElement('login')->setLabel($this->_translate->translate('Next'));
        $this->setElementDecorators(array(
            'ViewHelper',
            'Description',
            'Label',
            array('Errors', array('HtmlTag' => 'div', 'placement' => 'PREPEND')),
            array('HtmlTag', array('tag'=>'div', 'class' => 'element')),
        ));
        $this->removeDecorator('Errors');
        $this->getElement('login')->removeDecorator('Label');
        $this->addForceInstanceCheckbox();

    }
    
    
	public function removeForgotPassword()
    {
        $password = $this->getElement('password');
        $password->getDecorator('Label')->setOption('requiredSuffix', '');
        
    }
    
    
	public function isValid($data)
    {
        $valid = parent::isValid($data);
        foreach($this->getElements() as $elem)
        {
            if($elem->hasErrors())
            {
                $elem->addDecorator('Errors', array('placement' => 'APPEND'));
                $elem->addDecorator('HtmlTag', array('tag'=>'div', 'class' => 'element error'));
            }
        }
        if(!$valid)
        {
            $this->removeDecorator('FormErrors');
        }
        
        return $valid;
    }
    
    
    public function adminLogin()
    {
    	// add an email address validator instead of the alphanum validator for username(email)
        $username = $this->getElement('username');
        $username->clearValidators();
        $username->addValidator(new Zend_Validate_EmailAddress(Zend_Validate_Hostname::ALLOW_DNS |
                    Zend_Validate_Hostname::ALLOW_LOCAL));
        $this->removeForgotPassword();
        $this->setAction( $this->view->baseUrl('/install/install'));
    }
    
/** insert referer info into the form
     *
     * @param Zend_Controller_Request_Abstract $request
     * @return Application_Form_Login 
     */
    public function trackReferrer(Zend_Controller_Request_Abstract $request)
    {
        $this->addElement('hidden', 'referrer');
        
//        if($request->getControllerName() == 'user' && $request->getActionName() == 'login')
        {
            $this->setDefault(
                'referrer', 
                $request->getParam(
                    'ref', 
                    $request->getServer('HTTP_REFERER')
                )
            );
        }
/*        else 
        {
            $this->setDefault(
                'referrer', 
                $request->getParam(
                    'ref', 
                    $request->getServer('HTTP_REFERER')
                )
            );
        }*/

        // use no decorator for the actual form element
        $this->referrer->setDecorators(array('ViewHelper')); 

        return $this;
        
    }
    /**
     *
     * @param type $default
     * @return type 
     */
    public function getReferrer($default = false)
    {
        if (!isset($this->referrer))
        {
            return $default;
        }
        else 
        {
            $val = $this->referrer->getValue();
            if ($val) 
            {
                return $val;
            }
            else
            {
                return $default;
            }
        }
    }

    public function addForceInstanceCheckbox()
    {
        $element = new Zend_Form_Element_Checkbox('forceUseInstanceId',
            array(
                'label' => $this->_translate->translate('Force instance id').':',
            )
        );
        $element->setOrder(5)->setAttrib('tabindex', 5);
		$element->setDecorators(array(
		    'Label',
	            'ViewHelper',
		    array('Errors', array('HtmlTag' => 'div', 'placement' => 'PREPEND')),
		    array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
		));
        $this->addElement($element);
    }

}
