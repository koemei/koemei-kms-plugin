<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class Application_Form_Base extends Zend_Form
{
    public function init()
    {
        $nonce = new Kms_Form_Element_Hash('nonce', array('salt' => 'unique_'.get_class($this)));
        $this->addElement($nonce);
    }
}

