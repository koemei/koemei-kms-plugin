<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
*/

class Application_Form_AddCategory extends Application_Form_Base
{

    public function init()
    {
        parent::init();
        /* Form Elements & Other Definitions Here ... */
    }


}

