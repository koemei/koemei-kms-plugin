<?php
/**
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

class Application_Form_EditEntry extends Kms_Form_Twitter_Bootstrap_Horizontal
{
    const FORM_NAME = 'Entry';
    const CATEGORY_ID = 'categoryId';

    private $view;
    private $_translate = null;

    public function init()
    {
        parent::init();
        $this->_translate = Zend_Registry::get('Zend_Translate');
        
        $front = Zend_Controller_Front::getInstance();
        $this->view = $front->getParam('bootstrap')->getResource('view');
        
        $this->setMethod(self::METHOD_POST);
        $this->setAttrib('id', 'edit_entry');
        
        $categoryId = $this->getAttrib(self::CATEGORY_ID);
        $this->removeAttrib(self::CATEGORY_ID);

        $nameElem = $this->createFormElement(
            'text', 
            'name', 
            array(
                'label' => $this->_translate->translate('Name'),
                'required' => 'required',
                'isEmpty' => false,
                'isRequired' => $this->_translate->translate('Name is a required field')
            )
        );
		$descriptionOptions = array(
	        		'label' => $this->_translate->translate('Description'),
	                'isEmpty' => false,
	                'id' => 'description',
	                'placeholder' => $this->_translate->translate('Enter Description...'),
	                'rows' => 7,
        );
     	if (Kms_Resource_Config::getConfiguration('metadata', 'descriptionRequired')){
        	//$descriptionOptions['isRequired'] = $this->_translate->translate('Description is a required field');
        	//$descriptionOptions['required'] = 'required';
            $descriptionOptions['description'] = $this->_translate->translate('* Required For Publish');
        }
        $elem = $this->createFormElement(
            'textarea', 
            'description', 
            $descriptionOptions
        );
        $elem->setAttrib('class', $elem->getId() . ' span11 wysiwyg');
        
        
    	$tagsOptions = array( 
	        		'label' => $this->_translate->translate('Tags'),
        );
     	if (Kms_Resource_Config::getConfiguration('metadata', 'tagsRequired')){
        	//$tagsOptions['isRequired'] = $this->_translate->translate('Tags is a required field');
        	//$tagsOptions['required'] = 'required';
            $tagsOptions['description'] = $this->_translate->translate('* Required For Publish');
        }
        $elem = $this->createFormElement(
            'text', 
            'tags', 
            $tagsOptions
        );
        
        $elem->setAttrib('class', $elem->getId().' tags span11 select2');

        //add Shared Repositories custom data fields
        $channelModel = Kms_Resource_Models::getChannel();
        if ($channelModel->isSharedRepositoriesEnabled()){
            $fields = $channelModel->getSharedRepositoriesCustomDataFields();
            $requiredFields = Kms_Resource_Config::getConfiguration('sharedRepositories', 'requiredFields');
            $requiredLabel = $this->_translate->translate('* Required for Shared Repository');
            $configuredDateFormat = Kms_Resource_Config::getConfiguration('sharedRepositories', 'dateFormat');
            // iterate over the fields
            foreach ($fields as $fieldName => $fieldInfo)
            {
                Kms_Helper_Metadata::generateFormElement($this, $fieldName, $fieldInfo, 'sharedRepositories', $requiredFields , $requiredLabel, $configuredDateFormat);
            }
        }



        // will be used for entry id
        $idElem = $this->createFormElement(
            'hidden', 
            'id', 
            array(
            )
        );
        
        // will be used for category id (optional)
        $idElem = $this->createFormElement(
            'hidden', 
            'categoryId', 
            array(
            )
        );
        
        // set the value to be used by modules implementing Kms_Interface_Form_Entry_Edit
        // the categoryId determined the upload context
        $idElem->setValue($categoryId);

        // submit
        $this->addElement('button', 'submit', array(
            'belongsTo' => self::FORM_NAME,
            'label'         => $this->_translate->translate('Save'),
            'type'          => 'submit',
            'class'         => 'btn btn-primary',
        ));
        
        // goto media link - create hidden with no url
        $element = new Kms_Form_Element_Note(
                        array(  'belongsTo' => self::FORM_NAME,
                                'name' => 'back',
                                'value' => '<a href="#" class="btn btn-link hidden" id="back">'. $this->_translate->translate('Go to Media') .'</a>'));
        $this->addElement($element);
        
        // actions group
        $this->addDisplayGroup(
            array('submit', 'back'),
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
                'order' => 100
            )
        );

        $this->setIsArray(true);

        $this->setDecorators(array(
            'FormElements',
            'Form',
        ));

        // add a trim filter to this form's elements
        $this->setElementFilters(array('StringTrim'));
        $this->getElement('name')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());
        $this->getElement('tags')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());
        $this->getElement('description')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());

        // the interface needs to be done here so it's the last call
        // otherwise some other classes call setDecorators which clears decorators added by the interface
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_Edit') as $name => $model)
        {
            $model->editEntryForm($this);
        }
    }
    
    
    private function createFormElement($type, $name, $params = array())
    {
        $params['belongsTo'] = self::FORM_NAME;
        $this->addElement($type, $name, $params);
        $elem = $this->getElement($name);
        $elem->setAttrib('class', $elem->getId() . ' span11');
        return $elem;
    }

	public function populate(array $values)
    {
        parent::populate($values);
        
        // go to media link:
        if ($this->getElement('id')->getValue()) {
        	$entryUrl = $this->view->entryLink($this->getElement('id')->getValue());
        	$element = $this->getElement('back');
        	$element->setValue('<a href="'. $entryUrl .'" class="btn btn-link" id="back">'. $this->_translate->translate('Go to Media') .'</a>');
        }

        $channelModel = Kms_Resource_Models::getChannel();
        if ($channelModel->isSharedRepositoriesEnabled() && !empty($values['id'])){
            $customdataProfileId = Kms_Resource_Config::getConfiguration('sharedRepositories', 'customDataProfileId');
            $requiredFields = Kms_Resource_Config::getConfiguration('sharedRepositories', 'requiredFields');
            $configuredDateFormat = Kms_Resource_Config::getConfiguration('sharedRepositories','dateFormat');
            $requiredLabel = $this->_translate->translate('* Required for Shared Repository');
            Kms_Helper_Metadata::populateEditEntryFormWithCustomMetadata($this, $values['id'], $customdataProfileId, $configuredDateFormat, 'sharedRepositories', $requiredFields, $requiredLabel);
        }

        // allow modules to populate the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_EditPopulate') as $name => $model)
        {
        	$model->populate($this, $values);
        }
    }
}

