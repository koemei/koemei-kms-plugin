<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * form to change gallery settings
 * the members of this form corresponds to the members of Kaltura_Client_Type_Category - 
 * this in order for the populate to work.
 * This form is identical to Application_Form_EditCategory, but calls an additional dallery interface.
 */
class Application_Form_EditGallery extends Application_Form_EditCategory
{
    public function init()
    {
        parent::init();
        $translate = Zend_Registry::get('Zend_Translate');
        
        $this->setAttrib('id','edit_gallery');
        
        $membership = $this->getElement('membership');
        $options = $membership->getMultiOptions();
        $options[Application_Model_Category::MEMBERSHIP_PRIVATE] .= '<p class="muted"><strong>' . $translate->translate('Note:') . '&nbsp;</strong>' . $translate->translate('Sub categories under a private category will be visible only to members of those sub categories') . '</p>';
        $membership->setMultiOptions($options);
        
        // goto category link - create hidden with no url
        $element = new Kms_Form_Element_Note(
                        array(  'belongsTo' => Application_Form_EditCategory::FORM_NAME,
                                'name' => 'back',
                                'value' => '<a href="#" class="btn btn-link hidden" id="back">back</a>'));
        $this->addElement($element);
        
        // actions group
        $group = $this->getDisplayGroup('actions');
        $elements = array();
        foreach ($group->getElements() as $name => $e) {
        	$elements[] = $name;
        }
        $elements[] = 'back';
        $this->removeDisplayGroup('actions');
        $this->addDisplayGroup(
            $elements,
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
                'order' => 101
            )
        );
        
        
        // allow modules to modify the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Gallery_Edit') as $name => $model)
        {
            $model->editForm($this);
        }
    }
    
    public function populate(array $values)
    {
    	/* we need the category's "real" name for the "back" link (or breadcrumps won't find it). we want to avoid 
    	 * the scenario of failed form-validation when category name was changed, so we take it before the call to 
    	 * parent::populate. on the first time the form is shown there will be no value before parent::populate, 
    	 * so if empty we take the name afterwards.
    	 */ 
    	$givenName = $this->getElement('name')->getValue();
        parent::populate($values);
        if (empty($givenName)) {
        	$givenName = $this->getElement('name')->getValue();
        }
        
		//We should limit the options for sub categories according to the privacy type set for the parent. So:
 		//1. If parent is restricted - when you edit the sub category, the 'open' should disabled/hidden
 		//2. If parent is private - when you edit the sub category, the 'open' and 'restricted' should be disabled/hidden
 		//-------------------------------------------------
 		if (isset($values['parentId']))
 		{
	        $parentCategory = Kms_Resource_Models::getCategory()->get('',false,$values['parentId']);
	        $membership =  $parentCategory->membership; 
	        $multi = $this->getElement('membership');
	        $options = $multi->getMultiOptions();
	        
	        if (!Kms_Resource_Models::getCategory()->isTopLevelCategory($values['id']))
	        {
		        if (Application_Model_Category::MEMBERSHIP_RESTRICTED == $membership)
		        {
		        	unset($options[Application_Model_Category::MEMBERSHIP_OPEN]);
		        	$multi->setMultiOptions($options);
		        }
		        else if (Application_Model_Category::MEMBERSHIP_PRIVATE == $membership)
		        {
		        	unset($options[Application_Model_Category::MEMBERSHIP_OPEN]);
		        	unset($options[Application_Model_Category::MEMBERSHIP_RESTRICTED]);
		        	$multi->setMultiOptions($options);	
		        }
	        }
 		}
        //-----------------------------------------------
        
        // create the "back" link
    	if ($this->getElement('id')->getValue() && $givenName) {
        	// have id, this is an existing (saved) category
        	$translate = Zend_Registry::get('Zend_Translate');
        	$baseUrl = new Zend_View_Helper_BaseUrl();
        	$categoryNameForUrl = new Kms_View_Helper_CategoryNameForUrl();
        	$name = $categoryNameForUrl->CategoryNameForUrl($givenName);
        		
        	// go to category (assume it's a category)
	        $url = $baseUrl->baseUrl('/category/'.$name.'/'.$this->getElement('id')->getValue());
	        $text = $translate->translate('Back to Category');
        	$element = $this->getElement('back');
        	$element->setValue('<a href="'. $url .'" class="btn btn-link" id="back">'. $text .'</a>');
        }
    
        // allow modules to populate the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Gallery_EditPopulate') as $name => $model)
        {
            $model->populate($this, $values);
        }
    }
}