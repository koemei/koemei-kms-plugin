<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * form to hold entry options
 * the form itself is empty, and received all its content via modules.
 * for an example implementation, see the comments module.
 */
class Application_Form_EntryOptions extends Kms_Form_Twitter_Bootstrap_Horizontal
{   
	const FORM_NAME = 'EntryOptions';

    private $view;
	private $_translate = null;

	public function init()
    {
        parent::init();

        $this->_translate = Zend_Registry::get('Zend_Translate');
		$front = Zend_Controller_Front::getInstance();
        $this->view = $front->getParam('bootstrap')->getResource('view');

        $entryId = $this->getAttrib('entryId');
        $this->removeAttrib('entryId');
        $this->setAttrib('ajax', true);
        $this->setAction($this->view->baseUrl('/entry/edit-options/entryid/' . $entryId));

        // we want the entry id to pass on to modules in populate()
		$idElem = $this->addElement(
            'hidden', 
            'id', 
            array('belongsTo' => self::FORM_NAME,
            )
        );

        $this->addElement('button', 'submit', array(
            'belongsTo' => self::FORM_NAME,
            'label'         => $this->_translate->translate('Save'),
            'type'          => 'submit',
            'class'         => 'btn btn-primary',
        ));

        $entryUrl = $this->view->entryLink($entryId);

        $element = new Kms_Form_Element_Note(
                        array(  'belongsTo' => self::FORM_NAME,
                                'name' => 'back',
                                'value' => '<a href="' . $entryUrl. '" class="btn btn-link">'. $this->_translate->translate('Go to Media') .'</a>'));
        $this->addElement($element);

        $this->addDisplayGroup(
            array('submit','back'),
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
                'order' => 100
            )
        );

        // allow modules to modify the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_Options') as $name => $model)
        {
            $model->editEntryOptionsForm($this);
        }
    }

    public function populate(array $values)
    {
        parent::populate($values);
    
        // allow modules to populate the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Entry_Options') as $name => $model)
        {
            $model->populateEntryOptionsForm($this, $values);
        }
    }
}