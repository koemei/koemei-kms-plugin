<?php
/**
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * form to add categories as a category tree 
 * the form receives the categories as form properties.
 */
class Application_Form_CategoryTree extends Kms_Form_Twitter_Bootstrap_Horizontal implements Kms_Form_Twitter_Bootstrap_SubForm {

    private $view;

    const FORM_NAME = 'CategoryTree';
    const LABEL = 'label';
    const ROOT_CAT = 'rootcat';
    const CATEGORIES = 'categories';
    const MESSAGE = '';
    const IS_CONTROL_GROUP = 'false';

    public function init() {
        parent::init();

        $this->view = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getResource('view');

        // get the categories tree attributes
        $label = $this->getAttrib(self::LABEL);
        $rootCat = $this->getAttrib(self::ROOT_CAT);
        $message =  $this->getAttrib(self::MESSAGE);
        $categories = $this->getAttrib(self::CATEGORIES);

        // clear the non standard attributes so they won't interfere with the rendering of the form
        $this->removeAttrib(self::LABEL);
        $this->removeAttrib(self::ROOT_CAT);
        $this->removeAttrib(self::CATEGORIES);

        $categoriesArr = array();
        foreach ($categories as $cat)
            $categoriesArr[] = $cat->id;

        // prepare the categories navigation tree
        $nav = new Zend_Navigation();
        $categoryModel = new Application_Model_Gallery();
        $nav->addPages(Kms_Resource_Nav::buildCategoryTree($categoryModel->getAllGalleries()));

        // iterate on the gallery tree and and form elements
        $iterator = new RecursiveIteratorIterator($nav, RecursiveIteratorIterator::SELF_FIRST);
        $iterator->setMaxDepth(4);
        $depth = 0;
        $i = 1;
        $tagOrder = 10;

        // remove the decorators 'wrapper' and 'htmltag' which make lots of problems in the context of what we are trying to do here
        // basicaly, they are forcing the 'controlgroup' and 'control' divs which we do not want here
        $this->setElementDecorators(array(
            array('FieldSize'),
            array('ViewHelper'),
            array('Addon'),
            array('ElementErrors'),
        ));
        //-----------------------------------------------------------
        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'div_cg',
            'value' => '<div class="control-group"><label class="control-label">' . $label . '</label><div class="navbar">'. $message. $this->view->partial('partials/category/iconLegend.phtml') . '</div><div class="controls">')));


        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'div',
            'value' => '<br><div class="row-fluid categoriesList">')));

        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'ul' . $tagOrder++,
            'value' => '<ul class="unstyled">')));

        foreach ($iterator as $level => $page) {
            // if page is a category
            if ($page->categoryname) {
            	$iteratorDepth = $iterator->getDepth();
                // add <ul></ul> elements to new levels of the tree
                if ($depth < $iteratorDepth) {
                    $this->addElement(new Kms_Form_Element_Note(
                            array('belongsTo' => self::FORM_NAME,
                        'name' => 'ul' . $tagOrder++,
                        'value' => '<ul class="unstyled">')));
                } 
                elseif ($depth > $iteratorDepth) {
                    // if we are going more than a single level up, add multiple </ul>s
                    while ($depth > $iteratorDepth) {
	                	$this->addElement(new Kms_Form_Element_Note(
	                            array('belongsTo' => self::FORM_NAME,
	                        'name' => 'ul' . $tagOrder++,
	                        'value' => '</ul>')));
	                    $depth --;
                    }
                    
                } 
//                else { // ADDED THE LI TAG TO THE CLOSUERE ELEMENT
//                    $this->addElement(new Kms_Form_Element_Note(
//                            array('belongsTo' => self::FORM_NAME,
//                        'name' => 'li' . $tagOrder++,
//                        'value' => '</li>')));
//                }

                $depth = $iteratorDepth;

                // create the category checkboxes
                $spec = array('belongsTo' => self::FORM_NAME,
                    'name' => $page->catNum,
                );

                $value = '<li><label class="checkbox"><span class="inline">';

                $value .= $this->view->CategoryIcons($page->categoryInfo['moderation'], $page->categoryInfo['membership']);

                $this->addElement(new Kms_Form_Element_Note(
                        array('belongsTo' => self::FORM_NAME,
                    'name' => 'li' . $tagOrder++,
                    'value' => $value)));

                if (in_array($page->catNum, $categoriesArr))
                    $this->addElement('checkbox', (string) $page->catNum, $spec);

                $this->addElement(new Kms_Form_Element_Note(
                        array('belongsTo' => self::FORM_NAME,
                    'name' => 'des' . $tagOrder++,
                    'value' => (string) $page->getLabel())));

                $this->addElement(new Kms_Form_Element_Note(
                        array('belongsTo' => self::FORM_NAME,
                    'name' => 'label' . $tagOrder++,
                    'value' => '</span></label></li>')));
            }
        }
        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'ul' . $tagOrder++,
            'value' => '</ul>')));

        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'end_div',
            'value' => '</div>')));

        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'div_end_categorylist',
            'value' => '</div>')));

        $this->addElement(new Kms_Form_Element_Note(
                array('belongsTo' => self::FORM_NAME,
            'name' => 'div_end_cg',
            'value' => '</div>')));
    }

}