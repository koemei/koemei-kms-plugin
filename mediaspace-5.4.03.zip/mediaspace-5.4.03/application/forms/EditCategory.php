<?php
/*
 * All Code Confidential and Proprietary, Copyright ©2011 Kaltura, Inc.
 * To learn more: http://corp.kaltura.com/Products/Video-Applications/Kaltura-Mediaspace-Video-Portal
 */

/**
 * form to change category settings
 * the members of this form corresponds to the members of Kaltura_Client_Type_Category - 
 * this in order for the populate to work.
 */
class Application_Form_EditCategory extends Kms_Form_Twitter_Bootstrap_Horizontal
{
    const FORM_NAME = 'Category';
        
    public function init()
    {
        parent::init();
        $translate = Zend_Registry::get('Zend_Translate');

        // will be used for category id
        $idElem = $this->createFormElement(
            'hidden', 
            'id', 
            array(
            )
        );
        
        // title
        $validator = new Zend_Validate_StringLength(array('max' => 60));
        $validator->setMessage($translate->translate('Value is longer than %max% characters').'.', Zend_Validate_StringLength::TOO_LONG);
        $this->createFormElement(
        	'text',
        	'name',
        	array(
             	'label' => $translate->translate('Name'),
        		'isRequired' => $translate->translate('Name is a required field'),
        		'required' => 'required',
        	),
        	array($validator)
        );
        

        // description
        $elem = $this->createFormElement(
            'textarea', 
            'description', 
            array(
                'label' => $translate->translate('Description'),
                'isEmpty' => false,
                'id' => 'description',
                'placeholder' => $translate->translate('Enter Description...'),
                'rows' => 7,
            )
        );
        $elem->setAttrib('class', $elem->getId() . ' input-xxlarge wysiwyg');
        
        // tags
		$elem = $this->createFormElement(
            'text', 
            'tags', 
            array(
            	'id' => 'tags',
                'label' => $translate->translate('Tags'),
            )
        );
        
        $elem->setAttrib('class', $elem->getId().' tags input-xxlarge select2');
        
        // membership
        $membershipMultiOptions = $this->getMembershipMultiOptions();
        $this->createMembershipFormElement($membershipMultiOptions);

        // indication that this form is about a channel 
        $this->createFormElement(
        	'hidden',
        	'id',array()
        );
        
        $this->createFormElement("MultiCheckbox", "options", array(
			"label" => 'Options',
			"multiOptions" => array(
				"moderation" => $translate->translate('Moderate content (Media will not appear in channel until approved by channel manager)'),
			)
		));
		       
        // allow modules to modify the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Category_Edit') as $name => $model)
        {
            $model->editForm($this);
        }   
                
        $this->addElement('button', 'submit', array(
            'belongsTo' => self::FORM_NAME,
            'label'         => $translate->translate('Save'),
            'type'          => 'submit',
            'class'         => 'btn btn-primary',
        ));
		
        $this->addDisplayGroup(
            array('submit'),
            'actions',
            array(
                'disableLoadDefaultDecorators' => true,
                'decorators' => array('Actions'),
            )
        );

        // add a trim filter to this form's elements
        $this->setElementFilters(array('StringTrim'));
        $this->getElement('name')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());
        $this->getElement('tags')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());
        $this->getElement('description')->addFilter(Kms_Resource_Wysihtml::getFieldFilter());
    }
    
    protected function getMembershipMultiOptions(){
       return array(Application_Model_Category::MEMBERSHIP_OPEN => $this->getMembershipTranslation(Application_Model_Category::MEMBERSHIP_OPEN),
                       Application_Model_Category::MEMBERSHIP_RESTRICTED => $this->getMembershipTranslation(Application_Model_Category::MEMBERSHIP_RESTRICTED),
                        Application_Model_Category::MEMBERSHIP_PRIVATE => $this->getMembershipTranslation(Application_Model_Category::MEMBERSHIP_PRIVATE),
                    );
    }
    
    protected function getMembershipTranslation($membership){
        $translate = Zend_Registry::get('Zend_Translate');
        $translation = '';
        switch ($membership){
            case Application_Model_Category::MEMBERSHIP_OPEN:
                $translation = '<strong>' . $translate->translate('Open') . '</strong> - <span>' . $translate->translate('Membership is open and non-members can view content and participate.') . '</span>';
                break;
            case Application_Model_Category::MEMBERSHIP_RESTRICTED:
                $translation = '<strong>' . $translate->translate('Restricted') . '</strong> - <span>' . $translate->translate('Non-members can view content, but users must be invited to participate.') . '</span>';
                break;
            case Application_Model_Category::MEMBERSHIP_PRIVATE:
                $translation = '<strong>' . $translate->translate('Private') . '</strong> - <span>' . $translate->translate('Membership is by invitation only and only members can view content and participate.') . '</span>';
                break;
        }
        
        return $translation;
    }

    /**
     * create and add the membership form element
     * @param array $allowedMemberships optional, array of category model membership consts that are allowed
     */
    protected function createMembershipFormElement(array $membershipMultiOptions = array()){
        $translate = Zend_Registry::get('Zend_Translate');
        $membershipValues = array_keys($membershipMultiOptions);
        $value = count($membershipValues)>0 ? $membershipValues[0] : null;
        $this->createFormElement(
            'radio', 
            'membership', 
            array(
              'multiOptions' => $membershipMultiOptions,
               'label' => $translate->translate('Privacy'),
               'value' => $value,
               'escape' => false,
           )
       );
    }
    
	protected function getModerationSpec()
    {
    	return $this->getElement('moderation');	
    }
    
    public function populate(array $values)
    {
        parent::populate($values);
		
        if (isset($values['moderation']) && $values['moderation'])
        {
        	$checked = $this->getElement('options')->getValue();
        	if (!is_array($checked))
        		$checked = array();
        		        
        	array_push($checked,'moderation');
        	$this->getElement('options')->setValue($checked);
        }
        	
        
        // allow modules to populate the form
        foreach(Kms_Resource_Config::getModulesForInterface('Kms_Interface_Form_Category_EditPopulate') as $name => $model)
        {
            $model->populate($this, $values);
        }
    }
    
	private function createFormElement($type, $name, $params = array(),$validators = Array())
    {
        $params['belongsTo'] = self::FORM_NAME;
        $this->addElement($type, $name, $params);
        $elem = $this->getElement($name);
        $elem->setAttrib('class', $elem->getId() . ' input-xxlarge');
        $elem->setValidators($validators);
        return $elem;
    }
}