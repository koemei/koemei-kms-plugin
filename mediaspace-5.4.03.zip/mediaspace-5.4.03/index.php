<?php
// redirect to public (backup in case htaccess fails)
header('Location: public/');
exit;

